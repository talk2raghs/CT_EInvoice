#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generator for the DDIC layer of ZZCLR_EINVOICE_ELT.
Emits abapGit XML in exactly the format used by the already-converted
ZZCLR_ELT public-cloud package (ABAP language version 5 / cloudDevelopment).
"""
import os

OUT = os.environ.get("EINV_OUT", "/home/claude/ZZCLR_EINVOICE_ELT/src")
os.makedirs(OUT, exist_ok=True)

BOM = "﻿"
HDR = '<?xml version="1.0" encoding="utf-8"?>\n'


def write(name, body):
    with open(os.path.join(OUT, name), "w", encoding="utf-8", newline="\n") as f:
        f.write(body)


def git(serializer, inner, sv="v1.0.0"):
    return (
        BOM + HDR
        + f'<abapGit version="v1.0.0" serializer="{serializer}" serializer_version="{sv}">\n'
        ' <asx:abap xmlns:asx="http://www.sap.com/abapxml" version="1.0">\n'
        '  <asx:values>\n'
        + inner
        + '  </asx:values>\n'
        ' </asx:abap>\n'
        '</abapGit>\n'
    )


# ---------------------------------------------------------------- domains ----
def outputlen_of(dt, leng, dec):
    """What DDIC computes as the output length, so the activation does not warn
    on every numeric domain. Integer digits, plus a thousands separator every
    three, plus the decimal point and the decimals."""
    if dt in ("DEC", "CURR", "QUAN", "FLTP"):
        intd = leng - (dec or 0)
        return intd + max(0, (intd - 1) // 3) + (1 if dec else 0) + (dec or 0)
    if dt == "INT4":
        return leng + 1
    if dt == "DATS":
        return 10
    if dt == "TIMS":
        return 8
    return leng


def domain(name, text, datatype, leng, outputlen=None, decimals=None,
           fixed=None, lowercase=False, sign=False, valexi=False):
    outputlen = outputlen if outputlen is not None else outputlen_of(datatype, leng, decimals)
    s = "   <DD01V>\n"
    s += f"    <DOMNAME>{name}</DOMNAME>\n"
    s += "    <DDLANGUAGE>E</DDLANGUAGE>\n"
    s += f"    <DATATYPE>{datatype}</DATATYPE>\n"
    s += f"    <LENG>{leng:06d}</LENG>\n"
    if decimals is not None:
        s += f"    <DECIMALS>{decimals:06d}</DECIMALS>\n"
    s += f"    <OUTPUTLEN>{outputlen:06d}</OUTPUTLEN>\n"
    if lowercase:
        s += "    <LOWERCASE>X</LOWERCASE>\n"
    if sign:
        s += "    <SIGNFLAG>X</SIGNFLAG>\n"
    if valexi:
        s += "    <VALEXI>X</VALEXI>\n"
    s += f"    <DDTEXT>{text}</DDTEXT>\n"
    s += "    <DOMMASTER>E</DOMMASTER>\n"
    s += "    <ABAP_LANGUAGE_VERSION>5</ABAP_LANGUAGE_VERSION>\n"
    s += "   </DD01V>\n"
    if fixed:
        s += "   <DD07V_TAB>\n"
        for i, (low, txt) in enumerate(fixed, start=1):
            s += "    <DD07V>\n"
            s += f"     <VALPOS>{i:04d}</VALPOS>\n"
            s += "     <DDLANGUAGE>E</DDLANGUAGE>\n"
            s += f"     <DOMVALUE_L>{low}</DOMVALUE_L>\n"
            s += f"     <DDTEXT>{txt}</DDTEXT>\n"
            s += "    </DD07V>\n"
        s += "   </DD07V_TAB>\n"
    write(f"{name.lower()}.doma.xml", git("LCL_OBJECT_DOMA", s))


# ----------------------------------------------------------- data elements ---
def dtel(name, domname, text, short, medium=None, long=None, head=None):
    medium = medium or short
    long = long or medium
    head = head or long
    s = "   <DD04V>\n"
    s += f"    <ROLLNAME>{name}</ROLLNAME>\n"
    s += "    <DDLANGUAGE>E</DDLANGUAGE>\n"
    s += f"    <DOMNAME>{domname}</DOMNAME>\n"
    s += f"    <HEADLEN>{min(len(head), 55)}</HEADLEN>\n"
    s += "    <SCRLEN1>10</SCRLEN1>\n"
    s += "    <SCRLEN2>20</SCRLEN2>\n"
    s += "    <SCRLEN3>40</SCRLEN3>\n"
    s += f"    <DDTEXT>{text}</DDTEXT>\n"
    s += f"    <REPTEXT>{head}</REPTEXT>\n"
    s += f"    <SCRTEXT_S>{short}</SCRTEXT_S>\n"
    s += f"    <SCRTEXT_M>{medium}</SCRTEXT_M>\n"
    s += f"    <SCRTEXT_L>{long}</SCRTEXT_L>\n"
    s += "    <DTELMASTER>E</DTELMASTER>\n"
    s += "    <REFKIND>D</REFKIND>\n"
    s += "    <ABAP_LANGUAGE_VERSION>5</ABAP_LANGUAGE_VERSION>\n"
    s += "   </DD04V>\n"
    write(f"{name.lower()}.dtel.xml", git("LCL_OBJECT_DTEL", s))


# ----------------------------------------------------------------- tables ----
# Built-in type metadata for fields declared without a data element.
BUILTIN = {
    "CLNT": ("C", lambda n: n * 2, "  CLNT"),
    "CHAR": ("C", lambda n: n * 2, "  CHAR"),
    "NUMC": ("N", lambda n: n * 2, "  NUMC"),
    "INT4": ("X", lambda n: 4, "  INT4"),
    "DATS": ("D", lambda n: 16, "  DATS"),
    "TIMS": ("T", lambda n: 12, "  TIMS"),
    "DEC": ("P", lambda n: (n // 2) + 1, "  DEC"),
    "STRG": ("g", lambda n: 8, "  STRG"),
    "RSTR": ("y", lambda n: 8, "  RSTR"),
    "CUKY": ("C", lambda n: n * 2, "  CUKY"),
}


def field(name, rollname=None, key=False, datatype=None, leng=None, decimals=None):
    s = "    <DD03P>\n"
    s += f"     <FIELDNAME>{name}</FIELDNAME>\n"
    if key:
        s += "     <KEYFLAG>X</KEYFLAG>\n"
    if rollname:
        s += f"     <ROLLNAME>{rollname}</ROLLNAME>\n"
    s += "     <ADMINFIELD>0</ADMINFIELD>\n"
    if rollname:
        if key:
            s += "     <NOTNULL>X</NOTNULL>\n"
        s += "     <COMPTYPE>E</COMPTYPE>\n"
    else:
        it, il, mask = BUILTIN[datatype]
        s += f"     <INTTYPE>{it}</INTTYPE>\n"
        s += f"     <INTLEN>{il(leng):06d}</INTLEN>\n"
        if key:
            s += "     <NOTNULL>X</NOTNULL>\n"
        s += f"     <DATATYPE>{datatype}</DATATYPE>\n"
        s += f"     <LENG>{leng:06d}</LENG>\n"
        if decimals is not None:
            s += f"     <DECIMALS>{decimals:06d}</DECIMALS>\n"
        s += f"     <MASK>{mask}</MASK>\n"
    s += "    </DD03P>\n"
    return s


CLIENT_FIELD = field("CLIENT", key=True, datatype="CLNT", leng=3)


def table(name, text, fields, tabart="APPL0", inttab=False):
    s = "   <DD02V>\n"
    s += f"    <TABNAME>{name}</TABNAME>\n"
    s += "    <DDLANGUAGE>E</DDLANGUAGE>\n"
    s += f"    <TABCLASS>{'INTTAB' if inttab else 'TRANSP'}</TABCLASS>\n"
    if not inttab:
        s += "    <CLIDEP>X</CLIDEP>\n"
    s += f"    <DDTEXT>{text}</DDTEXT>\n"
    s += "    <MASTERLANG>E</MASTERLANG>\n"
    if not inttab:
        s += "    <CONTFLAG>A</CONTFLAG>\n"
    s += "    <EXCLASS>1</EXCLASS>\n"
    s += "   </DD02V>\n"
    if not inttab:
        s += "   <DD09L>\n"
        s += f"    <TABNAME>{name}</TABNAME>\n"
        s += "    <AS4LOCAL>A</AS4LOCAL>\n"
        s += "    <TABKAT>0</TABKAT>\n"
        s += f"    <TABART>{tabart}</TABART>\n"
        s += "    <BUFALLOW>N</BUFALLOW>\n"
        s += "   </DD09L>\n"
    s += "   <DD03P_TABLE>\n"
    s += "".join(fields)
    s += "   </DD03P_TABLE>\n"
    if not inttab:
        s += "   <TABL_EXTRAS>\n"
        s += "    <TDDAT>\n"
        s += f"     <TABNAME>{name}</TABNAME>\n"
        s += "     <CCLASS>CUS_DEV_SUP_DA</CCLASS>\n"
        s += "    </TDDAT>\n"
        s += "   </TABL_EXTRAS>\n"
    write(f"{name.lower()}.tabl.xml", git("LCL_OBJECT_TABL", s))


def ttyp_elem(name, rowtype, text):
    """Table type over a DATA ELEMENT, so /ui2/cl_json renders a JSON array
    of plain scalars (["CODE"]) rather than an array of objects."""
    s = "   <DD40V>\n"
    s += f"    <TYPENAME>{name}</TYPENAME>\n"
    s += "    <DDLANGUAGE>E</DDLANGUAGE>\n"
    s += f"    <ROWTYPE>{rowtype}</ROWTYPE>\n"
    s += "    <ROWKIND>E</ROWKIND>\n"
    s += "    <ACCESSMODE>T</ACCESSMODE>\n"
    s += "    <KEYDEF>D</KEYDEF>\n"
    s += "    <KEYKIND>N</KEYKIND>\n"
    s += f"    <DDTEXT>{text}</DDTEXT>\n"
    s += "    <ABAP_LANGUAGE_VERSION>5</ABAP_LANGUAGE_VERSION>\n"
    s += "   </DD40V>\n"
    write(f"{name.lower()}.ttyp.xml", git("LCL_OBJECT_TTYP", s))


def ttyp(name, rowtype, text):
    s = "   <DD40V>\n"
    s += f"    <TYPENAME>{name}</TYPENAME>\n"
    s += "    <DDLANGUAGE>E</DDLANGUAGE>\n"
    s += f"    <ROWTYPE>{rowtype}</ROWTYPE>\n"
    s += "    <ROWKIND>S</ROWKIND>\n"
    s += "    <DATATYPE>STRU</DATATYPE>\n"
    s += "    <ACCESSMODE>T</ACCESSMODE>\n"
    s += "    <KEYDEF>D</KEYDEF>\n"
    s += "    <KEYKIND>N</KEYKIND>\n"
    s += f"    <DDTEXT>{text}</DDTEXT>\n"
    s += "    <ABAP_LANGUAGE_VERSION>5</ABAP_LANGUAGE_VERSION>\n"
    s += "   </DD40V>\n"
    write(f"{name.lower()}.ttyp.xml", git("LCL_OBJECT_TTYP", s))


# =============================================================== DOMAINS =====
# Domains whose content is free text, a URL, or a value supplied by or sent
# to the Clear platform. Without <LOWERCASE>X</LOWERCASE> the DDIC input
# conversion upper-cases every entry, which silently corrupts an endpoint
# URL, an HTTP header name such as X-Clear-Country-Code, a bearer token, or
# any message coming back from the portal. SAP keys and internal codes are
# deliberately NOT in this set: upper-casing them is correct, and a
# case-sensitive KEY field would let two rows differ only by case.
LOWERCASE_DOMAINS = {
    "ZDO_EINV_URL", "ZDO_EINV_PARAM", "ZDO_EINV_PARAMVAL", "ZDO_EINV_VALUE",
    "ZDO_EINV_ERRMSG", "ZDO_EINV_RESMSG", "ZDO_EINV_ERRSRC",
    "ZDO_EINV_ERRCODE", "ZDO_EINV_RESCODE", "ZDO_EINV_NAME",
    "ZDO_EINV_DOCID", "ZDO_EINV_IDENT", "ZDO_EINV_CMDID",
    "ZDO_EINV_REASONTXT", "ZDO_EINV_ACTDESC", "ZDO_EINV_DOCTDESC",
    # Key fields, added on the customer's instruction: these carry values
    # minted by the Clear platform, which may be mixed case. The trade-off
    # is that two rows can now differ by case alone - see section 37.
    "ZDO_EINV_INVNO", "ZDO_EINV_STATUS",
    # Non-key; VAT IDs are conventionally upper case but are stored as typed.
    "ZDO_EINV_VAT",
}

DOMAINS = [
    # name, text, type, len, extras
    ("ZDO_EINV_LAND1",      "Country Key",                        "CHAR", 3),
    ("ZDO_EINV_FUNC",       "e-Invoice API Functionality",        "CHAR", 30),
    ("ZDO_EINV_URL",        "e-Invoice Endpoint (relative URL)",  "CHAR", 300),
    ("ZDO_EINV_PARAM",      "HTTP Header / Parameter Name",       "CHAR", 60),
    ("ZDO_EINV_PARAMVAL",   "HTTP Header / Parameter Value",      "CHAR", 200),
    ("ZDO_EINV_LABEL",      "Configuration Label",                "CHAR", 30),
    ("ZDO_EINV_VALUE",      "Configuration Value",                "CHAR", 150),
    ("ZDO_EINV_PRODUCT",    "Clear Product",                      "CHAR", 10),
    ("ZDO_EINV_DOCT",       "e-Invoice Document Type Code",       "CHAR", 15),
    ("ZDO_EINV_DOCTDESC",   "e-Invoice Document Type Description", "CHAR", 60),
    ("ZDO_EINV_TRANST",     "e-Invoice Transaction Type",         "CHAR", 15),
    ("ZDO_EINV_SUPTYPE",    "Supply Type",                        "CHAR", 10),
    ("ZDO_EINV_STATUS",     "e-Invoice Status",                   "CHAR", 40),
    ("ZDO_EINV_DOCID",      "Clear Platform Document ID",         "CHAR", 60),
    ("ZDO_EINV_INVNO",      "e-Invoice Number",                   "CHAR", 40),
    ("ZDO_EINV_INVTYPE",    "e-Invoice Invoice Type",             "CHAR", 20),
    ("ZDO_EINV_IDENT",      "e-Invoice Identifier",               "CHAR", 60),
    ("ZDO_EINV_TYPE",       "e-Invoice Type",                     "CHAR", 20),
    ("ZDO_EINV_CMDID",      "ELT Command ID",                     "CHAR", 60),
    ("ZDO_EINV_ERRNO",      "Error Sequence Number",              "NUMC", 3),
    ("ZDO_EINV_ERRCODE",    "API Error Code",                     "CHAR", 40),
    ("ZDO_EINV_ERRSRC",     "API Error Source",                   "CHAR", 60),
    ("ZDO_EINV_ERRMSG",     "API Error Message",                  "CHAR", 250),
    ("ZDO_EINV_VAT",        "VAT Registration Number",            "CHAR", 20),
    ("ZDO_EINV_ACTION",     "e-Invoice Action Type",              "CHAR", 20),
    ("ZDO_EINV_ACTDESC",    "e-Invoice Action Description",       "CHAR", 60),
    ("ZDO_EINV_REASON",     "e-Invoice Reason Code",              "CHAR", 20),
    ("ZDO_EINV_REASONTXT",  "e-Invoice Reason Text",              "CHAR", 100),
    ("ZDO_EINV_RESCODE",    "Exchange Response Code",             "CHAR", 40),
    ("ZDO_EINV_RESMSG",     "Exchange Response Message",          "CHAR", 250),
    ("ZDO_EINV_HANDLER",    "Country Handler Class Name",         "CHAR", 30),
    ("ZDO_EINV_PROCMODE",   "Processing Mode",                    "CHAR", 1),
    ("ZDO_EINV_SEQ",        "Configuration Sequence",             "INT4", 10),
]

FIXED_DOMAINS = [
    ("ZDO_EINV_FLAG", "Single-Character Flag", "CHAR", 1,
     [("X", "Yes"), (" ", "No")]),
    ("ZDO_EINV_CRIT", "UI Criticality", "NUMC", 1,
     [("0", "Neutral"), ("1", "Negative (red)"),
      ("2", "Critical (yellow)"), ("3", "Positive (green)")]),
    # The sales cockpit's seller action never read /CLR/YT_ACTION: dynpro
    # 0200 hard-coded its two values in MODULE status_0200 via
    # VRM_SET_VALUES. A fixed-value domain is the faithful port and gives
    # Fiori the same two-entry dropdown without a customizing dependency.
    ("ZDO_EINV_SELLER_ACT", "Seller Action Type", "CHAR", 20,
     [("COMPLETE", "Mark Complete"), ("CONFIRM_PAYMENT", "Confirm Payment")]),
]

for d in DOMAINS:
    domain(d[0], d[1], d[2], d[3],
           lowercase=d[0] in LOWERCASE_DOMAINS)
for name, text, dt, ln, fx in FIXED_DOMAINS:
    domain(name, text, dt, ln, fixed=fx, valexi=True)

# ========================================================= DATA ELEMENTS =====
DTELS = [
    ("ZDE_EINV_LAND1",     "ZDO_EINV_LAND1",     "Country Key for e-Invoicing",        "Country"),
    ("ZDE_EINV_FUNC",      "ZDO_EINV_FUNC",      "e-Invoice API Functionality",        "Function"),
    ("ZDE_EINV_URL",       "ZDO_EINV_URL",       "e-Invoice Endpoint (relative URL)",  "URL"),
    ("ZDE_EINV_PARAM",     "ZDO_EINV_PARAM",     "HTTP Header / Parameter Name",       "Header"),
    ("ZDE_EINV_PARAMVAL",  "ZDO_EINV_PARAMVAL",  "HTTP Header / Parameter Value",      "Value"),
    ("ZDE_EINV_LABEL",     "ZDO_EINV_LABEL",     "Configuration Label",               "Label"),
    ("ZDE_EINV_LOW",       "ZDO_EINV_VALUE",     "Configuration Value (From)",         "Low"),
    ("ZDE_EINV_HIGH",      "ZDO_EINV_VALUE",     "Configuration Value (To)",           "High"),
    ("ZDE_EINV_PRODUCT",   "ZDO_EINV_PRODUCT",   "Clear Product",                      "Product"),
    ("ZDE_EINV_DOCT",      "ZDO_EINV_DOCT",      "e-Invoice Document Type Code",       "Doc.Type"),
    ("ZDE_EINV_DOCTDESC",  "ZDO_EINV_DOCTDESC",  "e-Invoice Document Type Description", "Doc.Type Desc."),
    ("ZDE_EINV_TRANST",    "ZDO_EINV_TRANST",    "e-Invoice Transaction Type",         "Trans.Type"),
    ("ZDE_EINV_SUPTYPE",   "ZDO_EINV_SUPTYPE",   "Supply Type",                        "Supply Type"),
    ("ZDE_EINV_STATUS",    "ZDO_EINV_STATUS",    "e-Invoice Status",                   "Status"),
    ("ZDE_EINV_STATUS_TO", "ZDO_EINV_STATUS",    "e-Invoice Target Status",            "Target Status"),
    ("ZDE_EINV_STATDESC",  "ZDO_EINV_DOCTDESC",  "e-Invoice Status Description",       "Status Desc."),
    ("ZDE_EINV_DOCID",     "ZDO_EINV_DOCID",     "Clear Platform Document ID",         "Document ID"),
    ("ZDE_EINV_INVNO",     "ZDO_EINV_INVNO",     "e-Invoice Number",                   "e-Invoice No."),
    ("ZDE_EINV_INVTYPE",   "ZDO_EINV_INVTYPE",   "e-Invoice Invoice Type",             "Invoice Type"),
    ("ZDE_EINV_IDENT",     "ZDO_EINV_IDENT",     "e-Invoice Identifier",               "Identifier"),
    ("ZDE_EINV_TYPE",      "ZDO_EINV_TYPE",      "e-Invoice Type",                     "e-Inv.Type"),
    ("ZDE_EINV_CMDID",     "ZDO_EINV_CMDID",     "ELT Command ID",                     "Command ID"),
    ("ZDE_EINV_ERRNO",     "ZDO_EINV_ERRNO",     "Error Sequence Number",              "Error No."),
    ("ZDE_EINV_ERRCODE",   "ZDO_EINV_ERRCODE",   "API Error Code",                     "Error Code"),
    ("ZDE_EINV_ERRSRC",    "ZDO_EINV_ERRSRC",    "API Error Source",                   "Error Source"),
    ("ZDE_EINV_ERRMSG",    "ZDO_EINV_ERRMSG",    "API Error Message",                  "Error Message"),
    ("ZDE_EINV_VAT",       "ZDO_EINV_VAT",       "VAT Registration Number",            "VAT No."),
    ("ZDE_EINV_ACTION",    "ZDO_EINV_ACTION",    "e-Invoice Action Type",              "Action"),
    ("ZDE_EINV_ACTDESC",   "ZDO_EINV_ACTDESC",   "e-Invoice Action Description",       "Action Desc."),
    ("ZDE_EINV_REASON",    "ZDO_EINV_REASON",    "e-Invoice Reason Code",              "Reason"),
    ("ZDE_EINV_REASONTXT", "ZDO_EINV_REASONTXT", "e-Invoice Reason Text",              "Reason Text"),
    ("ZDE_EINV_RESCODE",   "ZDO_EINV_RESCODE",   "Exchange Response Code",             "Resp.Code"),
    ("ZDE_EINV_RESMSG",    "ZDO_EINV_RESMSG",    "Exchange Response Message",          "Resp.Message"),
    ("ZDE_EINV_HANDLER",   "ZDO_EINV_HANDLER",   "Country Handler Class Name",         "Handler"),
    ("ZDE_EINV_PROCMODE",  "ZDO_EINV_PROCMODE",  "Processing Mode (S=Sync, A=Async)",  "Mode"),
    ("ZDE_EINV_SEQ",       "ZDO_EINV_SEQ",       "Configuration Sequence",             "Sequence"),
    ("ZDE_EINV_FLAG",      "ZDO_EINV_FLAG",      "e-Invoice Indicator",                "Indicator"),
    ("ZDE_EINV_CRIT",      "ZDO_EINV_CRIT",      "UI Criticality",                     "Criticality"),
    ("ZDE_EINV_SELLER_ACT", "ZDO_EINV_SELLER_ACT", "Seller Action Type",                "Action"),
]
for name, dom, text, short in DTELS:
    dtel(name, dom, text, short)

# ================================================================ TABLES =====
# ---- Common key blocks -------------------------------------------------------
# PROJECTID + SYSID mirror the scoping keys of ZTELT_CONFIG in ZZCLR_ELT, but
# with own data elements -- ZDE_PROJECT_ID / ZDE_SYSID over there are NOT
# C1-released, so referencing them across packages would break the contract.
domain("ZDO_EINV_PROJECTID", "Clear Project ID", "CHAR", 30)
dtel("ZDE_EINV_PROJECTID", "ZDO_EINV_PROJECTID", "Clear Project ID", "Project ID")
domain("ZDO_EINV_SYSID", "Logical System ID", "CHAR", 8)
dtel("ZDE_EINV_SYSID", "ZDO_EINV_SYSID", "Logical System ID", "System ID")


def key_scope():
    return [
        field("PROJECTID", "ZDE_EINV_PROJECTID", key=True),
        field("SYSID", "ZDE_EINV_SYSID", key=True),
    ]


def key_org():
    return [
        field("LAND1", "ZDE_EINV_LAND1", key=True),
        field("BUKRS", "ZDE_EINV_BUKRS", key=True),
    ]


# BUKRS: use an own data element over the released company-code domain type so
# the package has no dependency on a non-released DDIC element.
domain("ZDO_EINV_BUKRS", "Company Code", "CHAR", 4)
dtel("ZDE_EINV_BUKRS", "ZDO_EINV_BUKRS", "Company Code", "Comp.Code")
domain("ZDO_EINV_BILLDOC", "Billing Document", "CHAR", 10)
dtel("ZDE_EINV_BILLDOC", "ZDO_EINV_BILLDOC", "Billing Document", "Bill.Doc.")
domain("ZDO_EINV_ACCDOC", "Accounting Document Number", "CHAR", 10)
dtel("ZDE_EINV_ACCDOC", "ZDO_EINV_ACCDOC", "Accounting Document Number", "Acc.Doc.")
domain("ZDO_EINV_GJAHR", "Fiscal Year", "NUMC", 4)
dtel("ZDE_EINV_GJAHR", "ZDO_EINV_GJAHR", "Fiscal Year", "Fisc.Year")
domain("ZDO_EINV_FKART", "Billing Type", "CHAR", 4)
dtel("ZDE_EINV_FKART", "ZDO_EINV_FKART", "Billing Document Type", "Bill.Type")
domain("ZDO_EINV_BLART", "Accounting Document Type", "CHAR", 2)
dtel("ZDE_EINV_BLART", "ZDO_EINV_BLART", "Accounting Document Type", "Doc.Type")
domain("ZDO_EINV_PARTNER", "Business Partner Number", "CHAR", 10)
dtel("ZDE_EINV_PARTNER", "ZDO_EINV_PARTNER", "Business Partner Number", "Partner")
domain("ZDO_EINV_NAME", "Business Partner Name", "CHAR", 80,
       lowercase="ZDO_EINV_NAME" in LOWERCASE_DOMAINS)
dtel("ZDE_EINV_NAME", "ZDO_EINV_NAME", "Business Partner Name", "Name")
# --- 2026-09-25 HANA drop: signed invoice, QR code, platform UUID ----------
# /CLR/ZT_EINV and /CLR/ZT_SALES_ST both gained ZSIGNED_QRCODE, ZSIGNED_INV
# and UUID. Note the HANA package has TWO uuid data elements with crossed
# names -- the tables use /CLR/DE_UUID (domain /CLR/ZDM_UUID, CHAR 100), NOT
# /CLR/ZDE_UUID (domain /CLR/DOM_UUID, CHAR 50). CHAR 100 is the right one.
domain("ZDO_EINV_QRCODE", "Signed Invoice QR Code", "STRG", 0, lowercase=True)
dtel("ZDE_EINV_QRCODE", "ZDO_EINV_QRCODE", "Signed Invoice QR Code", "QR Code")
domain("ZDO_EINV_SIGNEDINV", "Signed Invoice", "STRG", 0, lowercase=True)
dtel("ZDE_EINV_SIGNEDINV", "ZDO_EINV_SIGNEDINV", "Signed Invoice (signed payload)", "Signed Inv.")
domain("ZDO_EINV_UUID", "Clear Platform UUID", "CHAR", 100, lowercase=True)
dtel("ZDE_EINV_UUID", "ZDO_EINV_UUID", "Clear Platform UUID", "UUID")

domain("ZDO_EINV_TSTMPL", "UTC Time Stamp (Long)", "DEC", 21, decimals=7)
dtel("ZDE_EINV_LCHG", "ZDO_EINV_TSTMPL", "Last Changed At (UTC, long)", "Chg.At")
domain("ZDO_EINV_USER", "User Name", "CHAR", 12)
dtel("ZDE_EINV_USER", "ZDO_EINV_USER", "Created By User", "Created By")


def doc_key():
    """The semantic key of a sales e-invoice, 1:1 with /CLR/ZT_EINV minus MANDT."""
    return [
        field("VBELN", "ZDE_EINV_BILLDOC", key=True),
        field("BELNR", "ZDE_EINV_ACCDOC", key=True),
        field("BUKRS", "ZDE_EINV_BUKRS", key=True),
        field("GJAHR", "ZDE_EINV_GJAHR", key=True),
    ]


# ---------------------------------------------------------- 1. ZTEINV_CNTRY --
# SEQUENCE was promoted to a key field in the 2026-09-25 HANA drop, and VAT
# was added. Note the HANA factory still does SELECT SINGLE without SEQUENCE
# in the WHERE, so with several sequence rows per company code the row it
# picks is non-deterministic -- ZCL_EINV_CONFIG orders by SEQUENCE instead.
table("ZTEINV_CNTRY", "e-Invoice Country / Company Registration",
      [CLIENT_FIELD] + key_scope() + key_org() + [
          field("SEQUENCE", "ZDE_EINV_SEQ", key=True),
          field("VAT", "ZDE_EINV_VAT"),
          field("LAND1_DESC", "ZDE_EINV_DOCTDESC"),
          field("AUTO_EINV_GENERATE", "ZDE_EINV_FLAG"),
          field("AUTO_EINV_CANCEL", "ZDE_EINV_FLAG"),
          field("HANDLER_CLASS", "ZDE_EINV_HANDLER"),
      ])

# ------------------------------------------------------------ 2. ZTEINV_API --
table("ZTEINV_API", "e-Invoice API Endpoint Registry",
      [CLIENT_FIELD] + key_scope() + key_org() + [
          field("FUNCTIONALITY", "ZDE_EINV_FUNC", key=True),
          field("SEQUENCE", "ZDE_EINV_SEQ", key=True),
          field("URL", "ZDE_EINV_URL"),
          field("PARAM_NAME", "ZDE_EINV_PARAM"),
          field("PARAM_VALUE", "ZDE_EINV_PARAMVAL"),
      ])

# ---------------------------------------------------------- 3. ZTEINV_CONST --
table("ZTEINV_CONST", "e-Invoice Generic Constants",
      [CLIENT_FIELD] + key_scope() + [
          field("PRODUCT", "ZDE_EINV_PRODUCT", key=True),
      ] + key_org() + [
          field("ZLABEL", "ZDE_EINV_LABEL", key=True),
          field("SEQUENCE", "ZDE_EINV_SEQ", key=True),
          field("LOW", "ZDE_EINV_LOW"),
          field("HIGH", "ZDE_EINV_HIGH"),
      ])

# --------------------------------------------------------- 4. ZTEINV_INVMAP --
table("ZTEINV_INVMAP", "e-Invoice Document Relevance Mapping",
      [CLIENT_FIELD] + key_scope() + key_org() + [
          field("FKART", "ZDE_EINV_FKART", key=True),
          field("BLART", "ZDE_EINV_BLART", key=True),
          field("DOC_TYPE", "ZDE_EINV_DOCT", key=True),
          field("EINVOICE", "ZDE_EINV_FLAG"),
          field("EWAYBILL", "ZDE_EINV_FLAG"),
          field("NONIRN", "ZDE_EINV_FLAG"),
          field("NO_ACC", "ZDE_EINV_FLAG"),
          field("B2C", "ZDE_EINV_FLAG"),
          field("PURCHASE", "ZDE_EINV_FLAG"),
      ])

# --------------------------------------------------------- 5. ZTEINV_DOCTYP --
table("ZTEINV_DOCTYP", "e-Invoice Document Type Codes",
      [CLIENT_FIELD] + key_scope() + key_org() + [
          field("TRANSACT_TYPE", "ZDE_EINV_TRANST", key=True),
          field("DOC_TYPE_CODE", "ZDE_EINV_DOCT", key=True),
          field("DOC_TYPE_DESCR", "ZDE_EINV_DOCTDESC"),
      ])

# --------------------------------------------------------- 6. ZTEINV_STATUS --
table("ZTEINV_STATUS", "e-Invoice Status Mapping and Criticality",
      [CLIENT_FIELD] + key_scope() + key_org() + [
          field("SEQUENCE", "ZDE_EINV_SEQ", key=True),
          field("PROC_MODE", "ZDE_EINV_PROCMODE", key=True),
          field("STATUS", "ZDE_EINV_STATUS"),
          field("STATUS_TO_BE", "ZDE_EINV_STATUS_TO"),
          field("STATUS_DESC", "ZDE_EINV_STATDESC"),
          field("CRITICALITY", "ZDE_EINV_CRIT"),
      ])

# ------------------------------------------------------------ 7. ZTEINV_VAT --
table("ZTEINV_VAT", "e-Invoice Company Code VAT Registration",
      [CLIENT_FIELD] + key_scope() + key_org() + [
          field("SEQUENCE", "ZDE_EINV_SEQ", key=True),
          field("VAT", "ZDE_EINV_VAT"),
      ])

# --------------------------------------------------------- 8. ZTEINV_ACTION --
table("ZTEINV_ACTION", "e-Invoice Action Types",
      [CLIENT_FIELD, field("EINV_TYPE", "ZDE_EINV_TYPE", key=True),
       field("ACTION_TYPE", "ZDE_EINV_ACTION", key=True),
       field("ACTION_DESCRIPTION", "ZDE_EINV_ACTDESC")])

# --------------------------------------------------------- 9. ZTEINV_REASON --
table("ZTEINV_REASON", "e-Invoice Reason Codes per Action",
      [CLIENT_FIELD, field("ACTION_TYPE", "ZDE_EINV_ACTION", key=True),
       field("REASON_CODE", "ZDE_EINV_REASON", key=True),
       field("REASON_TEXT", "ZDE_EINV_REASONTXT")])

# -------------------------------------------------------- 10. ZTEINV_STATTX --
table("ZTEINV_STATTX", "e-Invoice Status Texts",
      [CLIENT_FIELD, field("STATUS_CODE", "ZDE_EINV_STATUS", key=True),
       field("STATUS_TEXT", "ZDE_EINV_STATDESC")])

# ============================================ TRANSACTIONAL PERSISTENCE ======
# 11. ZTEINV_DOC  <-  /CLR/ZT_EINV   (field names kept 1:1 so the Clear
#     platform's ingestion write-back schema needs only a table rename)
table("ZTEINV_DOC", "e-Invoice Document Status (Sales / AR)",
      [CLIENT_FIELD] + doc_key() + [
          field("INVNO", "ZDE_EINV_INVNO"),
          field("INVDT", datatype="DATS", leng=8),
          field("DOC_TYPE", "ZDE_EINV_DOCT"),
          field("INVID", "ZDE_EINV_DOCID"),
          field("INVTYPE", "ZDE_EINV_INVTYPE"),
          field("STATUS", "ZDE_EINV_STATUS"),
          field("ERROR", "ZDE_EINV_ERRMSG"),
          field("B2C", "ZDE_EINV_FLAG"),
          field("B2G", "ZDE_EINV_FLAG"),
          field("SENT", "ZDE_EINV_FLAG"),
          field("B2C_STATUS", "ZDE_EINV_STATUS"),
          field("EINV_IDENTIFIER", "ZDE_EINV_IDENT"),
          field("EINV_TYPE", "ZDE_EINV_TYPE"),
          field("COMMAND_ID", "ZDE_EINV_CMDID"),
          field("ZSIGNED_QRCODE", "ZDE_EINV_QRCODE"),
          field("ZSIGNED_INV", "ZDE_EINV_SIGNEDINV"),
          field("UUID", "ZDE_EINV_UUID"),
          field("CRDAT", datatype="DATS", leng=8),
          field("CRTIME", datatype="TIMS", leng=6),
          field("CRUSER", "ZDE_EINV_USER"),
          field("LOCAL_LAST_CHANGED_AT", "ZDE_EINV_LCHG"),
      ], tabart="APPL1")

# 12. ZTEINV_DOC_ASY  <-  /CLR/ZT_EINV_ASY
table("ZTEINV_DOC_ASY", "e-Invoice Document Status (Asynchronous)",
      [CLIENT_FIELD] + doc_key() + [
          field("INVNO", "ZDE_EINV_INVNO"),
          field("INVDT", datatype="DATS", leng=8),
          field("DOC_TYPE", "ZDE_EINV_DOCT"),
          field("INVID", "ZDE_EINV_DOCID"),
          field("INVTYPE", "ZDE_EINV_INVTYPE"),
          field("STATUS", "ZDE_EINV_STATUS"),
          field("ERROR", "ZDE_EINV_ERRMSG"),
          field("B2C", "ZDE_EINV_FLAG"),
          field("B2G", "ZDE_EINV_FLAG"),
          field("SENT", "ZDE_EINV_FLAG"),
          field("B2C_STATUS", "ZDE_EINV_STATUS"),
          field("CRDAT", datatype="DATS", leng=8),
          field("CRTIME", datatype="TIMS", leng=6),
          field("CRUSER", "ZDE_EINV_USER"),
      ], tabart="APPL1")

# 13. ZTEINV_ERR  <-  /CLR/ZT_EINV_ERR  (CHECKBOX removed from the key)
table("ZTEINV_ERR", "e-Invoice API Error Details",
      [CLIENT_FIELD] + doc_key() + [
          field("INVNO", "ZDE_EINV_INVNO", key=True),
          field("ERRORNO", "ZDE_EINV_ERRNO", key=True),
          field("ERRORDATE", datatype="DATS", leng=8),
          field("ERRORTIME", datatype="TIMS", leng=6),
          field("ERRORCODE", "ZDE_EINV_ERRCODE"),
          field("ERRORSOURCE", "ZDE_EINV_ERRSRC"),
          field("ERRORMESSAGE", "ZDE_EINV_ERRMSG"),
      ], tabart="APPL1")

# 14. ZTEINV_SALES_ST  <-  /CLR/ZT_SALES_ST  (multi-stage exchange status)
STAGES = [
    ("PA_EXCHG", "Peer-to-Peer Exchange"),
    ("PPF_INVSUB", "PPF Invoice Submission"),
    ("PPF_LCSUB", "PPF Lifecycle Submission"),
    ("PPF_LCREJ", "PPF Lifecycle Rejection"),
    ("PPF_LCREF", "PPF Lifecycle Refusal"),
    ("PPF_LCPMNT", "PPF Payment Collection"),
]
stage_fields = []
for st, _ in STAGES:
    stage_fields += [
        field(f"{st}_STAT", "ZDE_EINV_STATUS"),
        field(f"{st}_RESCODE", "ZDE_EINV_RESCODE"),
        field(f"{st}_RESMSG", "ZDE_EINV_RESMSG"),
    ]
table("ZTEINV_SALES_ST", "e-Invoice Multi-Stage Exchange Status (Sales)",
      [CLIENT_FIELD] + doc_key() + [
          field("INVID", "ZDE_EINV_DOCID"),
          field("INVOICE_NUM", "ZDE_EINV_INVNO"),
          field("INVOICE_TYPE", "ZDE_EINV_INVTYPE"),
          field("DOC_TYPE", "ZDE_EINV_DOCT"),
          field("ZSIGNED_QRCODE", "ZDE_EINV_QRCODE"),
          field("ZSIGNED_INV", "ZDE_EINV_SIGNEDINV"),
          field("UUID", "ZDE_EINV_UUID"),
      ] + stage_fields + [
          field("EINV_IDENTIFIER", "ZDE_EINV_IDENT"),
          field("EINV_TYPE", "ZDE_EINV_TYPE"),
      ], tabart="APPL1")

# 15. ZTEINV_PDF -- replaces cl_gui_frontend_services=>gui_download
table("ZTEINV_PDF", "e-Invoice Printout (PDF) Store",
      [CLIENT_FIELD] + doc_key() + [
          field("INVID", "ZDE_EINV_DOCID"),
          field("FILENAME", "ZDE_EINV_PARAMVAL"),
          field("MIMETYPE", "ZDE_EINV_PARAM"),
          field("CONTENT", datatype="RSTR", leng=0),
          field("CRDAT", datatype="DATS", leng=8),
          field("CRTIME", datatype="TIMS", leng=6),
      ], tabart="APPL1")

# ================================================== WIRE / API STRUCTURES =====
# Response envelopes for the three e-invoice endpoints that this package calls
# directly. Leaf fields are STRG so /ui2/cl_json can fill them regardless of
# what the platform sends -- same convention as ZSTR_* in ZZCLR_ELT.
def strg(name):
    return field(name, datatype="STRG", leng=0)


# ------------------------------------------------- the e-document fetch log --
# Kept from /CLR/EINV_AP_RUN. It used to live in the e-document generator,
# which is gone with the flat AP tables; the run log is not part of that model.
table("ZTEINV_RUN", "e-Invoice Document Fetch Run Log",
      [field("CLIENT", key=True, datatype="CLNT", leng=3),
       field("RUN_UUID", "ZDE_EINV_UUID", key=True),
       field("EINV_TYPE", "ZDE_EINV_TYPE"),
       field("RUN_DATE", datatype="DATS", leng=8),
       field("RUN_TIME", datatype="TIMS", leng=6),
       field("RUN_BY", "ZDE_EINV_USER"),
       field("START_DATE", datatype="DATS", leng=8),
       field("END_DATE", datatype="DATS", leng=8),
       field("ADHOC_INDICATOR", "ZDE_EINV_FLAG"),
       field("DOC_COUNT", datatype="INT4", leng=10),
       field("MESSAGE", "ZDE_EINV_ERRMSG")])

table("ZSTR_EINV_ERRDTL", "e-Invoice API Error Detail",
      [strg("ERROR_CODE"), strg("ERROR_MESSAGE"), strg("ERROR_SOURCE"), strg("PATH")],
      inttab=True)
ttyp("ZSTR_EINV_ERRDTL_TT", "ZSTR_EINV_ERRDTL", "Table type for ZSTR_EINV_ERRDTL")

table("ZSTR_EINV_STATUS_RES", "e-Invoice Status API Response",
      [strg("SUCCESS"), strg("DOCUMENT_ID"), strg("STATUS"), strg("UUID"),
       strg("LONGID"), strg("QR_CODE"), strg("INTERNAL_ID"),
       strg("DATE_TIME_VALIDATED"), strg("CANCEL_DATE_TIME"),
       strg("REJECT_REQUEST_TIME"),
       field("ERROR_DETAILS", "ZSTR_EINV_ERRDTL_TT")],
      inttab=True)

table("ZSTR_EINV_ACTION_RES", "e-Invoice Seller / Cancel Action Response",
      [strg("SUCCESS"), strg("DOCUMENT_ID"), strg("UUID"),
       strg("CANCEL_DATE"), strg("MESSAGE"), strg("PPFREPORTING_REQUIRED"),
       field("ERROR_DETAILS", "ZSTR_EINV_ERRDTL_TT")],
      inttab=True)

table("ZSTR_EINV_PRINT_RES", "e-Invoice Print API Error Response",
      [field("ERROR", "ZSTR_EINV_ERRDTL_TT")], inttab=True)

table("ZSTR_EINV_VATSPLIT", "e-Invoice VAT Rate Split",
      [field("RATE", datatype="DEC", leng=5, decimals=2),
       field("AMOUNTCOLLECTEDINCLUDINGVAT", datatype="DEC", leng=15, decimals=2)],
      inttab=True)
ttyp("ZSTR_EINV_VATSPLIT_TT", "ZSTR_EINV_VATSPLIT", "Table type for ZSTR_EINV_VATSPLIT")

# actionData.reasonCodes is a JSON array of plain strings, so the ABAP type
# must be a table of a scalar - not a table of one-field structures.
ttyp_elem("ZSTR_EINV_REASON_TT", "ZDE_EINV_REASON", "e-Invoice Reason Code List")

table("ZSTR_EINV_ACT_DATA", "e-Invoice Action Payload - actionData",
      [strg("COLLECTIONDATE"),
       field("REASONCODES", "ZSTR_EINV_REASON_TT"),
       field("VATRATESPLIT", "ZSTR_EINV_VATSPLIT_TT")], inttab=True)

table("ZSTR_EINV_ACT_REQ", "e-Invoice Seller Action Request Payload",
      [strg("DOCUMENTID"), strg("ACTIONTYPE"), strg("DOCUMENTNUMBER"),
       strg("DOCUMENTDATE"), strg("TAXPAYERIDENTIFIER"), strg("DOCUMENTTYPECODE"),
       strg("COMMENT"),
       field("ACTIONDATA", "ZSTR_EINV_ACT_DATA")], inttab=True)

# Worklist / relevance transfer structure used by the pick-up logic and the job
# ---- document-list response of GET_DOC_LIST ------------------------------
# Shape taken from /CLR/EINV_AP_DOCS + /CLR/ZT_S_AP_DOCLIST, the two DDIC
# structures /CLR/AP_EINVOICE~get_documents deserialises into.
table("ZSTR_EINV_APDOC", "e-Invoice Document List Entry",
      [strg("DOCUMENT_ID"), strg("DOCUMENT_NUMBER"), strg("STATUS"),
       field("ERROR_DETAILS", "ZSTR_EINV_ERRDTL_TT")], inttab=True)
ttyp("ZSTR_EINV_APDOC_TT", "ZSTR_EINV_APDOC", "Table type for ZSTR_EINV_APDOC")

table("ZSTR_EINV_APDOCS_RES", "e-Invoice Document List API Response",
      [strg("SUCCESS"), strg("PAGE_NUMBER"), strg("PAGE_SIZE"),
       field("DOCUMENTS", "ZSTR_EINV_APDOC_TT"),
       field("ERROR_DETAILS", "ZSTR_EINV_ERRDTL_TT")], inttab=True)

table("ZSTR_EINV_RELEVANT", "e-Invoice Relevant Document (transfer structure)",
      [field("VBELN", "ZDE_EINV_BILLDOC"),
       field("BELNR", "ZDE_EINV_ACCDOC"),
       field("BUKRS", "ZDE_EINV_BUKRS"),
       field("GJAHR", "ZDE_EINV_GJAHR"),
       field("FKART", "ZDE_EINV_FKART"),
       field("BLART", "ZDE_EINV_BLART"),
       field("LAND1", "ZDE_EINV_LAND1"),
       field("DOC_TYPE", "ZDE_EINV_DOCT"),
       field("B2C", "ZDE_EINV_FLAG"),
       field("BLDAT", datatype="DATS", leng=8),
       field("BUDAT", datatype="DATS", leng=8)],
      inttab=True)
ttyp("ZSTR_EINV_RELEVANT_TT", "ZSTR_EINV_RELEVANT", "Table type for ZSTR_EINV_RELEVANT")

table("ZSTR_EINV_ACT_RESULT", "e-Invoice Action Result (per document)",
      [field("VBELN", "ZDE_EINV_BILLDOC"),
       field("BELNR", "ZDE_EINV_ACCDOC"),
       field("BUKRS", "ZDE_EINV_BUKRS"),
       field("GJAHR", "ZDE_EINV_GJAHR"),
       field("SUCCESS", "ZDE_EINV_FLAG"),
       field("STATUS", "ZDE_EINV_STATUS"),
       field("MESSAGE", "ZDE_EINV_ERRMSG")],
      inttab=True)
ttyp("ZSTR_EINV_ACT_RESULT_TT", "ZSTR_EINV_ACT_RESULT",
     "Table type for ZSTR_EINV_ACT_RESULT")

ttyp("ZTEINV_DOC_TT", "ZTEINV_DOC", "Table type for ZTEINV_DOC")
ttyp("ZTEINV_ERR_TT", "ZTEINV_ERR", "Table type for ZTEINV_ERR")

print("DDIC objects written to", OUT)
