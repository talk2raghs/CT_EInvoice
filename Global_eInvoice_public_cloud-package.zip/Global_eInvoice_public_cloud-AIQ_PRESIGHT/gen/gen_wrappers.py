#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Emits the remaining ZZCLR_EINVOICE_ELT artefacts:
  * service definitions / bindings          (.srvd.srvdsrv/.xml, .srvb.xml)
  * message class                           (.msag.xml)
  * APJ job catalog / template / log        (.sajc.json, .sajt.json, .aplo.json)
  * abapGit XML wrappers for every hand-written CDS / BDEF / class / intf
  * package + repository descriptors        (package.devc.xml, .abapgit.xml)
"""
import os
import re

ROOT = os.environ.get("EINV_ROOT", "/home/claude/ZZCLR_EINVOICE_ELT")
OUT = os.path.join(ROOT, "src")
os.makedirs(OUT, exist_ok=True)

BOM = "﻿"
HDR = '<?xml version="1.0" encoding="utf-8"?>\n'


def write(name, body):
    with open(os.path.join(OUT, name), "w", encoding="utf-8", newline="\n") as f:
        f.write(body)


def exists(name):
    return os.path.exists(os.path.join(OUT, name))


def git(serializer, inner, sv="v1.0.0"):
    return (BOM + HDR
            + f'<abapGit version="v1.0.0" serializer="{serializer}" serializer_version="{sv}">\n'
            ' <asx:abap xmlns:asx="http://www.sap.com/abapxml" version="1.0">\n'
            '  <asx:values>\n' + inner
            + '  </asx:values>\n </asx:abap>\n</abapGit>\n')


def esc(t):
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ======================================================= DDLS / DDLX / BDEF ==
def ddls_xml(name, text):
    write(f"{name.lower()}.ddls.xml", git("LCL_OBJECT_DDLS",
          "   <DDLS>\n"
          f"    <DDLNAME>{name}</DDLNAME>\n"
          "    <DDLANGUAGE>E</DDLANGUAGE>\n"
          f"    <DDTEXT>{esc(text[:60])}</DDTEXT>\n"
          "    <SOURCE_TYPE>W</SOURCE_TYPE>\n"
          "   </DDLS>\n"))


def ddls_baseinfo(name, from_list, assoc_list=None):
    assoc_list = assoc_list or []

    def arr(items):
        return "[]" if not items else "[\n" + ",\n".join(f'"{i}"' for i in items) + "\n]"

    write(f"{name.lower()}.ddls.baseinfo",
          '{\n"BASEINFO":\n{\n"FROM":\n' + arr(from_list)
          + ',\n"ASSOCIATED":\n' + arr(assoc_list)
          + ',\n"BASE":\n[],\n"ANNO_REF":\n[],\n"SCALAR_FUNCTION":\n[],\n'
            '"VERSION":0,\n"ANNOREF_EVALUATION_ERROR":""\n}\n}\n')


def ddlx_xml(name, text):
    write(f"{name.lower()}.ddlx.xml", git("LCL_OBJECT_DDLX",
          "   <DDLX>\n    <METADATA>\n"
          f"     <NAME>{name}</NAME>\n"
          f"     <DESCRIPTION>{esc(text[:60])}</DESCRIPTION>\n"
          "     <MASTER_LANGUAGE>EN</MASTER_LANGUAGE>\n"
          "    </METADATA>\n   </DDLX>\n"))


def bdef_xml(name, text):
    write(f"{name.lower()}.bdef.xml", git("LCL_OBJECT_BDEF",
          "   <BDEF>\n"
          f"    <NAME>{name}</NAME>\n"
          "    <TYPE>BDEF/BDO</TYPE>\n"
          f"    <DESCRIPTION>{esc(text[:60])}</DESCRIPTION>\n"
          "    <DESCRIPTION_TEXT_LIMIT>60</DESCRIPTION_TEXT_LIMIT>\n"
          "    <LANGUAGE>EN</LANGUAGE>\n"
          "    <MASTER_LANGUAGE>EN</MASTER_LANGUAGE>\n"
          "    <ABAP_LANGU_VERSION>5</ABAP_LANGU_VERSION>\n"
          f"    <SOURCE_URI>./{name.lower()}/source/main</SOURCE_URI>\n"
          "    <SOURCE_TYPE>ABAP_SOURCE</SOURCE_TYPE>\n"
          "    <SOURCE_FIXED_POINT_ARITHMETIC>true</SOURCE_FIXED_POINT_ARITHMETIC>\n"
          "    <SOURCE_UNICODE_CHECKS_ACTIVE>true</SOURCE_UNICODE_CHECKS_ACTIVE>\n"
          "   </BDEF>\n"))


def clas_xml(name, text, defint=None, category=None):
    inner = ("   <VSEOCLASS>\n"
             f"    <CLSNAME>{name}</CLSNAME>\n"
             "    <LANGU>E</LANGU>\n"
             f"    <DESCRIPT>{esc(text[:60])}</DESCRIPT>\n")
    if category:
        inner += f"    <CATEGORY>{category}</CATEGORY>\n"
    inner += ("    <STATE>1</STATE>\n"
              "    <CLSCCINCL>X</CLSCCINCL>\n"
              "    <FIXPT>X</FIXPT>\n"
              "    <UNICODE>X</UNICODE>\n")
    if defint:
        inner += f"    <CLSDEFINT>{defint}</CLSDEFINT>\n"
    inner += ("    <ABAP_LANGUAGE_VERSION>5</ABAP_LANGUAGE_VERSION>\n"
              "   </VSEOCLASS>\n")
    write(f"{name.lower()}.clas.xml", git("LCL_OBJECT_CLAS", inner))


def intf_xml(name, text):
    write(f"{name.lower()}.intf.xml", git("LCL_OBJECT_INTF",
          "   <VSEOINTERF>\n"
          f"    <CLSNAME>{name}</CLSNAME>\n"
          "    <LANGU>E</LANGU>\n"
          f"    <DESCRIPT>{esc(text[:60])}</DESCRIPT>\n"
          "    <EXPOSURE>2</EXPOSURE>\n"
          "    <STATE>1</STATE>\n"
          "    <UNICODE>X</UNICODE>\n"
          "    <ABAP_LANGUAGE_VERSION>5</ABAP_LANGUAGE_VERSION>\n"
          "   </VSEOINTERF>\n"))


# ------------------------- hand-written CDS: name -> (text, from, assoc) -----
CDS = {
    "ZCDS_INT_EINV_DOC": ("Interface View for Sales e-Invoice Document",
                          ["ZTEINV_DOC"],
                          ["ZCDS_INT_EINV_DOC_ERR", "ZCDS_INT_EINV_DOC_STAT",
                           "ZCDS_INT_EINV_DOC_ASY", "I_BILLINGDOCUMENT",
                           "I_JOURNALENTRY"]),
    "ZCDS_INT_EINV_DOC_ERR": ("Interface View for e-Invoice API Error Details",
                              ["ZTEINV_ERR"], ["ZCDS_INT_EINV_DOC"]),
    "ZCDS_INT_EINV_DOC_STAT": ("Interface View for Multi-Stage Exchange Status",
                               ["ZTEINV_SALES_ST"], ["ZCDS_INT_EINV_DOC"]),
    "ZCDS_INT_EINV_DOC_ASY": ("Interface View for Async e-Invoice Status",
                              ["ZTEINV_DOC_ASY"], []),
    "ZCDS_INT_EINV_REL_JRNL": ("e-Invoice Relevant Journal Entries",
                               ["I_JOURNALENTRY", "ZTEINV_INVMAP"], []),
    "ZCDS_INT_EINV_RELEVANT": ("e-Invoice Worklist Candidates",
                               ["ZCDS_INT_EINV_REL_JRNL", "I_BILLINGDOCUMENT"], []),
    "ZCDS_CUN_EINV_DOC": ("Sales e-Invoice Cockpit",
                          ["ZCDS_INT_EINV_DOC"],
                          ["ZCDS_CUN_EINV_DOC_ERR", "ZCDS_CUN_EINV_DOC_STAT"]),
    "ZCDS_CUN_EINV_DOC_ERR": ("e-Invoice API Error Details",
                              ["ZCDS_INT_EINV_DOC_ERR"], ["ZCDS_CUN_EINV_DOC"]),
    "ZCDS_CUN_EINV_DOC_STAT": ("e-Invoice Exchange Status",
                               ["ZCDS_INT_EINV_DOC_STAT"], ["ZCDS_CUN_EINV_DOC"]),
    "ZCDS_ABS_EINV_SELLACT": ("Seller Action Parameters", [],
                              ["ZCDS_ABS_EINV_VATSPLIT"]),
    "ZCDS_ABS_EINV_VATSPLIT": ("Seller Action VAT Rate Split", [],
                               ["ZCDS_ABS_EINV_SELLACT"]),
    "ZCDS_ABS_EINV_PICKUP": ("e-Invoice Pick-Up Parameters", [], []),
    "ZCDS_ABS_EINV_CANCEL": ("e-Invoice Cancellation Parameters", [], []),
    "ZCDS_ABS_EINV_APACT": ("Inbound e-Invoice Action Parameters", [], []),
    "ZCDS_ABS_EINV_SELFACT": ("Self-Billed Action Parameters", [], []),
}
for name, (text, frm, assoc) in CDS.items():
    if exists(f"{name.lower()}.ddls.asddls"):
        ddls_xml(name, text)
        ddls_baseinfo(name, frm, assoc)

ddlx_xml("ZCDS_MET_EINV_DOC", "UI for the Sales e-Invoice Cockpit")
# The two children of the sales cockpit need their own extensions: a
# #LINEITEM_REFERENCE facet is rendered from the CHILD entity's
# @UI.lineItem, so without these the Exchange Status and API Errors
# tables appear on the object page with no columns.
ddlx_xml("ZCDS_MET_EINV_DOC_ERR", "UI for the Sales e-Invoice API errors")
ddlx_xml("ZCDS_MET_EINV_DOC_STAT", "UI for the Sales e-Invoice exchange status")

bdef_xml("ZCDS_INT_EINV_DOC", "Behavior Definition for Sales e-Invoice")
bdef_xml("ZCDS_CUN_EINV_DOC", "Projection Behavior for Sales e-Invoice")

# ---------------------------------------------------- hand-written classes ---
CLASSES = {
    "ZBP_CDS_INT_EINV_DOC": ("Behavior Implementation for ZCDS_INT_EINV_DOC",
                             "ZCDS_INT_EINV_DOC", "06"),
    "ZBP_CDS_CUN_EINV_DOC": ("Projection Implementation for ZCDS_CUN_EINV_DOC",
                             "ZCDS_CUN_EINV_DOC", "06"),
    "ZCL_EINV_UTIL": ("e-Invoice: cloud-safe system information", None, None),
    "ZCL_EINV_CONFIG": ("e-Invoice: configuration access", None, None),
    "ZCL_EINV_COUNTRY_DEFAULT": ("e-Invoice: default country handler", None, None),
    "ZCL_EINV_COUNTRY_FACTORY": ("e-Invoice: country handler factory", None, None),
    "ZCL_EINV_API_CLIENT": ("e-Invoice: Clear platform HTTP client", None, None),
    "ZCL_EINV_SUBMIT": ("e-Invoice: submission orchestrator", None, None),
    "ZCL_EINV_WORKLIST": ("e-Invoice: worklist selection", None, None),
    "ZCL_EINV_PDF_STORE": ("e-Invoice: printout store", None, None),
    "ZCL_EINV_AUTO_TRIGGER": ("e-Invoice: automatic generation on posting", None, None),
    "ZCL_EINV_PICKUP_JOB": ("e-Invoice job: pick up relevant documents", None, None),
    "ZCL_EINV_SUBMIT_JOB": ("e-Invoice job: submit pending documents", None, None),
    "ZCL_EINV_STATUS_JOB": ("e-Invoice job: refresh platform status", None, None),
    "ZCL_EINV_COUNTRY_DE": ("e-Invoice country handler: Germany", None, None),
    "ZCL_EINV_COUNTRY_JO": ("e-Invoice country handler: Jordan", None, None),
    "ZCL_EINV_EDOC_ACTION": ("e-Document: action validation and send", None, None),
    "ZCL_EINV_EDOC_FETCH": ("e-Document: inbound document fetch", None, None),
    "ZCL_EINV_EDOC_FETCH_JOB": ("e-Document job: fetch inbound documents", None, None),
}
for name, (text, defint, cat) in CLASSES.items():
    if exists(f"{name.lower()}.clas.abap"):
        clas_xml(name, text, defint=defint, category=cat)

# projection implementation class body (empty, like ZZCLR_ELT's)
if not exists("zbp_cds_cun_einv_doc.clas.abap"):
    write("zbp_cds_cun_einv_doc.clas.abap",
          "CLASS zbp_cds_cun_einv_doc DEFINITION PUBLIC ABSTRACT FINAL "
          "FOR BEHAVIOR OF zcds_cun_einv_doc.\n\n"
          "  PROTECTED SECTION.\n  PRIVATE SECTION.\nENDCLASS.\n\n\n\n"
          "CLASS ZBP_CDS_CUN_EINV_DOC IMPLEMENTATION.\nENDCLASS.\n")
    clas_xml("ZBP_CDS_CUN_EINV_DOC",
             "Projection Implementation for ZCDS_CUN_EINV_DOC",
             defint="ZCDS_CUN_EINV_DOC", category="06")

intf_xml("ZIF_EINV_COUNTRY", "e-Invoice: country-specific behaviour")


# ================================================ service defs / bindings ===
def srvd(name, text, exposes):
    # @EndUserText.label is STRING(40) on a service definition too
    body = f"@EndUserText.label: '{(text or '')[:40].rstrip(' -,/(')}'\ndefine service {name} {{\n"
    for entity, alias in exposes:
        body += f"  expose {entity} as {alias};\n"
    body += "}\n"
    write(f"{name.lower()}.srvd.srvdsrv", body)
    write(f"{name.lower()}.srvd.xml", git("LCL_OBJECT_SRVD",
          "   <SRVD>\n"
          f"    <NAME>{name}</NAME>\n"
          "    <TYPE>SRVD/SRV</TYPE>\n"
          f"    <DESCRIPTION>{esc(text[:60])}</DESCRIPTION>\n"
          "    <LANGUAGE>EN</LANGUAGE>\n"
          "    <MASTER_LANGUAGE>EN</MASTER_LANGUAGE>\n"
          f"    <SOURCE_URI>./{name.lower()}/source/main</SOURCE_URI>\n"
          "    <SOURCE_TYPE>ABAP_SOURCE</SOURCE_TYPE>\n"
          "    <SOURCE_ORIGIN_DESCRIPTION>ABAP Development Tools</SOURCE_ORIGIN_DESCRIPTION>\n"
          "    <SRVD_SOURCE_TYPE>S</SRVD_SOURCE_TYPE>\n"
          "    <SRVD_SOURCE_TYPE_DESC>Definition</SRVD_SOURCE_TYPE_DESC>\n"
          "   </SRVD>\n"))


def srvb(name, text, srvd_name):
    write(f"{name.lower()}.srvb.xml", git("LCL_OBJECT_SRVB",
          "   <SRVB>\n    <METADATA>\n"
          f"     <NAME>{name}</NAME>\n"
          "     <TYPE>SRVB/SVB</TYPE>\n"
          f"     <DESCRIPTION>{esc(text[:60])}</DESCRIPTION>\n"
          "     <LANGUAGE>EN</LANGUAGE>\n"
          "     <MASTER_LANGUAGE>EN</MASTER_LANGUAGE>\n"
          "     <ABAP_LANGU_VERSION>5</ABAP_LANGU_VERSION>\n"
          "    </METADATA>\n"
          "    <CONTENT>\n"
          "     <BIND_TYPE_IMPL>\n"
          f"      <NAME>{name}</NAME>\n"
          "     </BIND_TYPE_IMPL>\n"
          "     <BIND_TYPE>ODATA</BIND_TYPE>\n"
          "     <BIND_TYPE_VERSION>V2</BIND_TYPE_VERSION>\n"
          "     <SERVICES>\n      <item>\n"
          f"       <SERVICE_NAME>{name}</SERVICE_NAME>\n"
          "       <SERVICE_CONTENT>\n        <item>\n"
          "         <SERVICE_VERSION>0001</SERVICE_VERSION>\n"
          "         <RELEASE_STATE>NOT_RELEASED</RELEASE_STATE>\n"
          "         <SRVD_REF>\n"
          f"          <URI>/sap/bc/adt/ddic/srvd/sources/{srvd_name.lower()}</URI>\n"
          "          <TYPE>SRVD/SRV</TYPE>\n"
          f"          <NAME>{srvd_name}</NAME>\n"
          "         </SRVD_REF>\n"
          "         <BIND_TYPE_DATA>\n          <CONTENT>\n"
          "           <ENCODING>base64</ENCODING>\n"
          "          </CONTENT>\n         </BIND_TYPE_DATA>\n"
          "        </item>\n       </SERVICE_CONTENT>\n"
          "      </item>\n     </SERVICES>\n"
          "    </CONTENT>\n"
          "    <CONTRACT>C1</CONTRACT>\n"
          "    <RELEASE_SUPPORTED>true</RELEASE_SUPPORTED>\n"
          "    <!-- false, not true: this binding has never been published in the\n"
          "         target tenant, and the inbound service that backs a published\n"
          "         endpoint is created BY the publish, not by the import. Claiming\n"
          "         PUBLISHED on import leaves the tenant looking for an inbound\n"
          "         service (ZSB_EDOC_AP_0001_G4BA and friends) that nothing ever\n"
          "         created, and Local Publish fails with 'does not exist'. -->\n"
          "    <PUBLISHED>false</PUBLISHED>\n"
          "    <BINDING_CREATED>false</BINDING_CREATED>\n"
          "   </SRVB>\n"))


# The Sales cockpit: one UI service over the transactional BO.
srvd("ZSD_EINV_DOC", "Service Definition for the Sales e-Invoice Cockpit",
     [("ZCDS_CUN_EINV_DOC", "EInvoice"),
      ("ZCDS_CUN_EINV_DOC_ERR", "EInvoiceError"),
      ("ZCDS_CUN_EINV_DOC_STAT", "EInvoiceExchange"),
      ("ZVH_EINV_COMPANYCODE", "VHCompanyCode"),
      ("ZVH_EINV_STATUS", "VHStatus"),
      # The seller action's two values come from the fixed-value domain of
      # ZDE_EINV_SELLER_ACT (dynpro 0200 hard-coded them); what this service
      # needs exposed is the reason-code help of the cancellation action.
      ("ZVH_EINV_REASONCODE", "VHReasonCode"),
      ("ZVH_EINV_PROJECT", "VHProject")])
srvb("ZSB_EINV_DOC", "Service Binding for the Sales e-Invoice Cockpit", "ZSD_EINV_DOC")

# The configuration group: one UI service over all ten customizing BOs,
# replacing /CLR/EINV_CONFIG and its twelve CALL TRANSACTION branches to SM30.
srvd("ZSD_EINV_CONFIG", "Service Definition for e-Invoice Configuration",
     [("ZCDS_CUN_EINV_CNTRY", "CountryRegistration"),
      ("ZCDS_CUN_EINV_API", "ApiEndpoint"),
      ("ZCDS_CUN_EINV_CONST", "Constant"),
      ("ZCDS_CUN_EINV_INVMAP", "RelevanceMapping"),
      ("ZCDS_CUN_EINV_DOCTYP", "DocumentType"),
      ("ZCDS_CUN_EINV_STATUS", "StatusMapping"),
      ("ZCDS_CUN_EINV_VAT", "VatRegistration"),
      ("ZCDS_CUN_EINV_ACTION", "ActionType"),
      ("ZCDS_CUN_EINV_REASON", "ReasonCode"),
      ("ZCDS_CUN_EINV_STATTX", "StatusText"),
      ("ZVH_EINV_COUNTRY", "VHCountry"),
      ("ZVH_EINV_COMPANYCODE", "VHCompanyCode"),
      ("ZVH_EINV_BILLINGTYPE", "VHBillingType"),
      ("ZVH_EINV_ACCDOCTYPE", "VHAccDocType"),
      ("ZVH_EINV_ACTIONTYPE", "VHActionType"),
      ("ZVH_EINV_STATUS", "VHStatus"),
      ("ZVH_EINV_REASONCODE", "VHReasonCode"),
      ("ZVH_EINV_PROJECT", "VHProject")])
srvb("ZSB_EINV_CONFIG", "Service Binding for e-Invoice Configuration", "ZSD_EINV_CONFIG")


# ========================================================= message class ====
# Numbers 000-022 keep the meaning they had in /CLR/ZME_EINV wherever the
# original message still applies, so existing operational runbooks and the
# HANA source comments stay readable side by side.
MESSAGES = [
    ("000", "e-Invoice submitted successfully"),
    ("001", "Document is not relevant for e-Invoicing"),
    ("002", "Company code &1 has no e-Invoice country registration"),
    ("003", "e-Invoice is already generated"),
    ("004", "e-Invoice is already submitted"),
    ("005", "No Clear platform document ID available for this document"),
    ("006", "Endpoint &1 is not maintained in ZTEINV_API"),
    ("007", "Authentication token is not maintained in ZTELT_CONFIG"),
    ("008", "Clear platform returned HTTP &1 &2"),
    ("009", "Presigned upload URL is not maintained"),
    ("010", "Command not found - expected DATA_EXTRACTION, received &1"),
    ("011", "Extraction produced no file"),
    ("015", "Enter at least one date range or a document number"),
    ("016", "&1 relevant document(s) found"),
    ("017", "&1 new worklist entry/entries created"),
    ("018", "Select at least one document"),
    ("020", "Source document &1 is already cancelled or reversed"),
    ("021", "Printout for document &1 is available for download"),
    ("022", "A collection date is required for CONFIRM_PAYMENT"),
    ("023", "e-Invoice cannot be cancelled more than &1 hours after creation"),
    ("024", "e-Invoice is already cancelled"),
    ("025", "Status refreshed for &1 document(s)"),
    ("030", "Enter an action type"),
    ("031", "Action type &1 is not configured for &2"),
    ("032", "Enter a reason code for action &1"),
    ("033", "Reason code &1 is not valid for action &2"),
    ("034", "No company code found for VAT &1"),
    ("035", "&1 document(s) fetched, &2 new"),
    ("036", "Detail fetch is not implemented - see ZCL_EINV_EDOC_FETCH"),
    ("037", "Document no longer exists or is not visible to you"),
    ("038", "&1 document(s) submitted immediately after pick-up"),
]
inner = ("   <T100A>\n"
         "    <ARBGB>ZEINV_MSG</ARBGB>\n"
         "    <MASTERLANG>E</MASTERLANG>\n"
         "    <STEXT>e-Invoice ELT Messages</STEXT>\n"
         "   </T100A>\n"
         "   <T100>\n")
for num, txt in MESSAGES:
    inner += ("    <T100>\n"
              "     <SPRSL>E</SPRSL>\n"
              "     <ARBGB>ZEINV_MSG</ARBGB>\n"
              f"     <MSGNR>{num}</MSGNR>\n"
              f"     <TEXT>{esc(txt)}</TEXT>\n"
              "    </T100>\n")
inner += "   </T100>\n"
write("zeinv_msg.msag.xml", git("LCL_OBJECT_MSAG", inner))


# ================================================ APJ jobs (catalog / log) ==
def sajc(name, desc, classname, params=None):
    doc = {
        "formatVersion": "1",
        "header": {"description": desc,
                   "originalLanguage": "en",
                   "abapLanguageVersion": "cloudDevelopment"},
        "generalInformation": {"className": classname},
    }
    # No sections / groups / parameters block. The only job catalog entries
    # known to activate in this tenant - ZAJC_ELT_EXECUTE_COMMAND and
    # ZAJC_INSTRU_EXEC, both inherited from ZZCLR_ELT - carry `className` and
    # nothing else, and the selection screen comes from the class's
    # if_apj_dt_exec_object~get_parameters at runtime, not from this file.
    # `params` is kept in the signature so the call sites still document which
    # parameters each job offers.
    _ = params
    import json
    write(f"{name.lower()}.sajc.json", json.dumps(doc, indent=2) + "\n")


def sajt(name, desc, catalog):
    import json
    write(f"{name.lower()}.sajt.json", json.dumps({
        "formatVersion": "1",
        "header": {"description": desc,
                   "originalLanguage": "en",
                   "abapLanguageVersion": "cloudDevelopment"},
        # `catalogName`, not `catalogEntry`. With the wrong key the field
        # is simply absent and the tenant answers "Job catalog entry  
        # doesn't exist." with an empty name and no object to point at.
        # The two templates inherited from ZZCLR_ELT, which activate,
        # are what settled the spelling.
        "generalInformation": {"catalogName": catalog},
    }, indent=2) + "\n")


sajc("ZAJC_EINV_PICKUP", "Application Job Catalog for e-Invoice Pick-Up",
     "ZCL_EINV_PICKUP_JOB",
     ["P_BUKRS", "P_PROJID", "P_BUDAT_F", "P_BUDAT_T",
      "P_CPUDT_F", "P_CPUDT_T", "P_SUBMIT"])
sajt("ZAJT_EINV_PICKUP", "Job Template for e-Invoice Pick-Up", "ZAJC_EINV_PICKUP")

sajc("ZAJC_EINV_SUBMIT", "Application Job Catalog for e-Invoice Submission",
     "ZCL_EINV_SUBMIT_JOB", ["P_BUKRS", "P_MAXROWS"])
sajt("ZAJT_EINV_SUBMIT", "Job Template for e-Invoice Submission", "ZAJC_EINV_SUBMIT")

sajc("ZAJC_EINV_STATUS", "Application Job Catalog for e-Invoice Status Refresh",
     "ZCL_EINV_STATUS_JOB", ["P_BUKRS", "P_MAXROWS"])
sajt("ZAJT_EINV_STATUS", "Job Template for e-Invoice Status Refresh", "ZAJC_EINV_STATUS")

import json
sajc("ZAJC_EINV_FETCH", "Application Job Catalog for e-Document Fetch",
     "ZCL_EINV_EDOC_FETCH_JOB",
     ["P_BUKRS", "P_TYPE", "P_SDATE", "P_EDATE", "P_ADHOC"])
sajt("ZAJT_EINV_FETCH", "Job Template for e-Document Fetch", "ZAJC_EINV_FETCH")

write("zajl_einv_execution.aplo.json", json.dumps({
    "formatVersion": "1",
    "header": {"description": "Application Job Log for e-Invoice Execution",
               "originalLanguage": "en",
               "abapLanguageVersion": "cloudDevelopment"},
    "subobjects": [
        {"name": "JOB_LOG_PICKUP", "description": "Job Log for e-Invoice Pick-Up"},
        {"name": "JOB_LOG_SUBMIT", "description": "Job Log for e-Invoice Submission"},
        {"name": "JOB_LOG_STATUS", "description": "Job Log for e-Invoice Status Refresh"},
        {"name": "JOB_LOG_FETCH", "description": "Job Log for e-Document Fetch"},
    ],
}, indent=2) + "\n")


# ========================================================== package / repo ===
write("package.devc.xml", git("LCL_OBJECT_DEVC",
      "   <DEVC>\n"
      "    <CTEXT>Clear e-Invoice ELT Package (Public Cloud)</CTEXT>\n"
      "    <LANGUAGE>E</LANGUAGE>\n"
      "    <MASTERLANG>E</MASTERLANG>\n"
      "    <SRV_CHECK>X</SRV_CHECK>\n"
      "   </DEVC>\n"))

with open(os.path.join(ROOT, ".abapgit.xml"), "w", encoding="utf-8", newline="\n") as f:
    f.write(BOM + HDR
            + '<asx:abap xmlns:asx="http://www.sap.com/abapxml" version="1.0">\n'
              ' <asx:values>\n'
              '  <DATA>\n'
              '   <MASTER_LANGUAGE>E</MASTER_LANGUAGE>\n'
              '   <STARTING_FOLDER>/src/</STARTING_FOLDER>\n'
              '   <FOLDER_LOGIC>FULL</FOLDER_LOGIC>\n'
              '   <IGNORE>\n'
              '    <item>/.gitignore</item>\n'
              '    <item>/LICENSE</item>\n'
              '    <item>/README.md</item>\n'
              '    <item>/CONVERSION_DESIGN.md</item>\n'
              '    <item>/package.json</item>\n'
              '    <item>/.travis.yml</item>\n'
              '    <item>/.gitlab-ci.yml</item>\n'
              '    <item>/abaplint.json</item>\n'
              '    <item>/azure-pipelines.yml</item>\n'
              '   </IGNORE>\n'
              '  </DATA>\n'
              ' </asx:values>\n'
              '</asx:abap>\n')


# ---------------------------------------------------------------- IAM apps --
# An application job catalog entry is only reachable once it is registered as
# an IAM app of type SAJC. The two inherited jobs each have one
# (ZAJC_ELT_EXECUTE_COMMAND_SAJC, ZAJC_INSTRU_EXEC_SAJC); the four generated
# here had none, so nothing in the tenant could resolve them by name.
#
# The file is fully determined - no platform hash anywhere in it, unlike the
# business catalog, whose CHIP_ID is generated and which therefore still has
# to be created in ADT (see CONVERSION_DESIGN.md §23).
def sia6_job(catalog):
    name = f"{catalog}_SAJC"
    write(f"{name.lower()}.sia6.xml",
          '<?xml version="1.0" encoding="utf-8"?>\n'
          '<abapGit version="v1.0.0" serializer="LCL_OBJECT_SIA6" serializer_version="v1.0.0">\n'
          ' <asx:abap xmlns:asx="http://www.sap.com/abapxml" version="1.0">\n'
          '  <asx:values>\n'
          '   <SIA6>\n'
          '    <MAIN_OBJECT>\n'
          f'     <NAME>{name}</NAME>\n'
          '     <TYPE>SIA6</TYPE>\n'
          f'     <DESCRIPTION>IAM APP:{name}</DESCRIPTION>\n'
          '     <MASTER_LANGUAGE>EN</MASTER_LANGUAGE>\n'
          '     <PACKAGE_REF>\n'
          '      <PACKAGE_NAME>ZZCLR_GEINV</PACKAGE_NAME>\n'
          '     </PACKAGE_REF>\n'
          '     <ABAP_LANGU_VERSION>5</ABAP_LANGU_VERSION>\n'
          '    </MAIN_OBJECT>\n'
          f'    <APP_ID>{name}</APP_ID>\n'
          '    <APP_TYPE>SAJC</APP_TYPE>\n'
          '    <ABAP_LANGUAGE_VERSION>5</ABAP_LANGUAGE_VERSION>\n'
          f'    <SECONDARY_ID>{catalog}</SECONDARY_ID>\n'
          '    <PUBLISH_STATUS>u</PUBLISH_STATUS>\n'
          '   </SIA6>\n'
          '  </asx:values>\n'
          ' </asx:abap>\n'
          '</abapGit>\n')


for _c in ("ZAJC_EINV_PICKUP", "ZAJC_EINV_SUBMIT", "ZAJC_EINV_STATUS", "ZAJC_EINV_FETCH"):
    sia6_job(_c)

print("wrappers, services, messages, jobs and descriptors written to", OUT)
