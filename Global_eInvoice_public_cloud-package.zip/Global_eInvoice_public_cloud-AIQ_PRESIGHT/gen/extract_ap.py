#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Extract the full /CLR/EINV_ELT_AP model from the HANA export, enriched with the
labels, UBL XPaths and BT codes of the companion mapping workbook.

The XML is authoritative for structure and typing; the workbook is authoritative
for what each field MEANS. Neither alone is enough: the export carries no XPath
and the workbook carries no reference-field wiring.
"""
import glob, json, os, re
import openpyxl

HANA = ("/tmp/claude-0/-home-claude/72239396-9680-5f1b-b64f-4de20ad4c92c/"
        "scratchpad/ap_new/einv_elt_ap/src")
XLSX = ("/root/.claude/uploads/72239396-9680-5f1b-b64f-4de20ad4c92c/"
        "3560e0d4-EINV_ELT_AP_Table_XML_Mapping.xlsx")

def rd(p): return open(p, encoding="utf-8-sig", errors="replace").read()

# ----------------------------------------------------------------- domains --
doma = {}
for f in glob.glob(os.path.join(HANA, "*.doma.xml")):
    b = rd(f)
    n = re.search(r"<DOMNAME>([^<]*)", b)
    if not n: continue
    g = lambda t, d=None: (re.search(rf"<{t}>([^<]*)", b).group(1)
                           if re.search(rf"<{t}>([^<]*)", b) else d)
    fixed = [(m.group(1), m.group(2)) for m in
             re.finditer(r"<DD07V>.*?<DOMVALUE_L>([^<]*)</DOMVALUE_L>.*?"
                         r"<DDTEXT>([^<]*)</DDTEXT>.*?</DD07V>", b, re.S)]
    doma[n.group(1).upper()] = dict(
        name=n.group(1).upper(), datatype=g("DATATYPE"),
        leng=int(g("LENG", "0")), decimals=int(g("DECIMALS", "0")),
        text=g("DDTEXT", ""), lowercase=bool(re.search(r"<LOWERCASE>X", b)),
        fixed=fixed)

# ----------------------------------------------------------- data elements --
dtel = {}
for f in glob.glob(os.path.join(HANA, "*.dtel.xml")):
    b = rd(f)
    n = re.search(r"<ROLLNAME>([^<]*)", b)
    if not n: continue
    g = lambda t, d="": (re.search(rf"<{t}>([^<]*)", b).group(1)
                         if re.search(rf"<{t}>([^<]*)", b) else d)
    dtel[n.group(1).upper()] = dict(
        name=n.group(1).upper(), domain=g("DOMNAME").upper(),
        text=g("DDTEXT"), short=g("SCRTEXT_S"), med=g("SCRTEXT_M"),
        long=g("SCRTEXT_L"), head=g("REPTEXT"))

# ------------------------------------------------------------------ tables --
tables = {}
for f in sorted(glob.glob(os.path.join(HANA, "*.tabl.xml"))):
    b = rd(f)
    tn = re.search(r"<TABNAME>([^<]*)", b)
    if not tn: continue
    tn = tn.group(1).upper()
    txt = re.search(r"<DDTEXT>([^<]*)", b)
    fields = []
    for r in re.findall(r"<DD03P>(.*?)</DD03P>", b, re.S):
        fn = re.search(r"<FIELDNAME>([^<]*)", r)
        if not fn: continue
        rn = re.search(r"<ROLLNAME>([^<]*)", r)
        rf = re.search(r"<REFFIELD>([^<]*)", r)
        rt = re.search(r"<REFTABLE>([^<]*)", r)
        fields.append(dict(field=fn.group(1).upper(),
                           key="<KEYFLAG>X</KEYFLAG>" in r,
                           roll=(rn.group(1).upper() if rn else None),
                           reftable=(rt.group(1).upper() if rt else None),
                           reffield=(rf.group(1).upper() if rf else None)))
    tables[tn] = dict(name=tn, text=(txt.group(1) if txt else ""), fields=fields)

# --------------------------------------------------------------- workbook ---
wb = openpyxl.load_workbook(XLSX, data_only=True)
SHEETS = {"EINV_ELTAPH": "/CLR/EINV_ELTAPH", "EINV_ELTAPI": "/CLR/EINV_ELTAPI",
          "EINV_ELTAPP": "/CLR/EINV_ELTAPP", "EINV_ELTAPA": "/CLR/EINV_ELTAPA",
          "EINV_ELTAPT": "/CLR/EINV_ELTAPT", "EINV_ELTAPN": "/CLR/EINV_ELTAPN",
          "EINV_ELTAPR": "/CLR/EINV_ELTAPR", "EINV_ELTAPX": "/CLR/EINV_ELTAPX"}
meta = {}
for sheet, tab in SHEETS.items():
    ws = wb[sheet]
    hdr = [str(c.value or "") for c in ws[1]]
    ix = {h: i for i, h in enumerate(hdr)}
    for row in ws.iter_rows(min_row=2, values_only=True):
        fld = row[ix["Field"]]
        if not fld: continue
        meta[(tab, str(fld).upper())] = dict(
            desc=str(row[ix["Description"]] or ""),
            xpath=str(row[ix["XML XPath (UBL 2.1)"]] or ""),
            rule=str(row[ix["Transformation / rule"]] or ""),
            sample=str(row[ix["Sample value (CTX-HANA-AP-2)"]] or ""),
            old=str(row[ix['Replaces (old APHEAD/APITEM)']] or ""))

# fixed values documented in the workbook rather than in the domain XML
roles = {}
for row in wb["Roles & Types"].iter_rows(min_row=2, values_only=True):
    if row[0] and str(row[0]).startswith("/CLR/"):
        roles.setdefault(str(row[0]).upper(), []).append(
            (str(row[1]), str(row[2])))

spec = dict(domains=doma, dtels=dtel, tables=tables,
            meta={f"{k[0]}|{k[1]}": v for k, v in meta.items()}, roles=roles)
json.dump(spec, open("/home/claude/gen/ap_spec.json", "w"), indent=1)

print(f"domains {len(doma)}  data elements {len(dtel)}  tables {len(tables)}")
print(f"workbook field notes {len(meta)}  fixed-value lists {len(roles)}")
for t in sorted(tables):
    n_meta = sum(1 for k in meta if k[0] == t)
    print(f"  {t:22s} {len(tables[t]['fields']):4d} fields, {n_meta:4d} documented")
# every data element a table uses must exist, or be a standard SAP one
missing = sorted({f["roll"] for t in tables.values() for f in t["fields"]
                  if f["roll"] and f["roll"] not in dtel})
print("standard SAP data elements referenced:", missing)
