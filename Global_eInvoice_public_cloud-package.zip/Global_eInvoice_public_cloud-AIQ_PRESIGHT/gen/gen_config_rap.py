#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generator for the configuration RAP stack of ZZCLR_EINVOICE_ELT.

For each configuration table it emits, following the ZZCLR_ELT conventions:
  ZCDS_INT_<n>          interface root view entity          (.ddls.asddls/.xml/.baseinfo)
  ZCDS_CUN_<n>          consumption projection view         (.ddls.*)
  ZCDS_INT_<n>.bdef     base behaviour definition (managed) (.bdef.asbdef/.xml)
  ZCDS_CUN_<n>.bdef     projection behaviour definition     (.bdef.asbdef/.xml)
  ZBP_CDS_INT_<n>       behaviour implementation class      (.clas.abap/.xml/.locals_imp.abap)
  ZBP_CDS_CUN_<n>       projection implementation class     (.clas.*)
  ZCDS_MET_<n>          metadata extension                  (.ddlx.asddlxs/.xml)
"""
import os

OUT = os.environ.get("EINV_OUT", "/home/claude/ZZCLR_EINVOICE_ELT/src")
os.makedirs(OUT, exist_ok=True)
BOM = "﻿"
HDR = '<?xml version="1.0" encoding="utf-8"?>\n'

# Key fields that may legitimately be left blank. In the on-premise data
# model a blank key is the "any" wildcard used by the relevance
# determination, so flagging these mandatory would make rows the old
# system depends on impossible to enter. They stay keys and stay
# readonly on update - only the mandatory-on-create flag is dropped.
# Keyed by database table -> CDS element names.
OPTIONAL_KEYS = {
    "zteinv_invmap": {"BillingDocumentType", "AccountingDocumentType",
                      "DocumentTypeCode"},
}


def write(name, body):
    with open(os.path.join(OUT, name), "w", encoding="utf-8", newline="\n") as f:
        f.write(body)


def git(serializer, inner, sv="v1.0.0"):
    return (BOM + HDR
            + f'<abapGit version="v1.0.0" serializer="{serializer}" serializer_version="{sv}">\n'
            ' <asx:abap xmlns:asx="http://www.sap.com/abapxml" version="1.0">\n'
            '  <asx:values>\n' + inner
            + '  </asx:values>\n </asx:abap>\n</abapGit>\n')


# --------------------------------------------------------------- wrappers ----
def ddls_xml(name, text):
    inner = ("   <DDLS>\n"
             f"    <DDLNAME>{name}</DDLNAME>\n"
             "    <DDLANGUAGE>E</DDLANGUAGE>\n"
             f"    <DDTEXT>{text}</DDTEXT>\n"
             "    <SOURCE_TYPE>W</SOURCE_TYPE>\n"
             "   </DDLS>\n")
    write(f"{name.lower()}.ddls.xml", git("LCL_OBJECT_DDLS", inner))


def ddls_baseinfo(name, from_list, assoc_list=None):
    assoc_list = assoc_list or []
    def arr(items):
        if not items:
            return "[]"
        return "[\n" + ",\n".join(f'"{i}"' for i in items) + "\n]"
    body = ('{\n"BASEINFO":\n{\n"FROM":\n' + arr(from_list)
            + ',\n"ASSOCIATED":\n' + arr(assoc_list)
            + ',\n"BASE":\n[],\n"ANNO_REF":\n[],\n"SCALAR_FUNCTION":\n[],\n'
              '"VERSION":0,\n"ANNOREF_EVALUATION_ERROR":""\n}\n}\n')
    write(f"{name.lower()}.ddls.baseinfo", body)


def bdef_xml(name, text):
    inner = ("   <BDEF>\n"
             f"    <NAME>{name}</NAME>\n"
             "    <TYPE>BDEF/BDO</TYPE>\n"
             f"    <DESCRIPTION>{text}</DESCRIPTION>\n"
             "    <DESCRIPTION_TEXT_LIMIT>60</DESCRIPTION_TEXT_LIMIT>\n"
             "    <LANGUAGE>EN</LANGUAGE>\n"
             "    <MASTER_LANGUAGE>EN</MASTER_LANGUAGE>\n"
             "    <ABAP_LANGU_VERSION>5</ABAP_LANGU_VERSION>\n"
             f"    <SOURCE_URI>./{name.lower()}/source/main</SOURCE_URI>\n"
             "    <SOURCE_TYPE>ABAP_SOURCE</SOURCE_TYPE>\n"
             "    <SOURCE_FIXED_POINT_ARITHMETIC>true</SOURCE_FIXED_POINT_ARITHMETIC>\n"
             "    <SOURCE_UNICODE_CHECKS_ACTIVE>true</SOURCE_UNICODE_CHECKS_ACTIVE>\n"
             "   </BDEF>\n")
    write(f"{name.lower()}.bdef.xml", git("LCL_OBJECT_BDEF", inner))


def clas_xml(name, text, defint=None, category=None):
    inner = ("   <VSEOCLASS>\n"
             f"    <CLSNAME>{name}</CLSNAME>\n"
             "    <LANGU>E</LANGU>\n"
             f"    <DESCRIPT>{text}</DESCRIPT>\n")
    if category:
        inner += f"    <CATEGORY>{category}</CATEGORY>\n"
    inner += ("    <STATE>1</STATE>\n"
              "    <CLSCCINCL>X</CLSCCINCL>\n"
              "    <FIXPT>X</FIXPT>\n"
              "    <UNICODE>X</UNICODE>\n")
    if defint:
        inner += f"    <CLSDEFINT>{defint}</CLSDEFINT>\n"
    inner += ("    <ABAP_LANGUAGE_VERSION>5</ABAP_LANGUAGE_VERSION>\n"
              "   </VSEOCLASS>\n")
    write(f"{name.lower()}.clas.xml", git("LCL_OBJECT_CLAS", inner))


def ddlx_xml(name, text):
    inner = ("   <DDLX>\n    <METADATA>\n"
             f"     <NAME>{name}</NAME>\n"
             f"     <DESCRIPTION>{text}</DESCRIPTION>\n"
             "     <MASTER_LANGUAGE>EN</MASTER_LANGUAGE>\n"
             "    </METADATA>\n   </DDLX>\n")
    write(f"{name.lower()}.ddlx.xml", git("LCL_OBJECT_DDLX", inner))


def lab40(t):
    """@EndUserText.label is typed STRING(40). Anything longer is rejected
    outright by the activation, so the cap is applied at the one place that
    writes the annotation rather than trusted to whoever writes the spec."""
    t = (t or "").replace("'", "")
    if len(t) <= 40:
        return t
    cut = t[:40]
    # never leave a half-open parenthesis behind
    if cut.count("(") > cut.count(")"):
        cut = cut[:cut.rfind("(")]
    return cut.rstrip(" -,/(")


# ------------------------------------------------------------------ spec -----
# fields: (db_field, CdsName, Label, is_key, value_help_or_None)
CFG = [
    dict(
        suffix="EINV_CNTRY", table="zteinv_cntry",
        text="e-Invoice Country / Company Registration",
        plural="Country Registrations", single="Country Registration",
        fields=[
            ("projectid", "ProjectId", "Project ID", True, None),
            ("sysid", "SystemId", "System ID", True, None),
            ("land1", "Country", "Country", True, "ZVH_EINV_COUNTRY"),
            ("bukrs", "CompanyCode", "Company Code", True, "ZVH_EINV_COMPANYCODE"),
            ("sequence", "Sequence", "Sequence", True, None),
            ("vat", "VatRegistrationNumber", "VAT Number", False, None),
            ("land1_desc", "CountryDescription", "Country Description", False, None),
            ("auto_einv_generate", "AutoGenerate", "Auto Generate", False, None),
            ("auto_einv_cancel", "AutoCancel", "Auto Cancel", False, None),
            ("handler_class", "HandlerClass", "Handler Class", False, None),
        ]),
    dict(
        suffix="EINV_API", table="zteinv_api",
        text="e-Invoice API Endpoint Registry",
        plural="API Endpoints", single="API Endpoint",
        fields=[
            ("projectid", "ProjectId", "Project ID", True, None),
            ("sysid", "SystemId", "System ID", True, None),
            ("land1", "Country", "Country", True, "ZVH_EINV_COUNTRY"),
            ("bukrs", "CompanyCode", "Company Code", True, "ZVH_EINV_COMPANYCODE"),
            ("functionality", "Functionality", "Functionality", True, None),
            ("sequence", "Sequence", "Sequence", True, None),
            ("url", "EndpointUrl", "Endpoint URL", False, None),
            ("param_name", "ParameterName", "Header Name", False, None),
            ("param_value", "ParameterValue", "Header Value", False, None),
        ]),
    dict(
        suffix="EINV_CONST", table="zteinv_const",
        text="e-Invoice Generic Constants",
        plural="Constants", single="Constant",
        fields=[
            ("projectid", "ProjectId", "Project ID", True, None),
            ("sysid", "SystemId", "System ID", True, None),
            ("product", "Product", "Product", True, None),
            ("land1", "Country", "Country", True, "ZVH_EINV_COUNTRY"),
            ("bukrs", "CompanyCode", "Company Code", True, "ZVH_EINV_COMPANYCODE"),
            # LABEL is a reserved word in CDS - the element cannot be called
            # that, whatever the column is called.
            ("zlabel", "LabelCode", "Label", True, None),
            ("sequence", "Sequence", "Sequence", True, None),
            ("low", "LowValue", "Low", False, None),
            ("high", "HighValue", "High", False, None),
        ]),
    dict(
        suffix="EINV_INVMAP", table="zteinv_invmap",
        text="e-Invoice Document Relevance Mapping",
        plural="Relevance Mappings", single="Relevance Mapping",
        fields=[
            ("projectid", "ProjectId", "Project ID", True, None),
            ("sysid", "SystemId", "System ID", True, None),
            ("land1", "Country", "Country", True, "ZVH_EINV_COUNTRY"),
            ("bukrs", "CompanyCode", "Company Code", True, "ZVH_EINV_COMPANYCODE"),
            ("fkart", "BillingDocumentType", "Billing Type", True, "ZVH_EINV_BILLINGTYPE"),
            ("blart", "AccountingDocumentType", "Accounting Doc. Type", True,
             "ZVH_EINV_ACCDOCTYPE"),
            ("doc_type", "DocumentTypeCode", "Document Type Code", True, None),
            ("einvoice", "IsEInvoiceRelevant", "e-Invoice", False, None),
            ("ewaybill", "IsEWayBillRelevant", "e-Way Bill", False, None),
            ("nonirn", "IsNonIrn", "Non-IRN", False, None),
            ("no_acc", "HasNoAccountingDoc", "No Accounting Doc.", False, None),
            ("b2c", "IsB2C", "B2C", False, None),
            ("purchase", "IsPurchase", "Purchase", False, None),
        ]),
    dict(
        suffix="EINV_DOCTYP", table="zteinv_doctyp",
        text="e-Invoice Document Type Codes",
        plural="Document Types", single="Document Type",
        fields=[
            ("projectid", "ProjectId", "Project ID", True, None),
            ("sysid", "SystemId", "System ID", True, None),
            ("land1", "Country", "Country", True, "ZVH_EINV_COUNTRY"),
            ("bukrs", "CompanyCode", "Company Code", True, "ZVH_EINV_COMPANYCODE"),
            ("transact_type", "TransactionType", "Transaction Type", True, None),
            ("doc_type_code", "DocumentTypeCode", "Document Type Code", True, None),
            ("doc_type_descr", "DocumentTypeDescription", "Description", False, None),
        ]),
    dict(
        suffix="EINV_STATUS", table="zteinv_status",
        text="e-Invoice Status Mapping and Criticality",
        plural="Status Mappings", single="Status Mapping",
        fields=[
            ("projectid", "ProjectId", "Project ID", True, None),
            ("sysid", "SystemId", "System ID", True, None),
            ("land1", "Country", "Country", True, "ZVH_EINV_COUNTRY"),
            ("bukrs", "CompanyCode", "Company Code", True, "ZVH_EINV_COMPANYCODE"),
            ("sequence", "Sequence", "Sequence", True, None),
            ("proc_mode", "ProcessingMode", "Processing Mode", True, None),
            ("status", "Status", "Status", False, None),
            ("status_to_be", "TargetStatus", "Target Status", False, None),
            ("status_desc", "StatusDescription", "Description", False, None),
            ("criticality", "Criticality", "Criticality", False, None),
        ]),
    dict(
        suffix="EINV_VAT", table="zteinv_vat",
        text="e-Invoice Company Code VAT Registration",
        plural="VAT Registrations", single="VAT Registration",
        fields=[
            ("projectid", "ProjectId", "Project ID", True, None),
            ("sysid", "SystemId", "System ID", True, None),
            ("land1", "Country", "Country", True, "ZVH_EINV_COUNTRY"),
            ("bukrs", "CompanyCode", "Company Code", True, "ZVH_EINV_COMPANYCODE"),
            ("sequence", "Sequence", "Sequence", True, None),
            ("vat", "VatRegistrationNumber", "VAT Number", False, None),
        ]),
    dict(
        suffix="EINV_ACTION", table="zteinv_action",
        text="e-Invoice Action Types",
        plural="Action Types", single="Action Type",
        fields=[
            ("einv_type", "EInvoiceType", "e-Invoice Type", True, None),
            ("action_type", "ActionType", "Action Type", True, None),
            ("action_description", "ActionDescription", "Description", False, None),
        ]),
    dict(
        suffix="EINV_REASON", table="zteinv_reason",
        text="e-Invoice Reason Codes per Action",
        plural="Reason Codes", single="Reason Code",
        fields=[
            ("action_type", "ActionType", "Action Type", True, "ZVH_EINV_ACTIONTYPE"),
            ("reason_code", "ReasonCode", "Reason Code", True, None),
            ("reason_text", "ReasonText", "Reason Text", False, None),
        ]),
    dict(
        suffix="EINV_STATTX", table="zteinv_stattx",
        text="e-Invoice Status Texts",
        plural="Status Texts", single="Status Text",
        fields=[
            ("status_code", "StatusCode", "Status Code", True, None),
            ("status_text", "StatusText", "Status Text", False, None),
        ]),
]

HEAD_ANNO = """@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: '{label}'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #CUSTOMIZING
}}
"""

for c in CFG:
    intn = f"ZCDS_INT_{c['suffix']}"
    cunn = f"ZCDS_CUN_{c['suffix']}"
    metn = f"ZCDS_MET_{c['suffix']}"
    bpint = f"ZBP_CDS_INT_{c['suffix']}"
    bpcun = f"ZBP_CDS_CUN_{c['suffix']}"

    # ---------------------------------------------------- interface view -----
    lines = []
    for db, cds, _lab, iskey, _vh in c["fields"]:
        lines.append(f"  {'key ' if iskey else ''}{db} as {cds},")
    lines[-1] = lines[-1].rstrip(",")
    src = (HEAD_ANNO.format(label=lab40(f"Interface View for {c['text']}"))
           + f"define root view entity {intn} as select from {c['table']}\n"
           + "{\n" + "\n".join(lines) + "\n}\n")
    write(f"{intn.lower()}.ddls.asddls", src)
    ddls_xml(intn, f"Interface View for {c['text']}"[:60])
    ddls_baseinfo(intn, [c["table"].upper()])

    # -------------------------------------------------- consumption view -----
    lines = []
    selpos = 0
    for db, cds, lab, iskey, vh in c["fields"]:
        lines.append(f"      @EndUserText.label: '{lab40(lab)}'")
        if iskey:
            selpos += 10
            lines.append(f"      @UI.selectionField: [ {{ position: {selpos} }} ]")
        if vh:
            lines.append("      @Consumption.valueHelpDefinition: "
                         f"[ {{ entity: {{ name: '{vh}', element: '{cds}' }} }} ]")
        lines.append(f"      {'key ' if iskey else ''}{cds},")
    lines[-1] = lines[-1].rstrip(",")
    # A projection view that carries a projection BDEF must declare the
    # transactional contract, otherwise the BDEF cannot bind to it and the
    # service exposes the entity read-only.
    src = (HEAD_ANNO.format(label=lab40(f"Consumption View for {c['text']}"))
           + "@Metadata.allowExtensions: true\n"
           + f"define root view entity {cunn}\n"
             f"  provider contract transactional_query\n"
             f"  as projection on {intn}\n"
           + "{\n" + "\n".join(lines) + "\n}\n")
    write(f"{cunn.lower()}.ddls.asddls", src)
    ddls_xml(cunn, f"Consumption View for {c['text']}"[:60])
    ddls_baseinfo(cunn, [intn])

    # ------------------------------------------------------- base BDEF -------
    keys = [f[1] for f in c["fields"] if f[3]]
    # Not every key field is mandatory on create - see OPTIONAL_KEYS.
    mand = [k for k in keys if k not in OPTIONAL_KEYS.get(c["table"], ())]
    mand_line = (f"  field ( mandatory : create ) {', '.join(mand)};\n"
                 if mand else "")
    src = (f"managed implementation in class {bpint.lower()} unique;\n"
           "strict ( 2 );\n\n"
           f"define behavior for {intn} alias {c['suffix'][5:]}\n"
           f"persistent table {c['table']}\n"
           "lock master\n"
           # Both, not just instance: CREATE has no instance to authorize, so
           # it is covered by the global authorization. Declaring only
           # ( instance ) leaves the create of a business object that has
           # `create;` without an authorization contract.
           "authorization master ( instance, global )\n"
           "{\n"
           "  create;\n"
           "  update;\n"
           "  delete;\n\n"
           + mand_line
           + f"  field ( readonly : update ) {', '.join(keys)};\n\n"
           # RAP resolves a CDS element to its table column by name, so any
           # element aliased away from the column (land1 -> Country) needs an
           # explicit entry here or the behaviour definition will not activate.
           f"  mapping for {c['table']}\n    {{\n"
           + "".join(f"      {cds} = {db};\n" for db, cds, _l, _k, _v in c["fields"])
           + "    }\n"
           "}\n")
    write(f"{intn.lower()}.bdef.asbdef", src)
    bdef_xml(intn, f"Behavior Definition for {c['text']}"[:60])

    # ------------------------------------------------- projection BDEF -------
    src = (f"projection;\n"
           "strict ( 2 );\n\n"
           f"define behavior for {cunn} alias {c['suffix'][5:]}\n"
           "{\n"
           "  use create;\n"
           "  use update;\n"
           "  use delete;\n"
           "}\n")
    write(f"{cunn.lower()}.bdef.asbdef", src)
    bdef_xml(cunn, f"Projection Behavior for {c['text']}"[:60])

    # ------------------------------------------------- handler classes -------
    write(f"{bpint.lower()}.clas.abap",
          f"CLASS {bpint.lower()} DEFINITION PUBLIC ABSTRACT FINAL "
          f"FOR BEHAVIOR OF {intn.lower()}.\n\n"
          "  PROTECTED SECTION.\n  PRIVATE SECTION.\nENDCLASS.\n\n\n\n"
          f"CLASS {bpint} IMPLEMENTATION.\nENDCLASS.\n")
    clas_xml(bpint, f"Behavior Implementation for {intn}"[:60], defint=intn, category="06")
    # The handler addresses the entity by its BDEF ALIAS, not by the CDS
    # entity name, and an instance-authorization handler that leaves RESULT
    # empty denies every operation on every row - the business object would
    # activate and then refuse all access. Both are written out explicitly.
    alias = c["suffix"][5:]
    write(f"{bpint.lower()}.clas.locals_imp.abap",
          f"CLASS lhc_{c['suffix']} DEFINITION INHERITING FROM cl_abap_behavior_handler.\n"
          "  PRIVATE SECTION.\n\n"
          "    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION\n"
          f"      IMPORTING keys REQUEST requested_authorizations FOR {alias}\n"
          "      RESULT result.\n\n"
          "    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION\n"
          f"      IMPORTING REQUEST requested_authorizations FOR {alias}\n"
          "      RESULT result.\n\n"
          f"ENDCLASS.\n\nCLASS lhc_{c['suffix']} IMPLEMENTATION.\n\n"
          "  METHOD get_instance_authorizations.\n"
          "    \" Configuration tables: access is governed by the business\n"
          "    \" catalog assigned to the service binding, so every instance is\n"
          "    \" granted here. RESULT must be filled - an instance\n"
          "    \" authorization handler that returns nothing denies everything.\n"
          "    \" Add company-code or country restrictions here once a\n"
          "    \" restriction field is defined in the IAM business role.\n"
          "    result = VALUE #( FOR ls_key IN keys\n"
          "                      ( %tky    = ls_key-%tky\n"
          "                        %update = if_abap_behv=>auth-allowed\n"
          "                        %delete = if_abap_behv=>auth-allowed ) ).\n"
          "  ENDMETHOD.\n\n\n"
          "  METHOD get_global_authorizations.\n"
          "    \" Covers CREATE, which has no instance to authorize.\n"
          "    result-%create = if_abap_behv=>auth-allowed.\n"
          "    result-%update = if_abap_behv=>auth-allowed.\n"
          "    result-%delete = if_abap_behv=>auth-allowed.\n"
          "  ENDMETHOD.\n\nENDCLASS.\n")

    write(f"{bpcun.lower()}.clas.abap",
          f"CLASS {bpcun.lower()} DEFINITION PUBLIC ABSTRACT FINAL "
          f"FOR BEHAVIOR OF {cunn.lower()}.\n\n"
          "  PROTECTED SECTION.\n  PRIVATE SECTION.\nENDCLASS.\n\n\n\n"
          f"CLASS {bpcun} IMPLEMENTATION.\nENDCLASS.\n")
    clas_xml(bpcun, f"Projection Implementation for {cunn}"[:60], defint=cunn, category="06")

    # ---------------------------------------------- metadata extension -------
    facet_id = c["suffix"] + "_FACET"
    qual = c["suffix"] + "_FIELDS"
    body = [f"@Metadata.layer: #CORE",
            "@UI: { headerInfo: { typeName: '%s',\n"
            "                     typeNamePlural: '%s',\n"
            "                     title: { type: #STANDARD, value: '%s' } } }"
            % (c["single"], c["plural"], c["fields"][0][1]),
            f"annotate entity {cunn}",
            "    with",
            "{",
            f"  @UI.facet: [ {{ id: '{facet_id}',",
            "                 purpose: #STANDARD,",
            "                 type: #IDENTIFICATION_REFERENCE,",
            f"                 label: '{c['single']}',",
            f"                 targetQualifier: '{qual}',",
            "                 position: 10 } ]"]
    for i, (_db, cds, lab, _k, _vh) in enumerate(c["fields"], start=1):
        pos = i * 10
        body.append(f"  @UI: {{ lineItem:       [ {{ position: {pos}, label: '{lab}' }} ],")
        body.append(f"         identification: [ {{ position: {pos}, "
                    f"qualifier: '{qual}', label: '{lab}' }} ] }}")
        body.append(f"  {cds};")
        body.append("")
    body.append("}")
    write(f"{metn.lower()}.ddlx.asddlxs", "\n".join(body) + "\n")
    ddlx_xml(metn, f"Metadata Extension for {c['text']}"[:60])

# ------------------------------------------------------------ value helps ----
VH = [
    ("ZVH_EINV_COUNTRY", "Value Help for e-Invoice Country",
     "ZCDS_INT_EINV_CNTRY", "Country"),
    ("ZVH_EINV_COMPANYCODE", "Value Help for e-Invoice Company Code",
     "ZCDS_INT_EINV_CNTRY", "CompanyCode"),
    ("ZVH_EINV_BILLINGTYPE", "Value Help for Billing Document Type",
     "ZCDS_INT_EINV_INVMAP", "BillingDocumentType"),
    ("ZVH_EINV_ACCDOCTYPE", "Value Help for Accounting Document Type",
     "ZCDS_INT_EINV_INVMAP", "AccountingDocumentType"),
    ("ZVH_EINV_ACTIONTYPE", "Value Help for e-Invoice Action Type",
     "ZCDS_INT_EINV_ACTION", "ActionType"),
    ("ZVH_EINV_STATUS", "Value Help for e-Invoice Status",
     "ZCDS_INT_EINV_STATTX", "StatusCode"),
    ("ZVH_EINV_PROJECT", "Value Help for Clear Project ID",
     "ZCDS_INT_EINV_CNTRY", "ProjectId"),
]
# Reason code is filtered by action type, so it needs both columns rather
# than the single-key shape the others use. This replaces the per-row
# dropdown handles (101,102,... / 201,202,...) of the two HANA cockpits.
write("zvh_einv_reasoncode.ddls.asddls",
      "@AbapCatalog.viewEnhancementCategory: [#NONE]\n"
      "@AccessControl.authorizationCheck: #NOT_REQUIRED\n"
      "@EndUserText.label: 'Value Help: e-Invoice Reason Code'\n"
      "@Metadata.ignorePropagatedAnnotations: true\n"
      "@ObjectModel.dataCategory: #VALUE_HELP\n"
      "@ObjectModel.usageType.dataClass: #CUSTOMIZING\n"
      "@ObjectModel.usageType.serviceQuality: #A\n"
      "@ObjectModel.usageType.sizeCategory: #S\n"
      "@ObjectModel.supportedCapabilities: [#CDS_MODELING_ASSOCIATION_TARGET,\n"
      "                                     #CDS_MODELING_DATA_SOURCE,\n"
      "                                     #SQL_DATA_SOURCE,\n"
      "                                     #VALUE_HELP_PROVIDER,\n"
      "                                     #SEARCHABLE_ENTITY]\n"
      "@ObjectModel.resultSet.sizeCategory: #XS\n\n"
      "define view entity ZVH_EINV_REASONCODE as select from ZCDS_INT_EINV_REASON\n"
      "{\n"
      "  key ActionType,\n"
      "  key ReasonCode,\n"
      "      ReasonText\n"
      "}\n")
ddls_xml("ZVH_EINV_REASONCODE", "Value Help for e-Invoice Reason Code")
ddls_baseinfo("ZVH_EINV_REASONCODE", ["ZCDS_INT_EINV_REASON"])

# The EINV_TYPE key of /CLR/YT_ACTION exists precisely so that the AP and the
# self-billed cockpit offer different action types: the HANA code selected
#   FROM /clr/yt_action WHERE einv_type = 'PURCHASE'     (AP)
#   FROM /clr/yt_action WHERE einv_type = 'SELF_BILLED'  (self-billed)
# An unfiltered value help would offer each cockpit the other one's actions,
# so there is one filtered value help per variant.
ACT_VH = [("ZVH_EINV_ACTTYPE_AP", "PURCHASE",
           "Value Help: Inbound e-Invoice Action Type"),
          ("ZVH_EINV_ACTTYPE_SELF", "SELF_BILLED",
           "Value Help: Self-Billed Action Type")]
for name, einv_type, label in ACT_VH:
    write(f"{name.lower()}.ddls.asddls",
          "@AbapCatalog.viewEnhancementCategory: [#NONE]\n"
          "@AccessControl.authorizationCheck: #NOT_REQUIRED\n"
          f"@EndUserText.label: '{lab40(label)}'\n"
          "@Metadata.ignorePropagatedAnnotations: true\n"
          "@ObjectModel.dataCategory: #VALUE_HELP\n"
          "@ObjectModel.usageType.dataClass: #CUSTOMIZING\n"
          "@ObjectModel.usageType.serviceQuality: #A\n"
          "@ObjectModel.usageType.sizeCategory: #S\n"
          "@ObjectModel.supportedCapabilities: [#CDS_MODELING_ASSOCIATION_TARGET,\n"
          "                                     #CDS_MODELING_DATA_SOURCE,\n"
          "                                     #SQL_DATA_SOURCE,\n"
          "                                     #VALUE_HELP_PROVIDER,\n"
          "                                     #SEARCHABLE_ENTITY]\n"
          "@ObjectModel.resultSet.sizeCategory: #XS\n\n"
          f"define view entity {name} as select from ZCDS_INT_EINV_ACTION\n"
          "{\n"
          "  key ActionType,\n"
          "      ActionDescription\n"
          "}\n"
          "where\n"
          f"  EInvoiceType = '{einv_type}'\n")
    ddls_xml(name, label[:60])
    ddls_baseinfo(name, ["ZCDS_INT_EINV_ACTION"])

for name, label, src_view, keyf in VH:
    body = ("@AbapCatalog.viewEnhancementCategory: [#NONE]\n"
            "@AccessControl.authorizationCheck: #NOT_REQUIRED\n"
            f"@EndUserText.label: '{lab40(label)}'\n"
            "@Metadata.ignorePropagatedAnnotations: true\n"
            "@ObjectModel.dataCategory: #VALUE_HELP\n"
            "@ObjectModel.usageType.dataClass: #CUSTOMIZING\n"
            "@ObjectModel.usageType.serviceQuality: #A\n"
            "@ObjectModel.usageType.sizeCategory: #S\n"
            "@ObjectModel.supportedCapabilities: [#CDS_MODELING_ASSOCIATION_TARGET,\n"
            "                                     #CDS_MODELING_DATA_SOURCE,\n"
            "                                     #SQL_DATA_SOURCE,\n"
            "                                     #VALUE_HELP_PROVIDER,\n"
            "                                     #SEARCHABLE_ENTITY]\n"
            "@ObjectModel.resultSet.sizeCategory: #XS\n\n"
            f"define view entity {name} as select from {src_view}\n"
            "{\n"
            f"  key {keyf}\n"
            "}\n"
            f"group by\n  {keyf}\n")
    write(f"{name.lower()}.ddls.asddls", body)
    ddls_xml(name, label[:60])
    ddls_baseinfo(name, [src_view])

print("config RAP stack written to", OUT)
