#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generator for the normalised e-document stack of ZZCLR_GEINV.

Source: the /CLR/EINV_ELT_AP drop (2026-10-01) plus its mapping workbook,
read by extract_ap.py into ap_spec.json.

What this replaces
------------------
The first conversion carried the HANA AP tables across as they stood: two flat
tables of 262 and 94 columns, with fixed slots for repeating UBL groups
(INV_NOTE..INV_NOTE3, four tax subtotals, one allowance and one charge per
document, ADDITIONAL_DOC_*1/2/3). The new drop normalises that into eight
tables and documents 33 defects in the old shape - truncation, wrong types,
missing UBL elements, and the currency/unit reference wiring that would not
have activated at all.

That is a model change, not a field change, so the flat ZTEINV_APHEAD /
ZTEINV_APITEM / ZTEINV_ARHEAD / ZTEINV_ARITEM stack and everything generated
from it is dropped rather than patched.

Shape
-----
    ZTEDOC_{v}H   invoice header            key UUID                  root
      ZTEDOC_{v}I   invoice line            + LINE_ID
      ZTEDOC_{v}P   parties                 + LINE_ID, PARTY_ROLE
      ZTEDOC_{v}A   allowances and charges  + LINE_ID, SEQ
      ZTEDOC_{v}T   VAT breakdown           + SEQ
      ZTEDOC_{v}N   notes                   + LINE_ID, SEQ
      ZTEDOC_{v}R   document references     + LINE_ID, REF_TYPE, SEQ
      ZTEDOC_{v}X   item attributes         + LINE_ID, ATTR_TYPE, SEQ

{v} is AP (inbound, EINV_TYPE 'PURCHASE') or SB (self-billed, 'SELF_BILLED').

LINE_ID is blank on a document-level row and carries the line number on a
line-level one, so parties, notes, allowances and references serve both levels
from one table - which is why every child hangs off the header on UUID alone.

A note on the self-billed variant
---------------------------------
Only the AP drop was supplied. The self-billed tables are generated from the
same structure because the two are the same UBL document read from the other
side, and the HANA originals were byte-identical. The UBL XPath comments are
therefore accurate for AP and inferred for self-billed: verify them against
the self-billed payload before relying on the mapping.
"""
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _name import camel                                        # noqa: E402

OUT = os.environ.get("EINV_OUT", "/home/claude/ZZCLR_EINVOICE_ELT/src")
SPEC = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                   "ap_spec.json")))
os.makedirs(OUT, exist_ok=True)

BOM = "﻿"
HDR = '<?xml version="1.0" encoding="utf-8"?>\n'


def write(n, b):
    open(os.path.join(OUT, n), "w", encoding="utf-8", newline="\n").write(b)


def esc(t):
    return (t or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def git(ser, inner):
    return (BOM + HDR
            + f'<abapGit version="v1.0.0" serializer="{ser}" serializer_version="v1.0.0">\n'
              ' <asx:abap xmlns:asx="http://www.sap.com/abapxml" version="1.0">\n'
              '  <asx:values>\n' + inner + '  </asx:values>\n </asx:abap>\n</abapGit>\n')


def ddls_xml(n, t):
    write(f"{n.lower()}.ddls.xml", git("LCL_OBJECT_DDLS",
          f"   <DDLS>\n    <DDLNAME>{n}</DDLNAME>\n    <DDLANGUAGE>E</DDLANGUAGE>\n"
          f"    <DDTEXT>{esc(t[:60])}</DDTEXT>\n    <SOURCE_TYPE>W</SOURCE_TYPE>\n   </DDLS>\n"))


def ddls_base(n, frm, assoc=()):
    a = lambda i: "[]" if not i else "[\n" + ",\n".join(f'"{x}"' for x in i) + "\n]"
    write(f"{n.lower()}.ddls.baseinfo",
          '{\n"BASEINFO":\n{\n"FROM":\n' + a(frm) + ',\n"ASSOCIATED":\n' + a(assoc)
          + ',\n"BASE":\n[],\n"ANNO_REF":\n[],\n"SCALAR_FUNCTION":\n[],\n'
            '"VERSION":0,\n"ANNOREF_EVALUATION_ERROR":""\n}\n}\n')


def bdef_xml(n, t):
    write(f"{n.lower()}.bdef.xml", git("LCL_OBJECT_BDEF",
          f"   <BDEF>\n    <NAME>{n}</NAME>\n    <TYPE>BDEF/BDO</TYPE>\n"
          f"    <DESCRIPTION>{esc(t[:60])}</DESCRIPTION>\n"
          "    <DESCRIPTION_TEXT_LIMIT>60</DESCRIPTION_TEXT_LIMIT>\n"
          "    <LANGUAGE>EN</LANGUAGE>\n    <MASTER_LANGUAGE>EN</MASTER_LANGUAGE>\n"
          "    <ABAP_LANGU_VERSION>5</ABAP_LANGU_VERSION>\n"
          f"    <SOURCE_URI>./{n.lower()}/source/main</SOURCE_URI>\n"
          "    <SOURCE_TYPE>ABAP_SOURCE</SOURCE_TYPE>\n"
          "    <SOURCE_FIXED_POINT_ARITHMETIC>true</SOURCE_FIXED_POINT_ARITHMETIC>\n"
          "    <SOURCE_UNICODE_CHECKS_ACTIVE>true</SOURCE_UNICODE_CHECKS_ACTIVE>\n   </BDEF>\n"))


def clas_xml(n, t, defint=None, cat=None):
    i = (f"   <VSEOCLASS>\n    <CLSNAME>{n}</CLSNAME>\n    <LANGU>E</LANGU>\n"
         f"    <DESCRIPT>{esc(t[:60])}</DESCRIPT>\n")
    if cat:
        i += f"    <CATEGORY>{cat}</CATEGORY>\n"
    i += ("    <STATE>1</STATE>\n    <CLSCCINCL>X</CLSCCINCL>\n"
          "    <FIXPT>X</FIXPT>\n    <UNICODE>X</UNICODE>\n")
    if defint:
        i += f"    <CLSDEFINT>{defint}</CLSDEFINT>\n"
    i += "    <ABAP_LANGUAGE_VERSION>5</ABAP_LANGUAGE_VERSION>\n   </VSEOCLASS>\n"
    write(f"{n.lower()}.clas.xml", git("LCL_OBJECT_CLAS", i))


def ddlx_xml(n, t):
    write(f"{n.lower()}.ddlx.xml", git("LCL_OBJECT_DDLX",
          f"   <DDLX>\n    <METADATA>\n     <NAME>{n}</NAME>\n"
          f"     <DESCRIPTION>{esc(t[:60])}</DESCRIPTION>\n"
          "     <MASTER_LANGUAGE>EN</MASTER_LANGUAGE>\n    </METADATA>\n   </DDLX>\n"))


def srvd(name, text, exposes):
    # @EndUserText.label is STRING(40) on a service definition too
    b = f"@EndUserText.label: '{(text or '')[:40].rstrip(' -,/(')}'\ndefine service {name} {{\n"
    for e, a in exposes:
        b += f"  expose {e} as {a};\n"
    write(f"{name.lower()}.srvd.srvdsrv", b + "}\n")
    write(f"{name.lower()}.srvd.xml", git("LCL_OBJECT_SRVD",
          f"   <SRVD>\n    <NAME>{name}</NAME>\n    <TYPE>SRVD/SRV</TYPE>\n"
          f"    <DESCRIPTION>{esc(text[:60])}</DESCRIPTION>\n    <LANGUAGE>EN</LANGUAGE>\n"
          "    <MASTER_LANGUAGE>EN</MASTER_LANGUAGE>\n"
          f"    <SOURCE_URI>./{name.lower()}/source/main</SOURCE_URI>\n"
          "    <SOURCE_TYPE>ABAP_SOURCE</SOURCE_TYPE>\n"
          "    <SOURCE_ORIGIN_DESCRIPTION>ABAP Development Tools</SOURCE_ORIGIN_DESCRIPTION>\n"
          "    <SRVD_SOURCE_TYPE>S</SRVD_SOURCE_TYPE>\n"
          "    <SRVD_SOURCE_TYPE_DESC>Definition</SRVD_SOURCE_TYPE_DESC>\n   </SRVD>\n"))


def srvb(name, text, sd):
    write(f"{name.lower()}.srvb.xml", git("LCL_OBJECT_SRVB",
          "   <SRVB>\n    <METADATA>\n"
          f"     <NAME>{name}</NAME>\n     <TYPE>SRVB/SVB</TYPE>\n"
          f"     <DESCRIPTION>{esc(text[:60])}</DESCRIPTION>\n"
          "     <LANGUAGE>EN</LANGUAGE>\n     <MASTER_LANGUAGE>EN</MASTER_LANGUAGE>\n"
          "     <ABAP_LANGU_VERSION>5</ABAP_LANGU_VERSION>\n    </METADATA>\n"
          "    <CONTENT>\n     <BIND_TYPE_IMPL>\n"
          f"      <NAME>{name}</NAME>\n     </BIND_TYPE_IMPL>\n"
          "     <BIND_TYPE>ODATA</BIND_TYPE>\n     <BIND_TYPE_VERSION>V2</BIND_TYPE_VERSION>\n"
          "     <SERVICES>\n      <item>\n"
          f"       <SERVICE_NAME>{name}</SERVICE_NAME>\n       <SERVICE_CONTENT>\n        <item>\n"
          "         <SERVICE_VERSION>0001</SERVICE_VERSION>\n"
          "         <RELEASE_STATE>NOT_RELEASED</RELEASE_STATE>\n         <SRVD_REF>\n"
          f"          <URI>/sap/bc/adt/ddic/srvd/sources/{sd.lower()}</URI>\n"
          f"          <TYPE>SRVD/SRV</TYPE>\n          <NAME>{sd}</NAME>\n         </SRVD_REF>\n"
          "         <BIND_TYPE_DATA>\n          <CONTENT>\n           <ENCODING>base64</ENCODING>\n"
          "          </CONTENT>\n         </BIND_TYPE_DATA>\n        </item>\n"
          "       </SERVICE_CONTENT>\n      </item>\n     </SERVICES>\n    </CONTENT>\n"
          "    <CONTRACT>C1</CONTRACT>\n    <RELEASE_SUPPORTED>true</RELEASE_SUPPORTED>\n"
          "    <!-- false, not true: the inbound service that backs a published\n"
          "         endpoint is created by the publish in ADT, not by the import. -->\n"
          "    <PUBLISHED>false</PUBLISHED>\n    <BINDING_CREATED>false</BINDING_CREATED>\n   </SRVB>\n"))


# ======================================================== DDIC: domains =====
def outputlen_of(dt, leng, dec):
    """What DDIC computes as the output length, so the activation does not warn
    on every numeric domain. Integer digits, plus a thousands separator every
    three, plus the decimal point and the decimals."""
    if dt in ("DEC", "CURR", "QUAN", "FLTP"):
        intd = leng - (dec or 0)
        return intd + max(0, (intd - 1) // 3) + (1 if dec else 0) + (dec or 0)
    if dt == "INT4":
        return leng + 1
    if dt == "DATS":
        return 10
    if dt == "TIMS":
        return 8
    return leng


def domain(name, text, dt, leng, dec=None, fixed=None, lower=False):
    s = ("   <DD01V>\n"
         f"    <DOMNAME>{name}</DOMNAME>\n    <DDLANGUAGE>E</DDLANGUAGE>\n"
         f"    <DATATYPE>{dt}</DATATYPE>\n    <LENG>{leng:06d}</LENG>\n")
    if dec is not None:
        s += f"    <DECIMALS>{dec:06d}</DECIMALS>\n"
    s += f"    <OUTPUTLEN>{outputlen_of(dt, leng, dec):06d}</OUTPUTLEN>\n"
    if lower:
        s += "    <LOWERCASE>X</LOWERCASE>\n"
    if fixed:
        s += "    <VALEXI>X</VALEXI>\n"
    s += (f"    <DDTEXT>{esc(text)}</DDTEXT>\n    <DOMMASTER>E</DOMMASTER>\n"
          "    <ABAP_LANGUAGE_VERSION>5</ABAP_LANGUAGE_VERSION>\n   </DD01V>\n")
    if fixed:
        s += "   <DD07V_TAB>\n"
        for i, (low, txt) in enumerate(fixed, start=1):
            s += ("    <DD07V>\n"
                  f"     <VALPOS>{i:04d}</VALPOS>\n     <DDLANGUAGE>E</DDLANGUAGE>\n"
                  f"     <DOMVALUE_L>{esc(low)}</DOMVALUE_L>\n"
                  f"     <DDTEXT>{esc(txt)}</DDTEXT>\n    </DD07V>\n")
        s += "   </DD07V_TAB>\n"
    write(f"{name.lower()}.doma.xml", git("LCL_OBJECT_DOMA", s))


def dtel(name, dom, text, short):
    short = (short or text)[:20]
    s = ("   <DD04V>\n"
         f"    <ROLLNAME>{name}</ROLLNAME>\n    <DDLANGUAGE>E</DDLANGUAGE>\n"
         f"    <DOMNAME>{dom}</DOMNAME>\n"
         f"    <HEADLEN>{min(len(short), 55)}</HEADLEN>\n"
         "    <SCRLEN1>10</SCRLEN1>\n    <SCRLEN2>20</SCRLEN2>\n    <SCRLEN3>40</SCRLEN3>\n"
         f"    <DDTEXT>{esc(text[:60])}</DDTEXT>\n    <REPTEXT>{esc(short)}</REPTEXT>\n"
         f"    <SCRTEXT_S>{esc(short[:10])}</SCRTEXT_S>\n"
         f"    <SCRTEXT_M>{esc(short)}</SCRTEXT_M>\n"
         f"    <SCRTEXT_L>{esc(text[:40])}</SCRTEXT_L>\n"
         "    <DTELMASTER>E</DTELMASTER>\n    <REFKIND>D</REFKIND>\n"
         "    <ABAP_LANGUAGE_VERSION>5</ABAP_LANGUAGE_VERSION>\n   </DD04V>\n")
    write(f"{name.lower()}.dtel.xml", git("LCL_OBJECT_DTEL", s))


BUILTIN = {"CLNT": ("C", lambda n: n * 2, "  CLNT")}


def fld(name, roll=None, key=False, dt=None, leng=None, reftable=None, reffield=None):
    s = f"    <DD03P>\n     <FIELDNAME>{name}</FIELDNAME>\n"
    if key:
        s += "     <KEYFLAG>X</KEYFLAG>\n"
    if roll:
        s += f"     <ROLLNAME>{roll}</ROLLNAME>\n"
    s += "     <ADMINFIELD>0</ADMINFIELD>\n"
    if roll:
        if key:
            s += "     <NOTNULL>X</NOTNULL>\n"
        if reftable:
            s += f"     <REFTABLE>{reftable}</REFTABLE>\n     <REFFIELD>{reffield}</REFFIELD>\n"
        s += "     <COMPTYPE>E</COMPTYPE>\n"
    else:
        it, il, mask = BUILTIN[dt]
        s += (f"     <INTTYPE>{it}</INTTYPE>\n     <INTLEN>{il(leng):06d}</INTLEN>\n"
              + ("     <NOTNULL>X</NOTNULL>\n" if key else "")
              + f"     <DATATYPE>{dt}</DATATYPE>\n     <LENG>{leng:06d}</LENG>\n"
              f"     <MASK>{mask}</MASK>\n")
    return s + "    </DD03P>\n"


def table(name, text, fields):
    s = ("   <DD02V>\n"
         f"    <TABNAME>{name}</TABNAME>\n    <DDLANGUAGE>E</DDLANGUAGE>\n"
         "    <TABCLASS>TRANSP</TABCLASS>\n    <CLIDEP>X</CLIDEP>\n"
         f"    <DDTEXT>{esc(text[:60])}</DDTEXT>\n    <MASTERLANG>E</MASTERLANG>\n"
         "    <CONTFLAG>A</CONTFLAG>\n    <EXCLASS>1</EXCLASS>\n   </DD02V>\n"
         "   <DD09L>\n"
         f"    <TABNAME>{name}</TABNAME>\n    <AS4LOCAL>A</AS4LOCAL>\n"
         "    <TABKAT>0</TABKAT>\n    <TABART>APPL0</TABART>\n    <BUFALLOW>N</BUFALLOW>\n"
         "   </DD09L>\n   <DD03P_TABLE>\n" + "".join(fields) + "   </DD03P_TABLE>\n"
         "   <TABL_EXTRAS>\n    <TDDAT>\n"
         f"     <TABNAME>{name}</TABNAME>\n     <CCLASS>CUS_DEV_SUP_DA</CCLASS>\n"
         "    </TDDAT>\n   </TABL_EXTRAS>\n")
    write(f"{name.lower()}.tabl.xml", git("LCL_OBJECT_TABL", s))


# ====================================================== naming the cloud ====
def cloud_dom(hana):
    """/CLR/ELTD_C50 -> ZDO_ELT_C50"""
    return "ZDO_ELT_" + hana.replace("/CLR/ELTD_", "")


def cloud_de(hana):
    """/CLR/ELT_DOCNO -> ZDE_ELT_DOCNO"""
    return "ZDE_ELT_" + hana.replace("/CLR/ELT_", "")


# Standard SAP data elements the drop uses. None is released for ABAP Cloud as
# a table field type, so each gets a local equivalent of the same type. MANDT
# is not among them: a cloud table's client column is a plain CLNT 3 named
# CLIENT, declared without a data element.
STD = {
    "LAND1":      ("ZDE_ELT_COUNTRY",    "ZDO_ELT_COUNTRY",    "CHAR", 3,  None,
                   "Country key"),
    "WAERS":      ("ZDE_ELT_CURRCODE",   "ZDO_ELT_CURRCODE",   "CUKY", 5,  None,
                   "Currency code"),
    "MEINS":      ("ZDE_ELT_UNITSAP",    "ZDO_ELT_UNITSAP",    "UNIT", 3,  None,
                   "Unit of measure (SAP)"),
    "TIMESTAMPL": ("ZDE_ELT_TIMESTAMPL", "ZDO_ELT_TIMESTAMPL", "DEC", 21, 7,
                   "Timestamp (long form)"),
    "INT4":       ("ZDE_ELT_INT4",       "ZDO_ELT_INT4",       "INT4", 10, None,
                   "Count"),
    "ERDAT":      ("ZDE_ELT_CRDATE",     "ZDO_ELT_DATE2",      "DATS", 8,  None,
                   "Created on"),
    "ERZET":      ("ZDE_ELT_CRTIME",     "ZDO_ELT_TIME2",      "TIMS", 6,  None,
                   "Created at"),
    "ERNAM":      ("ZDE_ELT_CRUSER",     "ZDO_ELT_USER",       "CHAR", 12, None,
                   "Created by"),
    "AEDAT":      ("ZDE_ELT_CHDATE",     "ZDO_ELT_DATE2",      "DATS", 8,  None,
                   "Changed on"),
    "AEZET":      ("ZDE_ELT_CHTIME",     "ZDO_ELT_TIME2",      "TIMS", 6,  None,
                   "Changed at"),
    "AENAM":      ("ZDE_ELT_CHUSER",     "ZDO_ELT_USER",       "CHAR", 12, None,
                   "Changed by"),
}


def resolve(roll):
    """HANA data element -> (cloud data element, cloud domain, type, len, dec)."""
    if roll in STD:
        de, dom, dt, ln, dc, _ = STD[roll]
        return de, dom, dt, ln, dc
    d = SPEC["dtels"][roll]
    dom = SPEC["domains"][d["domain"]]
    return (cloud_de(roll), cloud_dom(d["domain"]),
            dom["datatype"], dom["leng"], dom["decimals"] or None)


# =============================================== emit the shared DDIC layer ==
print("DDIC:")
for hname, d in sorted(SPEC["domains"].items()):
    fixed = d["fixed"] or SPEC["roles"].get(hname) or None
    domain(cloud_dom(hname), d["text"], d["datatype"], d["leng"],
           d["decimals"] or None, fixed=fixed,
           lower=(d["datatype"] in ("CHAR", "STRG") and d["lowercase"]))
for hname, d in sorted(SPEC["dtels"].items()):
    dtel(cloud_de(hname), cloud_dom(d["domain"]), d["text"],
         d["short"] or d["med"] or d["text"])
seen_dom = set()
for std, (de, dom, dt, ln, dc, txt) in sorted(STD.items()):
    if dom not in seen_dom:
        domain(dom, txt, dt, ln, dc)
        seen_dom.add(dom)
    dtel(de, dom, txt, txt)
print(f"  {len(SPEC['domains']) + len(seen_dom)} domains, "
      f"{len(SPEC['dtels']) + len(STD)} data elements")

# ================================================================ variants ===
# suffix -> (cloud table letter, composition name, BDEF alias, label, plural)
PARTS = [
    ("H", "",            "EDocument",     "Invoice header",         "Invoices"),
    ("I", "_Line",       "Line",          "Invoice line",           "Lines"),
    ("P", "_Party",      "Party",         "Party",                  "Parties"),
    ("T", "_TaxSubtotal", "TaxSubtotal",  "VAT breakdown",          "VAT breakdown"),
    ("A", "_Allowance",  "Allowance",     "Allowance / charge",     "Allowances and charges"),
    ("N", "_Note",       "Note",          "Note",                   "Notes"),
    ("R", "_Reference",  "Reference",     "Document reference",     "References"),
    ("X", "_ItemAttr",   "ItemAttribute", "Item attribute",         "Item attributes"),
]
HANA_OF = {p[0]: f"/CLR/EINV_ELTAP{p[0]}" for p in PARTS}

VARIANTS = [
    dict(tag="AP", label="Inbound e-Invoice (AP)", single="Inbound e-Invoice",
         plural="Inbound e-Invoices", einv_type="PURCHASE",
         acth="ZVH_EINV_ACTTYPE_AP", param="ZCDS_ABS_EINV_APACT",
         src="the AP cockpit /CLR/EINV_AP_COCKPIT (includes _DD / _SS / _COMMON)",
         inferred=False),
    dict(tag="SB", label="Self-Billed e-Invoice", single="Self-Billed e-Invoice",
         plural="Self-Billed e-Invoices", einv_type="SELF_BILLED",
         acth="ZVH_EINV_ACTTYPE_SELF", param="ZCDS_ABS_EINV_SELFACT",
         src="the P_SELF mode of /CLR/ELT_EINVOICE_COCKPIT",
         inferred=True),
]

# Fields the user may change. Everything else is the payload as the platform
# delivered it: the HANA cockpit enforced that with per-column EDIT_TOGGLE
# flags in /CLR/EINV_APFCAT; here it is in the behaviour definition.
WRITABLE = {"ACTION_TYPE", "REASON_CODE", "COMMENT_TXT", "MATCH_STATUS"}

# Columns of the list report, in order.
LIST_HEAD = ["DOCUMENTNUMBER", "ISSUE_DATE", "DUE_DATE", "INV_TYPE_CODE",
             "PAYABLE_AMT", "CURRENCY", "STATUS", "MATCH_STATUS",
             "ACTION_TYPE", "REASON_CODE", "API_MESSAGE"]
LIST_OF = {
    "I": ["LINE_ID", "ITEM_NAME", "QUANTITY", "UNIT_ISO", "PRICE_AMT",
          "LINE_NET_AMT", "LINE_TAX_AMT", "TAX_PERCENT", "CURRENCY"],
    "P": ["PARTY_ROLE", "PARTY_NAME", "VAT_ID", "COUNTRY", "CITY",
          "ENDPOINT_ID", "LINE_ID"],
    "T": ["SEQUENCE", "TAX_CAT", "TAX_PERCENT", "TAXABLE_AMT", "TAX_AMT",
          "CURRENCY", "TAX_EXE_RSN"],
    "A": ["LINE_ID", "SEQ", "CHARGE_IND", "AC_RSN_CODE", "AC_RSN_TEXT",
          "AMOUNT", "CURRENCY", "TAX_PERCENT"],
    "N": ["LINE_ID", "SEQ", "SUBJECT_CODE", "NOTE_TEXT"],
    "R": ["REF_TYPE", "LINE_ID", "SEQ", "REF_ID", "REF_DATE", "DOC_TYPE_CODE",
          "REF_DESC"],
    "X": ["ATTR_TYPE", "LINE_ID", "SEQ", "ATTR_NAME", "ATTR_VALUE",
          "ATTR_SCHEME"],
}

# Object-page grouping of the 82 header columns. The HANA cockpit showed them
# as one 262-column ALV; the prefix tells you which UBL group a field is in,
# so the grouping comes out of the field names rather than being invented.
FACETS = [
    ("Document",  ("DOCUMENTNUMBER", "DOCUMENTID", "UUID", "STATUS", "MATCH_STATUS",
                   "ACTION_TYPE", "REASON_CODE", "COMMENT_TXT", "API_MESSAGE",
                   "INV_TYPE_", "ISSUE_", "DUE_DATE", "TAX_POINT_DATE",
                   "ACC_COST", "BUYER_REF", "PERIOD_", "LINE_COUNT")),
    ("Standard",  ("UBL_VERSION", "CUSTOMIZATION_ID", "PROFILE_ID", "SBDH_")),
    ("Currency",  ("CURRENCY", "TAX_CURRENCY", "TAX_EXC_")),
    ("Totals",    ("LINE_EXT_AMT", "ALLOWANCE_TOTAL", "CHARGE_TOTAL", "TAX_EXCL_AMT",
                   "VAT_TOTAL", "TAX_INCL_AMT", "PREPAID_AMT", "PAYABLE_")),
    ("Delivery",  ("ACTUAL_DEL_DATE", "DEL_")),
    ("Payment",   ("PAY_MEANS", "PAY_INSTR", "PAY_ID", "PAYEE_", "CARD_",
                   "MANDATE_ID", "PAYER_")),
    ("PaymentTerms", ("PAY_TERMS",)),
    ("Prepaid",   ("PREPAID_",)),
    ("Admin",     ("JSON_PAYLOAD", "CREATED_", "CHANGED_")),
]


def facet_of(f):
    for name, pres in FACETS:
        for p in pres:
            if f == p or f.startswith(p):
                return name
    return "Other"


HEAD_ANNO = """@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: '{label}'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{{
    serviceQuality: #X,
    sizeCategory: #L,
    dataClass: #TRANSACTIONAL
}}
"""


def lab40(t):
    """@EndUserText.label is typed STRING(40). The workbook descriptions carry
    the BT code, which is the part worth keeping, so a long one is cut from the
    left of the suffix rather than losing its tail."""
    t = (t or "").replace("'", "").strip()
    if len(t) <= 40:
        return t
    m = re.search(r"\(B[TG]-\d+\)$", t)
    if m and len(m.group(0)) < 38:
        head = t[:m.start()].rstrip()
        keep = 40 - len(m.group(0)) - 1
        return (head[:keep].rstrip(" -,/(") + " " + m.group(0))
    cut = t[:40]
    if cut.count("(") > cut.count(")"):
        cut = cut[:cut.rfind("(")]
    return cut.rstrip(" -,/(")


def note(tab, field):
    return SPEC["meta"].get(f"{tab}|{field}", {})


def wrap(names, indent):
    out, cur = [], ""
    for n in names:
        if len(cur) + len(n) > 68:
            out.append(cur.rstrip())
            cur = ""
        cur += n + ", "
    out.append(cur.rstrip().rstrip(","))
    return ("\n" + indent).join(out)


# ===================================================== per-variant emission ==
for v in VARIANTS:
    tag = v["tag"]
    tabs = {p[0]: f"ZTEDOC_{tag}{p[0]}" for p in PARTS}
    ints = {p[0]: f"ZCDS_INT_EDOC_{tag}{p[0]}" for p in PARTS}
    cuns = {p[0]: f"ZCDS_CUN_EDOC_{tag}{p[0]}" for p in PARTS}
    bph = f"ZBP_CDS_INT_EDOC_{tag}H"
    bpc = f"ZBP_CDS_CUN_EDOC_{tag}H"
    fields = {p[0]: SPEC["tables"][HANA_OF[p[0]]]["fields"] for p in PARTS}

    # --------------------------------------------- derived values (CASE) --
    # @ObjectModel.virtualElement is not released for ABAP Cloud, so the
    # status criticality is a CASE in a view of its own, reached from the
    # header by a [1..1] association and exposed on the projection as a path
    # expression. That also makes it filterable and sortable, which a virtual
    # element never was.
    #
    # It cannot live in the header interface view: that is the root of a
    # managed business object and has to stay 1:1 with its table.
    enr = f"ZCDS_INT_EDOC_{tag}ENR"
    write(f"{enr.lower()}.ddls.asddls", f"""/* =====================================================================
   {v['label']} - derived values.

   Everything computed rather than stored, kept out of the business object's
   root view so that view stays 1:1 with {tabs['H']}.
   ===================================================================== */
@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: '{lab40(v["single"] + " - derived values")}'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{{
    serviceQuality: #C,
    sizeCategory: #L,
    dataClass: #TRANSACTIONAL
}}
define view entity {enr} as select from {tabs['H'].lower()}
{{
  key uuid as Uuid,

      /* Replaces /CLR/EINV_STATUS-COLOR_CODE. The two HANA e-document
         cockpits had no status colouring at all - set_status_colors exists
         only on the sales side - so this is new, and it costs nothing. */
      case upper( status )
        when 'ACCEPTED'    then 3
        when 'APPROVED'    then 3
        when 'CLEARED'     then 3
        when 'SENT'        then 3
        when 'REJECTED'    then 1
        when 'ERROR'       then 1
        when 'FAILED'      then 1
        when 'PENDING'     then 2
        when 'IN_PROGRESS' then 2
        else 0
      end  as StatusCriticality
}}
""")
    ddls_xml(enr, f"{v['single']} - derived values")
    ddls_base(enr, [tabs["H"]])

    # ----------------------------------------- action parameter (abstract)
    # One per variant rather than one shared entity: the action type list is
    # keyed by EINV_TYPE in /CLR/YT_ACTION, so a shared parameter entity
    # would offer the AP cockpit the self-billed actions and vice versa -
    # the very thing that key field was added to prevent.
    write(f"{v['param'].lower()}.ddls.asddls", f"""/* =====================================================================
   Parameters of the SendAction action of the {v['label']} business object.

   Replaces the editable ALV columns of the HANA cockpit. There, the action
   type and reason code were maintained inline in a cl_gui_alv_grid with two
   dropdown handle mechanisms:

     - ACTION_TYPE  a static handle loaded from
                    /CLR/YT_ACTION WHERE EINV_TYPE = '{v['einv_type']}'
     - REASON_CODE  a per-row handle (DRDN_FIELD = 'REASON_HNDL') with
                    handles allocated one per distinct action type and
                    re-pointed by an ON_DATA_CHANGED_FINISHED event handler
                    whenever the user changed the action type

   In Fiori that entire apparatus is two value helps with a filter
   dependency, so the dropdown handles, the handle map and the event
   handler class all disappear.

   The parameters are optional: leaving one empty keeps whatever is already
   on the document, which is how the HANA grid behaved.
   ===================================================================== */
@EndUserText.label: '{v['single']} Action Parameters'
define abstract entity {v['param']}
{{
      @EndUserText.label: 'Action Type'
      @Consumption.valueHelpDefinition: [ {{ entity: {{ name: '{v['acth']}',
                                                      element: 'ActionType' }} }} ]
      ActionType  : zde_einv_action;

      @EndUserText.label: 'Reason Code'
      @Consumption.valueHelpDefinition: [ {{ entity: {{ name: 'ZVH_EINV_REASONCODE',
                                                      element: 'ReasonCode' }},
                                            additionalBinding: [ {{ localElement: 'ActionType',
                                                                   element: 'ActionType',
                                                                   usage: #FILTER_AND_RESULT }} ] }} ]
      ReasonCode  : zde_einv_reason;

      @EndUserText.label: 'Comment'
      CommentText : zde_elt_comment;
}}
""")
    ddls_xml(v["param"], f"{v['single']} Action Parameters")
    ddls_base(v["param"], [])

    # ------------------------------------------------------------- tables --
    for letter, assoc, alias, label, plural in PARTS:
        hana = HANA_OF[letter]
        rows = fields[letter]
        out = [fld("CLIENT", key=True, dt="CLNT", leng=3)]
        for r in rows:
            if r["field"] == "MANDT":
                continue
            de, _dom, _dt, _ln, _dc = resolve(r["roll"])
            rt = rf = None
            if r["reffield"]:
                rt, rf = tabs[r["reftable"][-1]], r["reffield"]
            out.append(fld(r["field"], de, key=r["key"], reftable=rt, reffield=rf))
        table(tabs[letter], f"{v['single']}: {label}", out)

    # ------------------------------------------- CDS interface + projection -
    for letter, assoc, alias, label, plural in PARTS:
        hana = HANA_OF[letter]
        rows = [r for r in fields[letter] if r["field"] != "MANDT"]
        iname, cname = ints[letter], cuns[letter]

        lines = []
        for r in rows:
            n = note(hana, r["field"])
            desc = n.get("desc", "")
            xp = n.get("xpath", "")
            if desc:
                lines.append(f"      @EndUserText.label: '{lab40(desc)}'")
            if xp and not xp.startswith("("):
                lines.append(f"      /* {xp[:110]} */")
            if r["reffield"]:
                kind = ("amount.currencyCode"
                        if resolve(r["roll"])[2] == "CURR" else "quantity.unitOfMeasure")
                lines.append(f"      @Semantics.{kind}: '{camel(r['reffield'])}'")
            kw = "  key " if r["key"] else "      "
            lines.append(f"{kw}{r['field'].lower()} as {camel(r['field'])},")

        if letter == "H":
            comp = "\n".join(
                f"  composition [0..*] of {ints[l]} as {a}"
                for l, a, _al, _lb, _pl in PARTS if l != "H")
            # The seller and the buyer are two rows of the party table, picked
            # out by role. They get associations of their own so the
            # consumption view can path-navigate to them: a projection can
            # only follow an association the projected entity exposes, and
            # these two are what make the list report readable.
            #
            # Plain associations, not compositions - the rows already belong
            # to the _Party composition and an entity cannot be composed twice.
            comp += "".join(
                f"""
  association [0..1] to {ints['P']} as _{role.capitalize()}Party on  $projection.Uuid = _{role.capitalize()}Party.Uuid
                                                     and _{role.capitalize()}Party.LineId    = ' '
                                                     and _{role.capitalize()}Party.PartyRole = '{role}'"""
                for role in ("SELLER", "BUYER"))
            comp += (f"\n  association [1..1] to {enr} as _Enrich"
                     f"\n                                   on $projection.Uuid = _Enrich.Uuid")
            src = (HEAD_ANNO.format(label=lab40(f"Interface View for {v['label']}"))
                   + f"define root view entity {iname} as select from {tabs['H'].lower()}\n"
                   + comp + "\n{\n" + "\n".join(lines) + "\n\n"
                   + "\n".join(f"      {a}," for l, a, *_ in PARTS if l != "H")
                   + "\n      _SellerParty,\n      _BuyerParty,\n      _Enrich\n}\n")
            ddls_base(iname, [tabs["H"]],
                      [ints[l] for l, *_ in PARTS if l != "H"] + [enr])
        else:
            src = (HEAD_ANNO.format(label=lab40(f"Interface View for {v['single']} {label}"))
                   + f"define view entity {iname} as select from {tabs[letter].lower()}\n"
                     f"  association to parent {ints['H']} as _Document\n"
                     "    on $projection.Uuid = _Document.Uuid\n"
                   + "{\n" + "\n".join(lines) + "\n\n      _Document\n}\n")
            ddls_base(iname, [tabs[letter]], [ints["H"]])
        write(f"{iname.lower()}.ddls.asddls", src)
        ddls_xml(iname, f"Interface View for {v['single']} {label}")

        # projection
        plines, selpos = [], 0
        for r in rows:
            n = note(hana, r["field"])
            # A filter field takes its label from the element's
            # @EndUserText.label, and without one Fiori falls back to the data
            # element's SHORT DDIC label - ten characters, which is how the
            # filter bar came out reading "Invoice Nu:", "Match Stat:" and
            # "Invoice Ty:". The lineItem label only names the column, not the
            # filter. _SellerParty and _BuyerParty already carry theirs below.
            SEL_LABEL = {"DOCUMENTNUMBER": "Invoice Number",
                         "ISSUE_DATE":     "Issue Date",
                         "STATUS":         "Status",
                         "MATCH_STATUS":   "Match Status",
                         "INV_TYPE_CODE":  "Invoice Type"}
            if letter == "H" and r["field"] in SEL_LABEL:
                selpos += 10
                plines.append(f"      @EndUserText.label: '{SEL_LABEL[r['field']]}'")
                plines.append(f"      @UI.selectionField: [ {{ position: {selpos} }} ]")
            if letter == "H" and r["field"] in ("DOCUMENTNUMBER", "DOCUMENTID", "UUID"):
                plines.append("      @Search.defaultSearchElement: true")
            if letter == "P" and r["field"] in ("PARTY_NAME", "VAT_ID"):
                plines.append("      @Search.defaultSearchElement: true")
            if letter == "H" and r["field"] == "ACTION_TYPE":
                plines.append("      @Consumption.valueHelpDefinition: "
                              f"[ {{ entity: {{ name: '{v['acth']}', element: 'ActionType' }} }} ]")
            if letter == "H" and r["field"] == "REASON_CODE":
                plines.append("      @Consumption.valueHelpDefinition: "
                              "[ { entity: { name: 'ZVH_EINV_REASONCODE', element: 'ReasonCode' },"
                              " additionalBinding: [ { localElement: 'ActionType',"
                              " element: 'ActionType', usage: #FILTER_AND_RESULT } ] } ]")
            if r["reffield"]:
                kind = ("amount.currencyCode"
                        if resolve(r["roll"])[2] == "CURR" else "quantity.unitOfMeasure")
                # Restated, not inherited: @Metadata.ignorePropagatedAnnotations
                # is on, so an amount without its currency reference here
                # reaches OData with no currency at all.
                plines.append(f"      @Semantics.{kind}: '{camel(r['reffield'])}'")
            plines.append(("  key " if r["key"] else "      ") + camel(r["field"]) + ",")

        if letter == "H":
            # Seller and buyer names are the two columns that make the list
            # report readable, and they live in the party table. They are path
            # expressions on the PROJECTION, never elements of the interface
            # view: the root view of a managed business object has to stay 1:1
            # with its table or the behaviour definition will not activate.
            plines += [
                "",
                "      @EndUserText.label: 'Seller'",
                "      @UI.selectionField: [ { position: 60 } ]",
                "      _SellerParty.PartyName as SellerName,",
                "      @EndUserText.label: 'Seller VAT ID'",
                "      _SellerParty.VatId     as SellerVatId,",
                "      @EndUserText.label: 'Seller Country'",
                "      _SellerParty.Country   as SellerCountry,",
                "      @EndUserText.label: 'Buyer'",
                "      @UI.selectionField: [ { position: 70 } ]",
                "      _BuyerParty.PartyName  as BuyerName,",
                "      @EndUserText.label: 'Buyer VAT ID'",
                "      _BuyerParty.VatId      as BuyerVatId,",
                "",
                "      @EndUserText.label: 'Criticality'",
                "      _Enrich.StatusCriticality as StatusCriticality,",
                "",
            ] + [f"      {a} : redirected to composition child {cuns[l]},"
                 for l, a, *_ in PARTS if l != "H"]
            plines[-1] = plines[-1].rstrip(",")
            src = (HEAD_ANNO.format(label=lab40(v["label"]))
                   + "@Metadata.allowExtensions: true\n@Search.searchable: true\n"
                   + f"define root view entity {cname}\n"
                     "  provider contract transactional_query\n"
                     f"  as projection on {ints['H']}\n"
                   + "{\n" + "\n".join(plines) + "\n}\n")
            ddls_base(cname, [ints["H"]], [cuns[l] for l, *_ in PARTS if l != "H"])
        else:
            plines[-1] = plines[-1].rstrip(",")
            # No `provider contract transactional_query` on a child: the
            # contract is declared once, on the root projection, and inherited.
            # Declaring it on a view that also carries `redirected to parent`
            # is rejected with "Provider contract not modifiable if view
            # contains REDIRECTED TO PARENT associations".
            src = (HEAD_ANNO.format(label=lab40(f"{v['single']} {label}"))
                   + "@Metadata.allowExtensions: true\n"
                   + f"define view entity {cname}\n"
                     f"  as projection on {ints[letter]}\n"
                   + "{\n" + "\n".join(plines) + ",\n\n"
                   + f"      _Document : redirected to parent {cuns['H']}\n}}\n")
            ddls_base(cname, [ints[letter]], [cuns["H"]])
        write(f"{cname.lower()}.ddls.asddls", src)
        ddls_xml(cname, f"{v['single']} {label}")

    # ------------------------------------------------------------- BDEF ----
    blocks = []
    hrows = [r for r in fields["H"] if r["field"] != "MANDT"]
    ro = [camel(r["field"]) for r in hrows
          if not r["key"] and r["field"] not in WRITABLE]
    comps = "\n".join(f"  association {a} {{ create; }}"
                      for l, a, *_ in PARTS if l != "H")
    hmap = "\n".join(f"      {camel(r['field'])} = {r['field'].lower()};" for r in hrows)
    blocks.append(f"""managed implementation in class {bph.lower()} unique;
strict ( 2 );

define behavior for {ints['H']} alias EDocument
persistent table {tabs['H'].lower()}
lock master
authorization master ( instance, global )
{{
  update;

  /* Only the four action fields are writable; everything else is the payload
     as the Clear platform delivered it and must not be edited in SAP. The
     HANA cockpit enforced that with per-column EDIT_TOGGLE flags in
     /CLR/EINV_APFCAT - here it is in the behaviour definition, where it
     belongs. Key fields are not listed: RAP already refuses to change a key
     on update, and marking one readonly blocks it on create as well. */
  field ( readonly ) {wrap(ro, "                     ")};

  /* The key is fixed once the document is there. `readonly : update` rather
     than plain `readonly`: the unconditional form would block it on create
     too, and a loader has to be able to supply it. */
  field ( readonly : update ) {wrap([camel(r["field"]) for r in hrows if r["key"]], "                              ")};

  /* Replaces &ZSEND / FORM send_action_data: posts the action to the
     platform and writes back status + action. */
  /* ( features : instance ) replaces &ZEDIT, which toggled celltab styles on
     the checked rows: the button is greyed out per row rather than hidden
     for everybody. Feature control is a characteristic of the operation -
     there is no separate statement for it. */
  action ( features : instance ) SendAction parameter {v['param']} result [1] $self;

  validation checkAction on save {{ field ActionType, ReasonCode; }}

{comps}

  mapping for {tabs['H'].lower()}
    {{
{hmap}
    }}
}}""")
    for letter, assoc, alias, label, plural in PARTS:
        if letter == "H":
            continue
        rows = [r for r in fields[letter] if r["field"] != "MANDT"]
        cro = [camel(r["field"]) for r in rows if not r["key"]]
        cmap = "\n".join(f"      {camel(r['field'])} = {r['field'].lower()};" for r in rows)
        # No `field ( readonly )` here, but every field is readonly on the
        # PROJECTION below. The children are the UBL payload: nobody edits
        # them through the app, but the loader that will fill them from the
        # detail fetch has to be able to write them with EML, and a base-level
        # readonly would block that too.
        blocks.append(f"""define behavior for {ints[letter]} alias {alias}
persistent table {tabs[letter].lower()}
lock dependent by _Document
authorization dependent by _Document
{{
  update;

  /* A to-parent association has to be declared by the child and exposed on
     its projection, even when nothing navigates it: RAP needs it to tie the
     child back to the composition. */
  association _Document;

  field ( readonly : update ) {wrap([camel(r["field"]) for r in rows if r["key"]], "                              ")};

  mapping for {tabs[letter].lower()}
    {{
{cmap}
    }}
}}""")
    write(f"{ints['H'].lower()}.bdef.asbdef", f"""/* =====================================================================
   {v['label']} business object.

   Replaces {v['src']}.

   The payload is normalised across eight tables rather than the two flat
   ones of the first conversion: repeating UBL groups - notes, VAT
   subtotals, allowances and charges, document references, item attributes
   and the parties themselves - had fixed slots there (four notes, four tax
   subtotals, one allowance, one charge) and silently lost anything beyond
   them. Here each is its own child entity with no limit.

   Every child hangs off the header on UUID alone. LINE_ID is blank on a
   document-level row and carries the line number on a line-level one, so one
   table serves both levels - which is how the source models it.
   ===================================================================== */
""" + "\n\n".join(blocks) + "\n")
    bdef_xml(ints["H"], f"Behavior Definition for {v['label']}")

    pblocks = [f"""define behavior for {cuns['H']} alias EDocument
{{
  use update;
  use action SendAction;
""" + "\n".join(f"  use association {a};" for l, a, *_ in PARTS if l != "H") + "\n}"]
    for letter, assoc, alias, *_ in PARTS:
        if letter == "H":
            continue
        crows = [r for r in fields[letter] if r["field"] != "MANDT" and not r["key"]]
        pblocks.append(
            f"define behavior for {cuns[letter]} alias {alias}\n{{\n"
            "  /* Read-only in the app: this is the payload as the platform sent\n"
            "     it. The base behaviour leaves it writable so a loader can fill\n"
            "     it with EML.\n"
            "\n"
            "     `field ( ... )` is a statement of its own here - only create,\n"
            "     update, delete, action, function, event, key and association\n"
            "     may follow `use`. */\n"
            "  use update;\n"
            "  use association _Document;\n"
            f"  field ( readonly ) {wrap([camel(r['field']) for r in crows], '                     ')};\n"
            "}")
    write(f"{cuns['H'].lower()}.bdef.asbdef",
          "projection;\nstrict ( 2 );\n\n" + "\n\n".join(pblocks) + "\n")
    bdef_xml(cuns["H"], f"Projection Behavior for {v['label']}")

    # -------------------------------------------------- handler classes ----
    write(f"{bph.lower()}.clas.abap",
          f"CLASS {bph.lower()} DEFINITION PUBLIC ABSTRACT FINAL FOR BEHAVIOR OF {ints['H'].lower()}.\n\n"
          "  PROTECTED SECTION.\n  PRIVATE SECTION.\nENDCLASS.\n\n\n\n"
          f"CLASS {bph} IMPLEMENTATION.\nENDCLASS.\n")
    clas_xml(bph, f"Behavior Implementation for {ints['H']}", defint=ints["H"], cat="06")

    write(f"{bph.lower()}.clas.locals_imp.abap", f'''*"* Behaviour implementation of the {v['label']} business object.
*"*
*"* All the real work sits in ZCL_EINV_EDOC_ACTION, which this BO and its
*"* sibling share - the HANA originals (FORM send_action_data /
*"* self_send_action_data and FORM call_action_api / self_call_action_api)
*"* were two near-identical copies of the same ~200 lines, differing only in
*"* the EINV_TYPE literal, the endpoint and which party's VAT ID is sent as
*"* the taxpayer identifier.

CLASS lhc_edocument DEFINITION INHERITING FROM cl_abap_behavior_handler.

  PRIVATE SECTION.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR edocument RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR edocument RESULT result.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR edocument RESULT result.

    METHODS checkaction FOR VALIDATE ON SAVE
      IMPORTING keys FOR edocument~checkaction.

    METHODS sendaction FOR MODIFY
      IMPORTING keys FOR ACTION edocument~sendaction RESULT result.

ENDCLASS.


CLASS lhc_edocument IMPLEMENTATION.

  METHOD get_instance_authorizations.
    " The HANA cockpit checked nothing here; access to the transaction was the
    " whole authorization. In Public Cloud that is the business catalog on the
    " service binding, so every instance is granted.
    "
    " RESULT must be filled. An instance-authorization handler that returns an
    " empty table denies every operation on every row, which would leave this
    " business object activated but completely inert.
    result = VALUE #( FOR ls_auth IN keys
                      ( %tky = ls_auth-%tky %update = if_abap_behv=>auth-allowed ) ).
  ENDMETHOD.


  METHOD get_global_authorizations.
    result-%update = if_abap_behv=>auth-allowed.
  ENDMETHOD.


  METHOD get_instance_features.
    " The HANA cockpit drove button visibility from /CLR/EINV_APALV, whose
    " EINV_TYPE key field was added precisely so PURCHASE and SELF_BILLED could
    " have different toolbars. FORM get_excluded_fcodes was never updated to
    " filter on it, so deactivating a button for one variant hid it for both.
    " Feature control per instance replaces the whole mechanism and cannot have
    " that bug.
    READ ENTITIES OF {ints['H'].lower()} IN LOCAL MODE
      ENTITY edocument FIELDS ( ActionType Status ) WITH CORRESPONDING #( keys )
      RESULT DATA(lt_doc).

    result = VALUE #( FOR ls IN lt_doc
      ( %tky = ls-%tky
        %action-SendAction = COND #( WHEN ls-ActionType IS NOT INITIAL
                                     THEN if_abap_behv=>fc-o-enabled
                                     ELSE if_abap_behv=>fc-o-disabled ) ) ).
  ENDMETHOD.


  METHOD checkaction.
    " Ported from FORM send_action_data: the action type is mandatory, and if
    " the action has any reason codes in /CLR/YT_REASON then the reason code is
    " mandatory AND must be one of the codes configured for that action.
    READ ENTITIES OF {ints['H'].lower()} IN LOCAL MODE
      ENTITY edocument FIELDS ( ActionType ReasonCode ) WITH CORRESPONDING #( keys )
      RESULT DATA(lt_doc).

    DATA(lo_action) = NEW zcl_einv_edoc_action( iv_einv_type = '{v['einv_type']}' ).

    LOOP AT lt_doc INTO DATA(ls_doc).
      DATA(lv_msg) = lo_action->validate_action( iv_action_type = ls_doc-ActionType
                                                 iv_reason_code = ls_doc-ReasonCode ).
      IF lv_msg IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_doc-%tky ) TO failed-edocument.
        APPEND VALUE #( %tky = ls_doc-%tky
                        %msg = new_message_with_text(
                                 severity = if_abap_behv_message=>severity-error
                                 text     = lv_msg )
                        %element-ActionType = if_abap_behv=>mk-on )
               TO reported-edocument.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


  METHOD sendaction.
    READ ENTITIES OF {ints['H'].lower()} IN LOCAL MODE
      ENTITY edocument ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_doc).

    " The taxpayer identifier the platform expects is the VAT ID of the seller
    " for an inbound document and of the buyer for a self-billed one. Both now
    " live as rows of the party table rather than as header columns, so they
    " are read once for the whole request.
    " Document-level parties only (LINE_ID blank). A line-level party is an
    " item manufacturer, never the taxpayer. This was a helper method until
    " the tenant rejected its signature: a RAP derived type is not permitted
    " on a RETURNING parameter, and TABLE FOR ACTION IMPORT on the importing
    " parameter made the class fail to compile whenever the behaviour
    " definition was not yet active. Inlined, it needs neither.
    READ ENTITIES OF {ints['H'].lower()} IN LOCAL MODE
      ENTITY edocument BY \\_Party
        FIELDS ( Uuid LineId PartyRole PartyName VatId ) WITH CORRESPONDING #( keys )
      RESULT DATA(lt_all_party).

    DATA(lt_party) = lt_all_party.
    DELETE lt_party WHERE LineId IS NOT INITIAL.

    DATA(lo_action) = NEW zcl_einv_edoc_action( iv_einv_type = '{v['einv_type']}' ).
    DATA lt_update TYPE TABLE FOR UPDATE {ints['H'].lower()}.

    LOOP AT keys INTO DATA(ls_key).
      DATA(ls_doc) = VALUE #( lt_doc[ KEY entity Uuid = ls_key-Uuid ] OPTIONAL ).

      " A key the READ did not return is one the user may not see or that was
      " deleted meanwhile. Without this check the action would be sent to the
      " platform with an all-initial document.
      IF ls_doc-Uuid IS INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-edocument.
        APPEND VALUE #( %tky = ls_key-%tky
                        %msg = new_message( id       = 'ZEINV_MSG'
                                            number   = '037'
                                            severity = if_abap_behv_message=>severity-error ) )
               TO reported-edocument.
        CONTINUE.
      ENDIF.

      DATA(ls_res) = lo_action->send(
        is_document  = VALUE #( documentid     = ls_doc-DocumentId
                                documentnumber = ls_doc-DocumentNumber
                                issue_dt       = ls_doc-IssueDate
                                inv_typ_code   = ls_doc-InvoiceTypeCode
                                seller_vat     = VALUE #( lt_party[ Uuid      = ls_doc-Uuid
                                                                    PartyRole = 'SELLER' ]-VatId OPTIONAL )
                                buyer_vat      = VALUE #( lt_party[ Uuid      = ls_doc-Uuid
                                                                    PartyRole = 'BUYER' ]-VatId OPTIONAL ) )
        iv_action_type = COND #( WHEN ls_key-%param-ActionType IS NOT INITIAL
                                 THEN ls_key-%param-ActionType ELSE ls_doc-ActionType )
        iv_reason_code = COND #( WHEN ls_key-%param-ReasonCode IS NOT INITIAL
                                 THEN ls_key-%param-ReasonCode ELSE ls_doc-ReasonCode )
        iv_comment     = COND #( WHEN ls_key-%param-CommentText IS NOT INITIAL
                                 THEN ls_key-%param-CommentText ELSE ls_doc-CommentText ) ).

      " API_MESSAGE was in-memory only in the HANA grid and lost on exit.
      " Persisting it is the point of having a business object.
      APPEND VALUE #( %tky                = ls_key-%tky
                      %control-Status     = if_abap_behv=>mk-on
                      %control-ApiMessage = if_abap_behv=>mk-on
                      Status              = ls_res-status
                      ApiMessage          = ls_res-message )
             TO lt_update.

      IF ls_res-success = abap_false.
        APPEND VALUE #( %tky = ls_key-%tky
                        %msg = new_message_with_text(
                                 severity = if_abap_behv_message=>severity-error
                                 text     = CONV string( ls_res-message ) ) )
               TO reported-edocument.
      ENDIF.
    ENDLOOP.

    MODIFY ENTITIES OF {ints['H'].lower()} IN LOCAL MODE
      ENTITY edocument UPDATE FIELDS ( Status ApiMessage ) WITH lt_update
      REPORTED DATA(ls_rep)
      FAILED   DATA(ls_fail).

    " Whatever the inner EML call reported has to be carried into this
    " handler's own REPORTED/FAILED, otherwise it is discarded and the caller
    " is told the action succeeded.
    reported-edocument = VALUE #( BASE reported-edocument ( LINES OF ls_rep-edocument ) ).
    failed-edocument   = VALUE #( BASE failed-edocument   ( LINES OF ls_fail-edocument ) ).

    READ ENTITIES OF {ints['H'].lower()} IN LOCAL MODE
      ENTITY edocument ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_final).

    result = VALUE #( FOR ls_f IN lt_final ( %tky = ls_f-%tky %param = ls_f ) ).
  ENDMETHOD.


ENDCLASS.
''')

    write(f"{bpc.lower()}.clas.abap",
          f"CLASS {bpc.lower()} DEFINITION PUBLIC ABSTRACT FINAL FOR BEHAVIOR OF {cuns['H'].lower()}.\n\n"
          "  PROTECTED SECTION.\n  PRIVATE SECTION.\nENDCLASS.\n\n\n\n"
          f"CLASS {bpc} IMPLEMENTATION.\nENDCLASS.\n")
    clas_xml(bpc, f"Projection Implementation for {cuns['H']}", defint=cuns["H"], cat="06")

    # ------------------------------------------- metadata extension: header -
    met = f"ZCDS_MET_EDOC_{tag}H"
    hrows = [r for r in fields["H"] if r["field"] != "MANDT"]
    by_facet = {}
    for r in hrows:
        by_facet.setdefault(facet_of(r["field"]), []).append(r)
    ordered = ([f for f, _ in FACETS if f in by_facet]
               + (["Other"] if "Other" in by_facet else []))

    body = ["@Metadata.layer: #CORE", "",
            "@UI: { headerInfo: { typeName:       '%s'," % v["single"],
            "                     typeNamePlural: '%s'," % v["plural"],
            "                     title:          { type: #STANDARD, value: 'DocumentNumber' },",
            "                     description:    { type: #STANDARD, value: 'SellerName' } } }", "",
            f"annotate entity {cuns['H']}", "    with", "{"]

    fl = [f"{{ id: '{f}Facet', purpose: #STANDARD,\n"
          f"                type: #IDENTIFICATION_REFERENCE, label: '{f}',\n"
          f"                targetQualifier: '{f}', position: {i * 10} }}"
          for i, f in enumerate(ordered, start=1)]
    # one line-item facet per child entity - this is the "see all the data"
    # half of the request: every table of the model is a tab on the object page
    for j, (letter, assoc, alias, label, plural) in enumerate(
            [p for p in PARTS if p[0] != "H"], start=len(ordered) + 1):
        fl.append(f"{{ id: '{alias}Facet', purpose: #STANDARD,\n"
                  f"                type: #LINEITEM_REFERENCE, label: '{plural}',\n"
                  f"                targetElement: '{assoc}', position: {j * 10} }}")
    body.append("  @UI.facet: [ " + ",\n               ".join(fl) + " ]")
    body.append("")

    pos = {}
    for r in hrows:
        f = facet_of(r["field"])
        pos[f] = pos.get(f, 0) + 10
        nm, p = camel(r["field"]), pos[f]
        lab = (note(HANA_OF["H"], r["field"]).get("desc") or
               r["field"].replace("_", " ").title())[:40].replace("'", "")
        if r["field"] in LIST_HEAD:
            crit = ", criticality: 'StatusCriticality'" if r["field"] == "STATUS" else ""
            body.append(f"  @UI: {{ lineItem:       [ {{ position: {(LIST_HEAD.index(r['field']) + 1) * 10}, "
                        f"label: '{lab}', importance: #HIGH{crit} }} ],")
            body.append(f"         identification: [ {{ position: {p}, qualifier: '{f}', label: '{lab}' }} ] }}")
        else:
            body.append(f"  @UI: {{ identification: [ {{ position: {p}, qualifier: '{f}', label: '{lab}' }} ] }}")
        body += [f"  {nm};", ""]

    body += ["  @UI: { lineItem: [ { position: 5, label: 'Seller', importance: #HIGH } ] }",
             "  SellerName;", "",
             "  @UI: { lineItem: [ { position: 6, label: 'Buyer', importance: #MEDIUM } ] }",
             "  BuyerName;", "",
             "  @UI.hidden: true", "  StatusCriticality;", ""]
    body.append("}")
    write(f"{met.lower()}.ddlx.asddlxs", "\n".join(body) + "\n")
    ddlx_xml(met, f"UI for {v['label']}")

    # -------------------------------------------- metadata extensions: kids -
    for letter, assoc, alias, label, plural in PARTS:
        if letter == "H":
            continue
        meti = f"ZCDS_MET_EDOC_{tag}{letter}"
        rows = [r for r in fields[letter] if r["field"] != "MANDT"]
        want = LIST_OF.get(letter, [])
        ib = ["@Metadata.layer: #CORE", "",
              "@UI: { headerInfo: { typeName:       '%s'," % label,
              "                     typeNamePlural: '%s' } }" % plural, "",
              f"annotate entity {cuns[letter]}", "    with", "{",
              f"  @UI.facet: [ {{ id: '{alias}Detail', purpose: #STANDARD,",
              f"                 type: #IDENTIFICATION_REFERENCE, label: '{label}',",
              "                 position: 10 } ]", ""]
        for i, r in enumerate(rows, start=1):
            nm = camel(r["field"])
            lab = (note(HANA_OF[letter], r["field"]).get("desc") or
                   r["field"].replace("_", " ").title())[:40].replace("'", "")
            if r["field"] in want:
                lp = (want.index(r["field"]) + 1) * 10
                ib.append(f"  @UI: {{ lineItem:       [ {{ position: {lp}, label: '{lab}', "
                          "importance: #HIGH }],")
                ib.append(f"         identification: [ {{ position: {i * 10}, label: '{lab}' }} ] }}")
            else:
                ib.append(f"  @UI: {{ identification: [ {{ position: {i * 10}, label: '{lab}' }} ] }}")
            ib += [f"  {nm};", ""]
        ib.append("}")
        write(f"{meti.lower()}.ddlx.asddlxs", "\n".join(ib) + "\n")
        ddlx_xml(meti, f"UI for {v['single']} {label}")

    # ---------------------------------------------------- the flat view ----
    # One row per invoice line, carrying the whole header, the whole line and
    # the document-level seller and buyer. This is the export/analysis half of
    # "a view to see all this data": the object page tabs above cover the
    # repeating groups, which cannot be flattened without multiplying rows.
    flat_i, flat_c = f"ZCDS_INT_EDOC_{tag}FLAT", f"ZCDS_CUN_EDOC_{tag}FLAT"
    hflds = [x for x in fields["H"] if x["field"] not in ("MANDT", "JSON_PAYLOAD")]
    iflds = [x for x in fields["I"] if x["field"] not in ("MANDT", "UUID", "DOCUMENTNUMBER")]
    hnames = {camel(x["field"]) for x in hflds}
    # A line element whose name already exists on the header is prefixed Line:
    # both tables carry CURRENCY, PERIOD_START and so on, and a flat row can
    # only have one of each.
    lname = {x["field"]: ("Line" + camel(x["field"])
                          if camel(x["field"]) in hnames and
                          not camel(x["field"]).startswith("Line")
                          else camel(x["field"]))
             for x in iflds}

    def sem(r, namer):
        if not r["reffield"]:
            return []
        kind = ("amount.currencyCode"
                if resolve(r["roll"])[2] == "CURR" else "quantity.unitOfMeasure")
        return [f"      @Semantics.{kind}: '{namer(r['reffield'])}'"]

    # CDS requires the key elements to be contiguous and to start at position
    # one, so both of them are emitted first - the header's UUID and the line's
    # LINE_ID - and the rest follows in table order.
    ksel = [f"  key h.{camel(r['field'])} as {camel(r['field'])},"
            for r in hflds if r["key"]]
    ksel += [f"  key i.{camel(r['field'])} as {lname[r['field']]},"
             for r in iflds if r["key"]]
    hsel = []
    for r in hflds:
        if r["key"]:
            continue
        nm = camel(r["field"])
        hsel += sem(r, camel)
        hsel.append(f"      h.{nm} as {nm},")
    isel = []
    for r in iflds:
        if r["key"]:
            continue
        nm = lname[r["field"]]
        isel += sem(r, lambda f: lname.get(f, camel(f)))
        isel.append(f"      i.{camel(r['field'])} as {nm},")

    write(f"{flat_i.lower()}.ddls.asddls", f"""/* =====================================================================
   {v['label']} - one flat row per invoice line.

   Header, line and the document-level seller and buyer, joined into a single
   wide row. This is what to read, download or build an analytical query over
   when you want to see the model's contents without walking eight tables.

   What it deliberately does NOT flatten: notes, VAT subtotals, allowances and
   charges, document references and item attributes. Each of those is 0..n per
   document OR per line, so folding them in would multiply the rows and make
   every amount on the row wrong when summed. They are reachable as tabs on the
   object page of {cuns['H']}, and each is a view of its own.

   The join to the parties is on the document-level row (LINE_ID blank) of the
   SELLER and BUYER roles - a line-level party is an item manufacturer.
   ===================================================================== */
@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: '{lab40(v["single"] + " - one row per line")}'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{{
    serviceQuality: #C,
    sizeCategory: #L,
    dataClass: #TRANSACTIONAL
}}
define view entity {flat_i}
  as select from {ints['H']} as h
    inner join      {ints['I']} as i  on  h.Uuid = i.Uuid
    left outer join {ints['P']} as sp on  h.Uuid      = sp.Uuid
                                      and sp.LineId   = ''
                                      and sp.PartyRole = 'SELLER'
    left outer join {ints['P']} as bp on  h.Uuid      = bp.Uuid
                                      and bp.LineId   = ''
                                      and bp.PartyRole = 'BUYER'
{{
{chr(10).join(ksel)}

{chr(10).join(hsel)}

{chr(10).join(isel)}

      @EndUserText.label: 'Seller'
      sp.PartyName        as SellerName,
      @EndUserText.label: 'Seller VAT ID'
      sp.VatId            as SellerVatId,
      @EndUserText.label: 'Seller Endpoint'
      sp.EndpointId       as SellerEndpointId,
      @EndUserText.label: 'Seller Street'
      sp.Street           as SellerStreet,
      @EndUserText.label: 'Seller City'
      sp.City             as SellerCity,
      @EndUserText.label: 'Seller Postal Code'
      sp.PostalZone       as SellerPostalZone,
      @EndUserText.label: 'Seller Country'
      sp.Country          as SellerCountry,
      @EndUserText.label: 'Seller Registered Name'
      sp.RegistrationName as SellerRegistrationName,
      @EndUserText.label: 'Seller Legal ID'
      sp.LegalId          as SellerLegalId,
      @EndUserText.label: 'Seller Contact'
      sp.ContactName      as SellerContactName,
      @EndUserText.label: 'Seller E-Mail'
      sp.ContactMail      as SellerContactMail,

      @EndUserText.label: 'Buyer'
      bp.PartyName        as BuyerName,
      @EndUserText.label: 'Buyer VAT ID'
      bp.VatId            as BuyerVatId,
      @EndUserText.label: 'Buyer Endpoint'
      bp.EndpointId       as BuyerEndpointId,
      @EndUserText.label: 'Buyer Street'
      bp.Street           as BuyerStreet,
      @EndUserText.label: 'Buyer City'
      bp.City             as BuyerCity,
      @EndUserText.label: 'Buyer Postal Code'
      bp.PostalZone       as BuyerPostalZone,
      @EndUserText.label: 'Buyer Country'
      bp.Country          as BuyerCountry,
      @EndUserText.label: 'Buyer Registered Name'
      bp.RegistrationName as BuyerRegistrationName,
      @EndUserText.label: 'Buyer Legal ID'
      bp.LegalId          as BuyerLegalId,
      @EndUserText.label: 'Buyer Contact'
      bp.ContactName      as BuyerContactName,
      @EndUserText.label: 'Buyer E-Mail'
      bp.ContactMail      as BuyerContactMail
}}
""")
    ddls_xml(flat_i, f"{v['single']} - all fields, one row per line")
    ddls_base(flat_i, [ints["H"], ints["I"], ints["P"]])

    # Every element spelled out: "SELECT *" is not permitted in a view entity,
    # and listing them is also the only place the currency and unit references
    # can be restated for the consumption layer.
    fsel = []
    for ln in ksel:
        fsel.append("  key " + ln.split(" as ")[-1].rstrip(",") + ",")
    for ln in hsel + isel:
        t = ln.strip()
        if t.startswith("@"):
            fsel.append("      " + t)
        else:
            fsel.append("      " + t.split(" as ")[-1].rstrip(",") + ",")
    for role in ("Seller", "Buyer"):
        for col in ("Name", "VatId", "EndpointId", "Street", "City", "PostalZone",
                    "Country", "RegistrationName", "LegalId", "ContactName",
                    "ContactMail"):
            fsel.append(f"      {role}{col},")
    fsel[-1] = fsel[-1].rstrip(",")

    write(f"{flat_c.lower()}.ddls.asddls", f"""@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: '{lab40(v["single"] + " - All Data")}'
@Metadata.ignorePropagatedAnnotations: true
@Metadata.allowExtensions: true
@Search.searchable: true
@ObjectModel.usageType:{{
    serviceQuality: #C,
    sizeCategory: #L,
    dataClass: #TRANSACTIONAL
}}
define view entity {flat_c} as select from {flat_i}
{{
{chr(10).join(fsel)}
}}
""")
    ddls_xml(flat_c, f"{v['label']} - All Data")
    ddls_base(flat_c, [flat_i])

    # a plain list report over the flat view: all columns, filter on the ones
    # that identify a document
    fmet = f"ZCDS_MET_EDOC_{tag}FLAT"
    fb = ["@Metadata.layer: #CORE", "",
          "@UI: { headerInfo: { typeName:       '%s Line'," % v["single"],
          "                     typeNamePlural: '%s Lines' } }" % v["single"], "",
          f"annotate entity {flat_c}", "    with", "{"]
    FLAT_LIST = ["DocumentNumber", "LineId", "IssueDate", "SellerName", "BuyerName",
                 "ItemName", "Quantity", "UnitIso", "PriceAmount", "LineNetAmount",
                 "LineTaxAmount", "PayableAmount", "Currency", "Status"]
    FLAT_SEL = ["DocumentNumber", "IssueDate", "SellerName", "BuyerName", "Status"]
    for i, nm in enumerate(FLAT_LIST, start=1):
        fb.append(f"  @UI.lineItem: [ {{ position: {i * 10}, importance: #HIGH }} ]")
        if nm in FLAT_SEL:
            fb.append(f"  @UI.selectionField: [ {{ position: {(FLAT_SEL.index(nm) + 1) * 10} }} ]")
        fb += [f"  {nm};", ""]
    fb.append("}")
    write(f"{fmet.lower()}.ddlx.asddlxs", "\n".join(fb) + "\n")
    ddlx_xml(fmet, f"UI for {v['label']} All Data")

    # ------------------------------------------------------------ services -
    sd, sb = f"ZSD_EDOC_{tag}", f"ZSB_EDOC_{tag}"
    srvd(sd, f"Service Definition for {v['label']}",
         [(cuns["H"], "EDocument")]
         + [(cuns[l], al) for l, _a, al, *_ in PARTS if l != "H"]
         + [(v["acth"], "VHActionType"), ("ZVH_EINV_STATUS", "VHStatus"),
            ("ZVH_EINV_REASONCODE", "VHReasonCode")])
    srvb(sb, f"Service Binding for {v['label']}", sd)

    sdf, sbf = f"ZSD_EDOC_{tag}FLAT", f"ZSB_EDOC_{tag}FLAT"
    srvd(sdf, f"All Data Query for {v['label']}", [(flat_c, "EDocumentData")])
    srvb(sbf, f"All Data Query for {v['label']}", sdf)

    print(f"  {tag:3s} tables={len(PARTS)} header={len(hrows)} "
          f"fields total={sum(len(fields[l]) - 1 for l, *_ in PARTS)} "
          f"-> {cuns['H']}, {flat_c}, {sd}, {sdf}")

print("normalised e-document stack written to", OUT)
