#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Merge ZZCLR_ELT (the converted /CLR/ELT + /CLR/INSTRUMENTATION) and
ZZCLR_EINVOICE_ELT (the converted /CLR/EINVOICE_ELT) into a single ABAP
package, ZZCLR_GEINV, for one-repo / one-transport deployment.

Safe to do because:
  * there are ZERO object-name collisions between the two sets
  * the cloud ZZCLR_ELT contains no reference back to e-invoice objects
    (the circular dependency of the HANA original was already broken)

Dropped on the way, per the agreed scope:
  * the ZGSTELT_* generation - a parallel, config-only build superseded by
    the Z* generation, with no event log, no APJ jobs, no BAL logging and
    no business catalogs
  * its behaviour classes, which are named ZBP_GSTELT_* and so do not match
    a naive 'zgstelt*' filter
  * development scratch left in the delivered package
  * the .apis.xml C1 release contracts: with everything in one package
    nothing needs releasing, and a released object is a frozen API

Every drop is verified: if a surviving object still references a dropped
one, the merge fails rather than producing a package that will not activate.
"""
import os
import re
import shutil
import sys
from collections import defaultdict

SP = ("/tmp/claude-0/-home-claude/72239396-9680-5f1b-b64f-4de20ad4c92c/scratchpad/"
      "pc/integration-sap-public-cloud-elt-WEIKFIELD-ELT/src")
EINV = "/home/claude/ZZCLR_EINVOICE_ELT/src"
DEST_ROOT = "/home/claude/ZZCLR_GEINV"
DEST = os.path.join(DEST_ROOT, "src")

BOM = "﻿"
HDR = '<?xml version="1.0" encoding="utf-8"?>\n'

PACKAGE = "ZZCLR_GEINV"
PACKAGE_TEXT = "Clear Global e-Invoice (Public Cloud)"


def rd(p):
    return open(p, encoding="utf-8-sig", errors="replace").read()


def objname(fn):
    """abapGit filename -> object name. Handles the padded '<name> type.apis.xml'."""
    m = re.match(r"^(.*?)\s{2,}[a-z0-9]+\.apis\.xml$", fn)
    if m:
        return m.group(1).strip().upper()
    return fn.split(".")[0].upper()


# ------------------------------------------------------------------ drops --
def is_gstelt_generation(fn):
    n = objname(fn).lower()
    return n.startswith("zgstelt") or n.startswith("zbp_gstelt")


def covers_dropped_service(fn):
    """A .sush.xml is the IAM authorization default generated for one service
    binding or job catalog entry. The two generated for ZGSTELT_SB_CONFIG go
    with that generation; the ones for the APJ job catalogs stay."""
    if not fn.endswith(".sush.xml"):
        return False
    body = rd(os.path.join(SP, fn))
    return bool(re.search(r"ZGSTELT", body, re.I))


SCRATCH = {
    # dev leftovers shipped in the delivered package
    "ZCL_SELECT_TESTING",      # body commented out, pure scratch
    "ZCDS_ADDRESS_TEST1",      # duplicate of ZCDS_ADDRESS_2, yet C1-released
    "ZCDS_V",                  # @EndUserText.label: 'cds'
    "ZTELT_CONFIG_DR",         # draft table nothing references
}

drops, keeps = [], []
for fn in sorted(os.listdir(SP)):
    if fn == "package.devc.xml":
        continue
    if fn.endswith(".apis.xml"):
        drops.append((fn, "C1 release contract - single package, nothing to release"))
        continue
    if is_gstelt_generation(fn):
        drops.append((fn, "ZGSTELT generation"))
        continue
    if covers_dropped_service(fn):
        drops.append((fn, "ZGSTELT generation (IAM object for its service binding)"))
        continue
    if objname(fn) in SCRATCH:
        drops.append((fn, "development scratch"))
        continue
    keeps.append(fn)

# ------------------------------------------ verify nothing dangles on drop --
dropped_objects = {objname(f) for f, _ in drops if not f.endswith(".apis.xml")}
# keep only names distinctive enough to grep for
checkable = {o for o in dropped_objects if len(o) > 6}

dangling = defaultdict(list)
for fn in keeps:
    body = rd(os.path.join(SP, fn))
    # strip ABAP comments so a comment mentioning a dropped object is not a hit
    if fn.endswith(".abap"):
        body = "\n".join(l for l in body.splitlines()
                         if not l.lstrip().startswith(("*", '"')))
    for obj in checkable:
        if re.search(r"(?<![\w/])" + re.escape(obj) + r"(?![\w])", body, re.I):
            dangling[fn].append(obj)

if dangling:
    print("MERGE ABORTED - surviving objects reference dropped ones:\n")
    for fn, objs in sorted(dangling.items()):
        print(f"  {fn}")
        for o in sorted(set(objs)):
            print(f"      -> {o}")
    sys.exit(1)

# --------------------------------------------------------------- do it -----
if os.path.exists(DEST_ROOT):
    shutil.rmtree(DEST_ROOT)
os.makedirs(DEST)

n_elt = 0
for fn in keeps:
    shutil.copy2(os.path.join(SP, fn), os.path.join(DEST, fn))
    n_elt += 1

n_einv = 0
for fn in sorted(os.listdir(EINV)):
    if fn == "package.devc.xml":
        continue
    if os.path.exists(os.path.join(DEST, fn)):
        print(f"  ! unexpected collision: {fn}")
        sys.exit(1)
    shutil.copy2(os.path.join(EINV, fn), os.path.join(DEST, fn))
    n_einv += 1

# ------------------------------------------ retarget the ABAP package name --
# The ZZCLR_ELT IAM objects name three different packages internally
# (ZCLRELT, ZGSTELT, ZZCLR_ELT) - an inconsistency in the source. All of them
# become the one real package.
retargeted = 0
for fn in sorted(os.listdir(DEST)):
    p = os.path.join(DEST, fn)
    body = rd(p)
    new = re.sub(r"<PACKAGE_NAME>[^<]*</PACKAGE_NAME>",
                 f"<PACKAGE_NAME>{PACKAGE}</PACKAGE_NAME>", body)
    new = re.sub(r"<DEVCLASS>[^<]*</DEVCLASS>",
                 f"<DEVCLASS>{PACKAGE}</DEVCLASS>", new)
    if new != body:
        open(p, "w", encoding="utf-8", newline="\n").write(new)
        retargeted += 1

# ------------------------------- one minimal edit to the inherited source --
# @EndUserText.label is typed STRING(40) and ZSD_ELT_CONFIG ships a 42-character
# one, which stops it activating. Everything else inherited from ZZCLR_ELT is
# copied byte for byte; this is capped because an object that will not activate
# would block the whole import.
capped = 0
for fn in sorted(os.listdir(DEST)):
    if not fn.endswith((".srvd.srvdsrv", ".ddls.asddls", ".ddlx.asddlxs")):
        continue
    p = os.path.join(DEST, fn)
    body = rd(p)
    def cap(m):
        global capped
        if len(m.group(1)) <= 40:
            return m.group(0)
        capped += 1
        return "@EndUserText.label: '" + m.group(1)[:40].rstrip(" -,/(") + "'"
    new_body = re.sub(r"@EndUserText\.label:\s*'([^']*)'", cap, body)
    if new_body != body:
        open(p, "w", encoding="utf-8", newline="\n").write(new_body)

# ------------------------------------------------------- package descriptor -
open(os.path.join(DEST, "package.devc.xml"), "w", encoding="utf-8", newline="\n").write(
    BOM + HDR
    + '<abapGit version="v1.0.0" serializer="LCL_OBJECT_DEVC" serializer_version="v1.0.0">\n'
      ' <asx:abap xmlns:asx="http://www.sap.com/abapxml" version="1.0">\n'
      '  <asx:values>\n   <DEVC>\n'
    + f"    <CTEXT>{PACKAGE_TEXT}</CTEXT>\n"
    + '    <LANGUAGE>E</LANGUAGE>\n    <MASTERLANG>E</MASTERLANG>\n'
      '    <SRV_CHECK>X</SRV_CHECK>\n   </DEVC>\n'
      '  </asx:values>\n </asx:abap>\n</abapGit>\n')

open(os.path.join(DEST_ROOT, ".abapgit.xml"), "w", encoding="utf-8", newline="\n").write(
    BOM + HDR
    + '<asx:abap xmlns:asx="http://www.sap.com/abapxml" version="1.0">\n'
      ' <asx:values>\n  <DATA>\n'
      '   <MASTER_LANGUAGE>E</MASTER_LANGUAGE>\n'
      '   <STARTING_FOLDER>/src/</STARTING_FOLDER>\n'
      '   <FOLDER_LOGIC>FULL</FOLDER_LOGIC>\n'
      '   <IGNORE>\n'
      '    <item>/.gitignore</item>\n    <item>/LICENSE</item>\n'
      '    <item>/README.md</item>\n    <item>/CONVERSION_DESIGN.md</item>\n'
      '    <item>/MERGE_REPORT.md</item>\n    <item>/CODE_REVIEW.md</item>\n'
      '    <item>/package.json</item>\n'
      '    <item>/.travis.yml</item>\n    <item>/.gitlab-ci.yml</item>\n'
      '    <item>/abaplint.json</item>\n    <item>/azure-pipelines.yml</item>\n'
      '   </IGNORE>\n  </DATA>\n </asx:values>\n</asx:abap>\n')

# ------------------------------------------------------------------ report --
by_reason = defaultdict(int)
for _, why in drops:
    by_reason[why] += 1

print(f"package      : {PACKAGE}")
print(f"from ZZCLR_ELT          : {n_elt:4d} files")
print(f"from ZZCLR_EINVOICE_ELT : {n_einv:4d} files")
print(f"total                   : {len(os.listdir(DEST)):4d} files")
print(f"PACKAGE_NAME retargeted in {retargeted} file(s)")
print("\ndropped:")
for why, n in sorted(by_reason.items(), key=lambda x: -x[1]):
    print(f"  {n:4d}  {why}")
print(f"  ----\n  {len(drops):4d}  total")
print("\nno surviving object references a dropped one")
print(f"{capped} over-long @EndUserText.label(s) capped to 40 characters")

with open("/home/claude/gen/merge_drops.txt", "w") as f:
    for fn, why in drops:
        f.write(f"{why}\t{fn}\n")
