# -*- coding: utf-8 -*-
"""Field name -> CDS element name for the /CLR/EINV_ELT_AP model."""
WHOLE = {
    "MANDT": "Client", "UUID": "Uuid", "DOCUMENTNUMBER": "DocumentNumber",
    "DOCUMENTID": "DocumentId", "LINE_ID": "LineId", "SEQ": "Sequence",
    "ACC_COST": "AccountingCost", "LINE_ACC_COST": "LineAccountingCost",
    "TAX_EXCL_AMT": "TaxExclusiveAmount", "TAX_INCL_AMT": "TaxInclusiveAmount",
    "COMMENT_TXT": "CommentText", "JSON_PAYLOAD": "JsonPayload",
    "API_MESSAGE": "ApiMessage", "UBL_VERSION": "UblVersionId",
    "INV_TYPE_CODE": "InvoiceTypeCode", "INV_TYPE_NAME": "InvoiceTypeName",
    "CREATED_ON": "CreatedOn", "CREATED_AT": "CreatedAt", "CREATED_BY": "CreatedBy",
    "CHANGED_ON": "ChangedOn", "CHANGED_AT": "ChangedAt", "CHANGED_BY": "ChangedBy",
    "LINE_COUNT": "LineCount", "PARTY_ROLE": "PartyRole", "REF_TYPE": "ReferenceType",
    "ATTR_TYPE": "AttributeType", "PAY_TERMS_DUE": "PaymentTermsDueDate",
}
EXP = {
    "ID": "Id", "AMT": "Amount", "RSN": "Reason", "SCH": "Scheme",
    "ACC": "Account", "ATTR": "Attribute", "CURR": "Currency", "DEL": "Delivery",
    "EXE": "Exemption", "DESC": "Description", "EXC": "Exchange", "CAT": "Category",
    "DOC": "Document", "AC": "AllowanceCharge", "QTY": "Quantity",
    "SO": "SalesOrder", "STD": "Standard", "SUBDIV": "Subdivision",
    "EXCL": "Excluding", "INCL": "Including", "EXT": "Extension",
    "IND": "Indicator", "INSTR": "Instruction", "INV": "Invoice",
    "LOC": "Location", "ADD": "Additional", "ADDR": "Address", "ALLOW": "Allowance", "RCVD": "Received",
    "RND": "Rounding", "SRC": "Source", "TGT": "Target", "TS": "Timestamp",
    "TXT": "Text", "TEL": "Telephone", "VER": "Version", "ATT": "Attachment",
    "REG": "Registration", "PAY": "Payment", "REF": "Reference",
    "TAXCUR": "TaxCurrency", "MIME": "MimeType", "UBL": "Ubl", "SBDH": "Sbdh",
    "VAT": "Vat", "ISO": "Iso", "SAP": "Sap", "API": "Api", "JSON": "Json",
    "URI": "Uri", "NUM": "Number", "PCT": "Percent",
}
def camel(f):
    f = f.upper()
    if f in WHOLE:
        return WHOLE[f]
    out = []
    for p in f.split("_"):
        out.append(EXP.get(p, p.capitalize()))
    return "".join(out)
