#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Static consistency check of the generated ZZCLR_EINVOICE_ELT package."""
import os
import re
import sys
from collections import defaultdict

SRC = os.environ.get("CHECK_SRC", "/home/claude/ZZCLR_EINVOICE_ELT/src")
files = sorted(os.listdir(SRC))
problems = []
warnings = []


def read(n):
    with open(os.path.join(SRC, n), encoding="utf-8-sig") as f:
        return f.read()


def objs(suffix):
    return {f[: -len(suffix)].upper() for f in files if f.endswith(suffix)}


domains = objs(".doma.xml")
dtels = objs(".dtel.xml")
tables = {n for n in objs(".tabl.xml")}
ttyps = objs(".ttyp.xml")
cds = objs(".ddls.asddls")
bdefs = objs(".bdef.asbdef")
ddlx = objs(".ddlx.asddlxs")
classes = objs(".clas.abap")
intfs = objs(".intf.abap")

# Objects consumed from other packages / SAP standard. Anything referenced
# that is NOT local must be on this list, or it is flagged.
EXTERNAL = {
    # released SAP CDS views
    "I_JOURNALENTRY", "I_BILLINGDOCUMENT",
    # C1-released objects of package ZZCLR_ELT
    "ZTELT_CONFIG", "ZCL_ELT", "ZCL_INSTRU_EVENT_CLASS",
    # built-in DDIC types used without a data element
    "MANDT", "CLIENT",
}

# --------------------------------------------------- 1. DDIC referential ----
for f in files:
    if f.endswith(".tabl.xml"):
        src = read(f)
        for roll in re.findall(r"<ROLLNAME>([^<]+)</ROLLNAME>", src):
            r = roll.upper()
            if r not in dtels and r not in ttyps and r not in tables and r not in EXTERNAL:
                problems.append(f"{f}: field references unknown data element/type {roll}")
    if f.endswith(".dtel.xml"):
        src = read(f)
        for dom in re.findall(r"<DOMNAME>([^<]+)</DOMNAME>", src):
            if dom.upper() not in domains:
                problems.append(f"{f}: references unknown domain {dom}")
    if f.endswith(".ttyp.xml"):
        src = read(f)
        # ROWKIND S = structured row (a structure/table), E = elementary row
        # (a data element, which is how a JSON array of scalars is typed).
        elementary = "<ROWKIND>E</ROWKIND>" in src
        allowed = dtels if elementary else tables
        kind = "data element" if elementary else "structure/table"
        for row in re.findall(r"<ROWTYPE>([^<]+)</ROWTYPE>", src):
            if row.upper() not in allowed and row.upper() not in EXTERNAL:
                problems.append(f"{f}: ROWTYPE {row} is not a known {kind}")

# ------------------------------------------------------ 2. CDS data sources --
LOCAL_ENTITIES = cds | tables
for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    src = read(f)
    body = re.sub(r"/\*.*?\*/", "", src, flags=re.S)
    for m in re.finditer(
        r"(?:select\s+from|projection\s+on|join|association\s+(?:\[[^\]]*\]\s*)?to(?:\s+parent)?"
        r"|composition\s+\[[^\]]*\]\s+of)\s+"
        r"([A-Za-z_][A-Za-z0-9_]*)",
        body, re.I,
    ):
        ent = m.group(1).upper()
        if ent in ("PARENT", "OUTER", "INNER", "LEFT", "RIGHT"):
            continue
        if ent not in LOCAL_ENTITIES and ent not in EXTERNAL:
            problems.append(f"{f}: unknown data source / association target {m.group(1)}")

    # every CDS needs its abapGit wrapper
    base = f[: -len(".ddls.asddls")]
    for need in (".ddls.xml", ".ddls.baseinfo"):
        if base + need not in files:
            problems.append(f"{f}: missing {need} wrapper")

# ------------------------------------------------------------- 3. BDEFs -----
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    src = read(f)
    body = re.sub(r"/\*.*?\*/", "", src, flags=re.S)
    for cls in re.findall(r"implementation\s+in\s+class\s+([A-Za-z0-9_]+)", body, re.I):
        if cls.upper() not in classes:
            problems.append(f"{f}: behaviour class {cls} does not exist")
    for tab in re.findall(r"persistent\s+table\s+([A-Za-z0-9_]+)", body, re.I):
        if tab.upper() not in tables:
            problems.append(f"{f}: persistent table {tab} does not exist")
    for ent in re.findall(r"define\s+behavior\s+for\s+([A-Za-z0-9_]+)", body, re.I):
        if ent.upper() not in cds:
            problems.append(f"{f}: behaviour defined for unknown entity {ent}")
    for par in re.findall(r"parameter\s+([A-Za-z0-9_]+)", body, re.I):
        if par.upper() not in cds:
            problems.append(f"{f}: action parameter entity {par} does not exist")
    base = f[: -len(".bdef.asbdef")]
    if base + ".bdef.xml" not in files:
        problems.append(f"{f}: missing .bdef.xml wrapper")

# ------------------------------------------------- 4. metadata extensions ---
for f in files:
    if not f.endswith(".ddlx.asddlxs"):
        continue
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    for ent in re.findall(r"annotate\s+entity\s+([A-Za-z0-9_]+)", body, re.I):
        if ent.upper() not in cds:
            problems.append(f"{f}: annotates unknown entity {ent}")
    base = f[: -len(".ddlx.asddlxs")]
    if base + ".ddlx.xml" not in files:
        problems.append(f"{f}: missing .ddlx.xml wrapper")

# -------------------------------------------------- 5. class / intf pairs ---
for f in files:
    if f.endswith(".clas.abap"):
        base = f[: -len(".clas.abap")]
        if base + ".clas.xml" not in files:
            problems.append(f"{f}: missing .clas.xml wrapper")
    if f.endswith(".intf.abap"):
        base = f[: -len(".intf.abap")]
        if base + ".intf.xml" not in files:
            problems.append(f"{f}: missing .intf.xml wrapper")
for f in files:
    if f.endswith(".clas.xml"):
        base = f[: -len(".clas.xml")]
        if base + ".clas.abap" not in files:
            problems.append(f"{f}: .clas.xml without source")

# ------------------------------------- 6. ABAP references to own artefacts ---
OWN_PREFIX = re.compile(r"\b(z(?:cl|if|bp|str|de|do|te|cds|vh|sd|sb|ajc|ajt|ajl|einv)[a-z0-9_]*)\b", re.I)
KNOWN = (classes | intfs | tables | ttyps | cds | dtels | domains | bdefs | ddlx
         | EXTERNAL
         | {n for n in objs(".srvd.srvdsrv")}
         | {"ZEINV_MSG"}
         | {f[: -len(".sajc.json")].upper() for f in files if f.endswith(".sajc.json")}
         | {f[: -len(".sajt.json")].upper() for f in files if f.endswith(".sajt.json")}
         | {"ZAJL_EINV_EXECUTION"})

for f in files:
    if not (f.endswith(".abap")):
        continue
    src = read(f)
    # strip full-line and inline ABAP comments plus string literals
    lines = []
    for ln in src.splitlines():
        s = ln.lstrip()
        if s.startswith('*') or s.startswith('"'):
            continue
        ln = re.sub(r'".*$', "", ln)
        ln = re.sub(r"'[^']*'", "''", ln)
        ln = re.sub(r"\|[^|]*\|", "||", ln)
        lines.append(ln)
    body = "\n".join(lines)
    for m in OWN_PREFIX.finditer(body):
        name = m.group(1).upper()
        if name in KNOWN:
            continue
        # local handler / saver classes and RAP-generated derived types
        if name.startswith(("LHC_", "LSC_")):
            continue
        problems.append(f"{f}: references unknown object {m.group(1)}")

# ------------------------------------------- 7. service definition exposure --
for f in files:
    if not f.endswith(".srvd.srvdsrv"):
        continue
    body = read(f)
    for ent in re.findall(r"expose\s+([A-Za-z0-9_]+)\s+as", body, re.I):
        if ent.upper() not in cds:
            problems.append(f"{f}: exposes unknown entity {ent}")
    base = f[: -len(".srvd.srvdsrv")]
    if base + ".srvd.xml" not in files:
        problems.append(f"{f}: missing .srvd.xml wrapper")

# ------------------------------- 8. APJ job classes implement the contract --
import json as _json
for f in files:
    if not f.endswith(".sajc.json"):
        continue
    doc = _json.loads(read(f))
    cls = doc["generalInformation"]["className"]
    if cls.upper() not in classes:
        problems.append(f"{f}: job class {cls} does not exist")
        continue
    src = read(cls.lower() + ".clas.abap")
    for iface in ("if_apj_dt_exec_object", "if_apj_rt_exec_object"):
        if iface not in src.lower():
            problems.append(f"{cls}: does not implement {iface}")

# ----------------------------- 9. non-released APIs must not have survived --
FORBIDDEN = [
    (r"\bcl_gui_alv_grid\b", "cl_gui_alv_grid"),
    (r"\bcl_salv_table\b", "cl_salv_table"),
    (r"\bcl_gui_frontend_services\b", "cl_gui_frontend_services"),
    (r"\bcl_http_client\b", "cl_http_client"),
    (r"\bcl_rest_http_client\b", "cl_rest_http_client"),
    (r"REUSE_ALV", "REUSE_ALV_* function module"),
    (r"\bSCMS_DOWNLOAD\b", "SCMS_DOWNLOAD"),
    (r"^\s*CALL\s+FUNCTION\b", "CALL FUNCTION"),
    (r"^\s*CALL\s+TRANSACTION\b", "CALL TRANSACTION"),
    (r"^\s*SUBMIT\b", "SUBMIT"),
    (r"^\s*COMMIT\s+WORK\b", "COMMIT WORK"),
    (r"^\s*ROLLBACK\s+WORK\b", "ROLLBACK WORK"),
    (r"^\s*WAIT\s+UP\s+TO\b", "WAIT UP TO"),
    (r"\bENQUEUE_", "ENQUEUE_*"),
    (r"\bDEQUEUE_", "DEQUEUE_*"),
    (r"^\s*MESSAGE\s+[eiswax]\d", "MESSAGE <type><number>"),
    (r"\bsy-batch\b", "sy-batch"),
    (r"\bsy-sysid\b", "sy-sysid"),
    (r"\bsy-mandt\b", "sy-mandt"),
    (r"\bsy-datum\b", "sy-datum"),
    (r"\bsy-uzeit\b", "sy-uzeit"),
    (r"\bsy-repid\b", "sy-repid"),
    (r"\bsy-ucomm\b", "sy-ucomm"),
    (r"\bsy-tcode\b", "sy-tcode"),
    (r"\bLOOP\s+AT\s+SCREEN\b", "LOOP AT SCREEN"),
    (r"^\s*(FORM|PERFORM)\b", "FORM/PERFORM"),
    (r"\bFROM\s+(bkpf|bseg|vbrk|vbrp|kna1|lfa1|t001|mkpf)\b", "direct read of a non-released table"),
]
for f in files:
    if not f.endswith(".abap"):
        continue
    for i, ln in enumerate(read(f).splitlines(), 1):
        s = ln.lstrip()
        if s.startswith('*') or s.startswith('"'):
            continue           # a comment describing the old code is fine
        code = re.sub(r'".*$', "", ln)
        for pat, label in FORBIDDEN:
            if re.search(pat, code, re.I | re.M):
                problems.append(f"{f}:{i}: non-released construct {label} -> {code.strip()[:90]}")

# -------------------------------------------- 10. table field / CDS alignment
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    for blk in re.finditer(r"mapping\s+for\s+([A-Za-z0-9_]+)\s*\{(.*?)\}", body, re.S | re.I):
        tab, inner = blk.group(1).upper(), blk.group(2)
        if tab.lower() + ".tabl.xml" not in files:
            continue
        tsrc = read(tab.lower() + ".tabl.xml")
        tfields = {x.upper() for x in re.findall(r"<FIELDNAME>([^<]+)</FIELDNAME>", tsrc)}
        for cdsf, dbf in re.findall(r"([A-Za-z0-9_]+)\s*=\s*([A-Za-z0-9_]+)\s*;", inner):
            if dbf.upper() not in tfields:
                problems.append(f"{f}: mapping {cdsf} = {dbf} - {tab} has no field {dbf}")

# ---- 11. managed BO: every renamed CDS element must be mapped -------------
# RAP resolves a CDS element to a table column by case-insensitive name.
# An element aliased to something other than its column (issue_dt ->
# IssueDate) must appear in the BDEF mapping block or activation fails.
def cds_aliases(view):
    """{CdsElement: db_column} for a view selecting directly from a table."""
    f = view.lower() + ".ddls.asddls"
    if f not in files:
        return {}
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    body = re.sub(r"//.*$", "", body, flags=re.M)
    out = {}
    for m in re.finditer(r"(?:^|\s)(\w+)\s+as\s+(\w+)\s*,", body):
        out[m.group(2)] = m.group(1)
    return out


for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    if "projection" in body.split("\n")[0].lower():
        continue
    for blk in re.finditer(
            r"define\s+behavior\s+for\s+(\w+).*?persistent\s+table\s+(\w+)(.*?)(?=define\s+behavior|\Z)",
            body, re.S | re.I):
        view, tab, sect = blk.group(1), blk.group(2).upper(), blk.group(3)
        mapped = {m.group(1) for m in re.finditer(r"(\w+)\s*=\s*\w+\s*;", sect)}
        tf = tab.lower() + ".tabl.xml"
        if tf not in files:
            continue
        cols = {x.upper() for x in re.findall(r"<FIELDNAME>([^<]+)</FIELDNAME>", read(tf))}
        for elem, col in cds_aliases(view).items():
            if elem.upper() == col.upper():
                continue                      # implicit mapping works
            if elem in mapped:
                continue                      # explicitly mapped
            if col.upper() not in cols:
                continue                      # calculated / association field
            problems.append(
                f"{f}: {view}.{elem} is aliased from {tab}.{col.upper()} but has no "
                f"mapping entry - RAP maps by name and would not resolve it")


# ---------------------- 12. currency / quantity reference fields ------------
# A CURR column must point at a CUKY column and a QUAN column at a UNIT
# column, or DDIC refuses to activate the table. This is the check that would
# have caught ZTEINV_APITEM pointing every amount at INV_CURR, which is typed
# BP_CURR - an amount whose NAME says currency.
for f in files:
    if not f.endswith(".tabl.xml"):
        continue
    src = read(f)
    rows = re.findall(r"<DD03P>(.*?)</DD03P>", src, re.S)
    def _dom_of(roll):
        df = roll.lower() + ".dtel.xml"
        if df not in files:
            return None
        m = re.search(r"<DOMNAME>([^<]+)</DOMNAME>", read(df))
        if not m:
            return None
        of = m.group(1).lower() + ".doma.xml"
        if of not in files:
            return None
        t = re.search(r"<DATATYPE>([^<]+)</DATATYPE>", read(of))
        return t.group(1).upper() if t else None
    kind, reff = {}, {}
    for r in rows:
        fn = re.search(r"<FIELDNAME>([^<]+)", r)
        rn = re.search(r"<ROLLNAME>([^<]+)", r)
        if not fn or not rn:
            continue
        kind[fn.group(1).upper()] = _dom_of(rn.group(1))
        rf = re.search(r"<REFFIELD>([^<]+)", r)
        rt = re.search(r"<REFTABLE>([^<]+)", r)
        if rf:
            reff[fn.group(1).upper()] = (rt.group(1).upper() if rt else None,
                                         rf.group(1).upper())
    for fld, (rtab, rfld) in reff.items():
        want = {"CURR": "CUKY", "QUAN": "UNIT"}.get(kind.get(fld))
        if not want:
            continue
        if rtab and rtab != f[: -len(".tabl.xml")].upper():
            continue                       # reference into another table
        if fld == rfld:
            problems.append(f"{f}: {fld} references itself as its "
                            f"{'currency' if want == 'CUKY' else 'unit'} field")
        elif kind.get(rfld) != want:
            problems.append(
                f"{f}: {fld} is {kind.get(fld)} but its reference field {rfld} is "
                f"{kind.get(rfld)}, not {want} - DDIC will not activate the table")

# -------------------------- 13. @Semantics reference elements ---------------
for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    body = read(f)
    elems = set(cds_aliases(f[: -len(".ddls.asddls")].upper()).keys())
    for m in re.finditer(r"@Semantics\.(amount\.currencyCode|quantity\.unitOfMeasure)\s*:\s*'(\w+)'"
                         r"\s*\n\s*(?:@[^\n]*\n\s*)*(?:key\s+)?[\w.]+\s+as\s+(\w+)", body):
        ref, own = m.group(2), m.group(3)
        if ref == own:
            problems.append(f"{f}: {own} is annotated against itself - the reference "
                            f"element must be a different, CUKY/UNIT typed element")
        elif elems and ref not in elems:
            problems.append(f"{f}: @Semantics of {own} names {ref}, which is not an "
                            f"element of this view")

# -------------- 14. projection BDEF needs a transactional provider ----------
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    body = read(f)
    if not re.match(r"\s*projection\s*;", body):
        continue
    for ent in re.findall(r"define\s+behavior\s+for\s+(\w+)", body, re.I):
        vf = ent.lower() + ".ddls.asddls"
        if vf not in files:
            continue
        vb = read(vf)
        # Only the ROOT projection declares the contract; a child inherits it,
        # and declaring it on a view that carries `redirected to parent` is
        # rejected outright.
        if "redirected to parent" in vb:
            continue
        if "provider contract transactional_query" not in vb:
            problems.append(f"{vf}: {ent} carries a projection behaviour definition but "
                            f"does not declare `provider contract transactional_query`")

# ---------- 15. instance-authorization handler must fill its RESULT ---------
for f in files:
    if not f.endswith(".clas.locals_imp.abap"):
        continue
    body = read(f)
    for m in re.finditer(r"METHOD\s+get_instance_authorizations\s*\.(.*?)ENDMETHOD",
                         body, re.S | re.I):
        code = "\n".join(l for l in m.group(1).splitlines()
                         if l.strip() and not l.strip().startswith(('"', '*')))
        if "result" not in code.lower():
            problems.append(f"{f}: get_instance_authorizations never fills RESULT - "
                            f"every operation on every instance would be denied")

# ------------ 16. key fields must not be unconditionally readonly ----------
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    # Strip BDL comments FIRST. A comment that quotes the construct it is
    # explaining - "`field ( readonly )` is unconditional and blocks CREATE" -
    # otherwise matches the pattern and the rule reports the comment as code.
    # Rule 39/40 already does this; this one did not, and the explanatory
    # comments this conversion is full of made that a question of time.
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    body = re.sub(r"//.*$", "", body, flags=re.M)
    for blk in re.finditer(r"define\s+behavior\s+for\s+(\w+)[^{]*?persistent\s+table\s+(\w+)"
                           r"(.*?)\n\}", body, re.S | re.I):
        ent, tab, sect = blk.group(1), blk.group(2).upper(), blk.group(3)
        tf = tab.lower() + ".tabl.xml"
        if tf not in files:
            continue
        tsrc = read(tf)
        keycols = {re.search(r"<FIELDNAME>([^<]+)", r).group(1).upper()
                   for r in re.findall(r"<DD03P>(.*?)</DD03P>", tsrc, re.S)
                   if "<KEYFLAG>X</KEYFLAG>" in r
                   and re.search(r"<FIELDNAME>([^<]+)", r)}
        amap = {k.upper(): v.upper()
                for k, v in re.findall(r"(\w+)\s*=\s*(\w+)\s*;", sect)}
        # Only meaningful where a CREATE exists. The message this rule
        # encodes is "an EML create with external keys would insert empty
        # keys" - and a behaviour that declares no create, and is not the
        # create target of an association, has no such create to break.
        # ZCDS_INT_EINV_ZIP is read-only on purpose (the table is written
        # from the save phase, not through the BO), and unconditional
        # readonly on its keys is correct there; rule 39/40 still insists
        # every key carries SOME readonly declaration, which is the half of
        # this that always applies.
        creates = re.search(r"^\s*create\s*;", sect, re.I | re.M) or \
                  re.search(r"association\s+\w+\s*\{[^}]*\bcreate\b", sect, re.I)
        if not creates:
            continue
        for ro in re.finditer(r"field\s*\(\s*readonly\s*\)([^;]*);", sect, re.I):
            for name in re.findall(r"\w+", ro.group(1)):
                col = amap.get(name.upper(), name.upper())
                if col in keycols:
                    problems.append(
                        f"{f}: {ent} marks key field {name} as `field ( readonly )` - "
                        f"that also blocks it on CREATE, so an EML create with external "
                        f"keys would insert empty keys")

# ------- 17. `use ...` in a projection needs the base to declare it --------
base_of = {}
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    body = read(f)
    if re.match(r"\s*projection\s*;", body):
        continue
    for blk in re.finditer(r"define\s+behavior\s+for\s+(\w+)(.*?)\n\}", body, re.S | re.I):
        base_of[blk.group(1).upper()] = blk.group(2)

for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    body = read(f)
    if not re.match(r"\s*projection\s*;", body):
        continue
    for blk in re.finditer(r"define\s+behavior\s+for\s+(\w+)(.*?)\n\}", body, re.S | re.I):
        proj, sect = blk.group(1).upper(), blk.group(2)
        vf = proj.lower() + ".ddls.asddls"
        if vf not in files:
            continue
        pm = re.search(r"as\s+projection\s+on\s+(\w+)", read(vf), re.I)
        if not pm:
            continue
        bsec = base_of.get(pm.group(1).upper())
        if bsec is None:
            # "The base entity X of Y does not define a behavior." The
            # projection cannot activate without one, and until now this
            # rule skipped the case silently - it only checked that each
            # `use` had a counterpart, not that the base existed at all.
            problems.append(
                f"{f}: {proj}: its base entity {pm.group(1).upper()} has no "
                f"`define behavior for` anywhere in the repository - a "
                f"projection behaviour cannot activate without one")
            continue
        for u in re.finditer(r"\buse\s+(create|update|delete|association)\s*(\w*)", sect, re.I):
            kind, name = u.group(1).lower(), u.group(2)
            if kind == "association":
                if not re.search(r"\bassociation\s+" + re.escape(name) + r"\b", bsec, re.I):
                    problems.append(f"{f}: `use association {name}` but {pm.group(1)} does "
                                    f"not declare that association in its behaviour")
            elif not re.search(r"^\s*" + kind + r"\s*;", bsec, re.I | re.M):
                problems.append(f"{f}: `use {kind}` but {pm.group(1)} does not declare "
                                f"`{kind};`")

# --------------- 18. abapGit only knows four class local includes ----------
OK_INCLUDES = {"locals_def", "locals_imp", "macros", "testclasses"}
for f in files:
    m = re.match(r"^(\w+)\.clas\.([\w_]+)\.abap$", f)
    if m and m.group(2) not in OK_INCLUDES:
        problems.append(f"{f}: abapGit's class serializer only reads "
                        f"{', '.join(sorted(OK_INCLUDES))} - this file is ignored on pull")

# ---- 19. %action-... in an authorization handler needs an instance auth ----
for f in files:
    if not f.endswith(".clas.locals_imp.abap"):
        continue
    body = read(f)
    for m in re.finditer(r"METHOD\s+get_instance_authorizations\s*\.(.*?)ENDMETHOD",
                         body, re.S | re.I):
        for act in set(re.findall(r"%action-(\w+)", m.group(1))):
            bd = [x for x in files if x.endswith(".bdef.asbdef")
                  # The parentheses may carry other qualifiers alongside it -
              # `( features : instance, authorization : instance )` is the
              # normal shape once an action has both - so match inside the
              # group rather than demanding it be the only entry.
              and re.search(r"\([^)]*authorization\s*:\s*instance[^)]*\)[^;]*\b"
                                + re.escape(act) + r"\b", read(x), re.I)]
            if not bd:
                problems.append(f"{f}: get_instance_authorizations sets %action-{act}, but "
                                f"no behaviour definition declares that action with "
                                f"( authorization : instance )")

# ------------------- 20. message numbers must exist in ZEINV_MSG -----------
msgf = [x for x in files if x.endswith(".msag.xml")]
if msgf:
    msrc = read(msgf[0])
    have = set(re.findall(r"<MSGNR>(\d+)</MSGNR>", msrc))
    for f in files:
        if not f.endswith(".abap"):
            continue
        for m in re.finditer(r"id\s*=\s*'ZEINV_MSG'\s*\n?\s*number\s*=\s*'(\d+)'",
                             read(f), re.I):
            if m.group(1) not in have:
                problems.append(f"{f}: message ZEINV_MSG {m.group(1)} does not exist "
                                f"in the message class")



def cds_code(body):
    """CDS source with block and line comments removed - a rule that matches on
    words must not fire on a comment explaining why the word is absent."""
    body = re.sub(r"/\*.*?\*/", " ", body, flags=re.S)
    return re.sub(r"//[^\n]*", " ", body)


# ------------- 21. feature control is a characteristic, not a statement ----
# `instance feature control action X;` reads like the documentation but is not
# BDL. It is written `action ( features : instance ) X ...` on the operation
# itself, and the standalone form is both an unknown statement and a second
# declaration of the action.
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    for m in re.finditer(r"^\s*(?:instance|static)\s+feature\s+control\s+.*$",
                         read(f), re.M | re.I):
        problems.append(f"{f}: `{m.group(0).strip()}` is not behaviour-definition "
                        f"syntax - feature control is declared on the operation, "
                        f"as `action ( features : instance ) <name> ...`")

# ------------ 22. a path expression needs the association to be declared ---
# This is what an undeclared `_SellerParty.PartyName as SellerName` in a
# projection costs: the view does not activate, and neither does anything
# annotating the element it was supposed to produce.
cds_assoc = {}
for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    body = read(f)
    name = re.search(r"define\s+(?:root\s+)?(?:abstract\s+)?view\s+entity\s+(\w+)",
                     body, re.I)
    if not name:
        continue
    cds_assoc[name.group(1).upper()] = {
        a.upper() for a in re.findall(
            r"(?:association(?:\s*\[[^\]]*\])?\s+(?:to\s+parent\s+|to\s+)?[\w.]*\s*as\s+(_\w+)"
            r"|composition\s*\[[^\]]*\]\s*of\s+\w+\s+as\s+(_\w+))", body)
        for a in a if a}

for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    body = cds_code(read(f))
    name = re.search(r"define\s+(?:root\s+)?(?:abstract\s+)?view\s+entity\s+(\w+)", body, re.I)
    if not name:
        continue
    own = set(cds_assoc.get(name.group(1).upper(), set()))
    base = re.search(r"as\s+projection\s+on\s+(\w+)", body, re.I)
    if base:
        own |= cds_assoc.get(base.group(1).upper(), set())
    # a plain select-from view addresses its data sources by alias, not by
    # association, so only projections are checked
    if not base:
        continue
    for m in re.finditer(r"(?<![\w.])(_\w+)\s*\.", body):
        if m.group(1).upper() not in own:
            problems.append(f"{f}: path expression over {m.group(1)}, which is not an "
                            f"association of {name.group(1)} or of {base.group(1)}")

# ------------------ 23. EML association navigation needs a backslash -------
for f in files:
    if not f.endswith(".abap"):
        continue
    for m in re.finditer(r"^\s*ENTITY\s+\w+\s+BY\s+(?!\\)(_\w+)", read(f), re.M | re.I):
        problems.append(f"{f}: `BY {m.group(1)}` must be `BY \\{m.group(1)}` - "
                        f"EML navigates an association by its backslash path")


# ------------------- 24. @EndUserText.label is typed STRING(40) ------------
for f in files:
    if not f.endswith((".ddls.asddls", ".ddlx.asddlxs", ".srvd.srvdsrv")):
        continue
    for m in re.finditer(r"@EndUserText\.label:\s*'([^']*)'", read(f)):
        if len(m.group(1)) > 40:
            problems.append(f"{f}: @EndUserText.label '{m.group(1)[:45]}' is "
                            f"{len(m.group(1))} characters - the annotation is typed "
                            f"STRING(40) and a longer value is rejected")

# --------------------- 25. CDS reserved words as element names -------------
# The full list is long; these are the ones this model came close to.
CDS_RESERVED = {"LABEL", "KEY", "VALUE", "TYPE", "CASE", "WHEN", "THEN", "ELSE",
                "END", "AS", "ON", "AND", "OR", "NOT", "NULL", "LIKE", "BETWEEN",
                "SELECT", "FROM", "WHERE", "GROUP", "ORDER", "BY", "UNION",
                "ALL", "DISTINCT", "JOIN", "INNER", "LEFT", "RIGHT", "OUTER",
                "ASSOCIATION", "COMPOSITION", "TO", "OF", "PARENT", "DEFINE",
                "VIEW", "ENTITY", "ROOT", "VIRTUAL", "CAST", "COALESCE"}
for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    for m in re.finditer(r"\bas\s+(\w+)\s*,", cds_code(read(f))):
        if m.group(1).upper() in CDS_RESERVED:
            problems.append(f"{f}: element name {m.group(1)} is a CDS reserved word")

# ------------------ 26. key elements must be first and contiguous ----------
for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    body = cds_code(read(f))
    sel = body[body.index("{"):] if "{" in body else ""
    # A UNION restarts the element list: each branch has its own select
    # list and its own keys, so the contiguity check runs per branch.
    # Without this split the second branch's `key` lines look as though
    # they follow the first branch's plain elements.
    branches = re.split(r"\bunion\s+(?:all\s+)?", sel, flags=re.I)
    el = []
    for br in branches:
        # strip comments and annotations so only element lines remain
        lines = [l.strip() for l in br.splitlines()
                 if l.strip() and not l.strip().startswith(("@", "/*", "*", "//"))]
        lines = [l for l in lines
                 if re.match(r"^(key\s+)?[\w.]+(\s+as\s+\w+)?,?$", l, re.I)]
        el.append(lines)
    for branch_el in el:
      seen_plain = False
      for l in branch_el:
        if re.match(r"^key\s", l, re.I):
            if seen_plain:
                problems.append(f"{f}: `{l}` - key elements must be contiguous and "
                                f"start at the first position")
                break
        else:
            seen_plain = True

# ------------------------- 27. SELECT * in a view entity -------------------
for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    body = read(f)
    body = cds_code(body)
    if re.search(r"define\s+(?:root\s+)?view\s+entity", body, re.I) and \
       re.search(r"\{\s*\*\s*\}", body):
        problems.append(f"{f}: `{{ * }}` is not permitted in a view entity - "
                        f"list the elements")


# ---------- 28. a child projection must NOT declare a provider contract ----
for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    body = read(f)
    body = cds_code(body)
    if "redirected to parent" in body and "provider contract" in body:
        problems.append(f"{f}: a view with `redirected to parent` must not declare a "
                        f"provider contract - it is declared once on the root "
                        f"projection and inherited")


# ------- 29. @ObjectModel.virtualElement is not released for ABAP Cloud ----
for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    if re.search(r"@ObjectModel\.virtualElement", cds_code(read(f))):
        problems.append(f"{f}: @ObjectModel.virtualElement is not released for ABAP "
                        f"Cloud - compute the value as a CASE in a view beside the "
                        f"business object and reach it by association")

# ------------- 30. a projection view needs a behaviour definition ----------
# "Transactional Projection View must be part of a business object": a view
# declared `as projection on` is a projection whether or not it carries a
# contract, and it has to be named by some projection behaviour definition.
proj_entities = set()
for f in files:
    if f.endswith(".bdef.asbdef"):
        b = read(f)
        if re.match(r"\s*projection\s*;", b):
            proj_entities |= {e.upper() for e in
                              re.findall(r"define\s+behavior\s+for\s+(\w+)", b, re.I)}
for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    b = cds_code(read(f))
    if not re.search(r"as\s+projection\s+on", b, re.I):
        continue
    nm = re.search(r"define\s+(?:root\s+)?view\s+entity\s+(\w+)", b, re.I)
    if nm and nm.group(1).upper() not in proj_entities:
        problems.append(f"{f}: {nm.group(1)} is declared `as projection on` but no "
                        f"projection behaviour definition names it - either give it "
                        f"one or make it `as select from`")


# ---------------- 31. `use field` is not projection syntax -----------------
# Only create, update, delete, action, function, event, key and association
# may follow `use`. A field characteristic is a statement of its own.
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    for m in re.finditer(r"^\s*use\s+field\b.*$", read(f), re.M | re.I):
        problems.append(f"{f}: `{m.group(0).strip()}` - in a projection a field "
                        f"characteristic is written without `use`")

# ------- 32. a to-parent association must be declared and exposed ----------
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    body = read(f)
    if re.match(r"\s*projection\s*;", body):
        continue
    for blk in re.finditer(r"define\s+behavior\s+for\s+(\w+)(.*?)\n\}", body, re.S | re.I):
        ent, sect = blk.group(1), blk.group(2)
        par = re.search(r"lock\s+dependent\s+by\s+(_\w+)", sect, re.I)
        if not par:
            continue
        if not re.search(r"^\s*association\s+" + re.escape(par.group(1)) + r"\s*[;{]",
                         sect, re.I | re.M):
            problems.append(f"{f}: {ent} is `lock dependent by {par.group(1)}` but does "
                            f"not declare `association {par.group(1)};` - RAP requires a "
                            f"to-parent association to be declared by the child")

# --------------- 33. an APJ parameter name is CHAR 8 -----------------------
for f in files:
    if not f.endswith(".abap"):
        continue
    for m in re.finditer(r"selname\s*=\s*'([^']*)'", read(f), re.I):
        if len(m.group(1)) > 8:
            problems.append(f"{f}: APJ parameter name '{m.group(1)}' is "
                            f"{len(m.group(1))} characters - SELNAME is CHAR 8")

# ------------------------- 34. COND <type> #( ) ---------------------------
for f in files:
    if not f.endswith(".abap"):
        continue
    for m in re.finditer(r"\b(COND|SWITCH|REDUCE|VALUE)\s+(\w+)\s+#\s*\(", read(f), re.I):
        problems.append(f"{f}: `{m.group(1)} {m.group(2)} #(` - write either "
                        f"`{m.group(1)} #(` or `{m.group(1)} {m.group(2)}(`, not both")

# ------- 35. a derived RAP type is not permitted on RETURNING -------------
for f in files:
    if not f.endswith(".abap"):
        continue
    for m in re.finditer(r"RETURNING\s+VALUE\(\w+\)\s+TYPE\s+TABLE\s+FOR\s+(\w+)",
                         read(f), re.I):
        if True:
            problems.append(f"{f}: `TABLE FOR {m.group(1)}` on a RETURNING parameter - "
                            f"a derived RAP type has to be CHANGING or EXPORTING")


# ---- helpers shared by rules 36-41 ----------------------------------------
def cds_keys(view):
    """Key element names of a CDS view entity, as the view spells them."""
    f = view.lower() + ".ddls.asddls"
    if f not in files:
        return []
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    body = re.sub(r"//.*$", "", body, flags=re.M)
    out = []
    for m in re.finditer(r"^\s*key\s+([\w.]+)(?:\s+as\s+(\w+))?", body, re.I | re.M):
        # `key Elem`, `key col as Elem`, and `key SOURCE_VIEW.Elem` (the form
        # the inherited consumption views use, with no alias at all).
        out.append(m.group(2) or m.group(1).split(".")[-1])
    return out

_flag = lambda _f, _m: problems.append(f"{_f}: {_m}")

# ============================================================================
# Rules 36-41 were added after the fourth activation round in the tenant.
# Every one of them is a defect that round reported and that a static read of
# this repository could have found first.
# ============================================================================

# ------- 36. a derived RAP type in a method DECLARATION ---------------------
# `TYPE TABLE FOR ...` resolves only once the behaviour definition is active.
# In a method body that is fine - the class is compiled after the BDEF. In the
# declaration part of a class it is not: ZCL_EINV_WORKLIST failed with "the
# statement before CREATE ... was not closed" and ZBP_CDS_INT_EDOC_APH with
# "ACTION IMPORT is not valid", both because the BDEF was not yet active.
# RAP's own handler syntax (IMPORTING keys FOR ACTION x~y) is unaffected.
for f in files:
    if not f.endswith(".abap"):
        continue
    for m in re.finditer(r"METHODS\s+(\w+)(.*?)\.\s*$", read(f), re.S | re.M):
        name, sig = m.group(1), m.group(2)
        if len(sig) > 600:
            continue
        d = re.search(r"TYPE\s+TABLE\s+FOR\s+([\w\s]+)", sig, re.I)
        if d:
            # the kind is one to three keywords (CREATE / READ RESULT /
            # ACTION IMPORT), followed by the behaviour definition's name
            DKW = {"CREATE", "UPDATE", "DELETE", "READ", "ACTION", "FUNCTION",
                   "IMPORT", "RESULT", "INSTANCE", "FEATURES", "KEY", "OF",
                   "PERMISSIONS", "FAILED", "REPORTED", "MAPPED", "HIERARCHY",
                   "LINK", "GLOBAL", "AUTHORIZATION", "EARLY", "NUMBERING"}
            words = []
            for w in d.group(1).split():
                if w.upper() not in DKW:
                    break
                words.append(w.upper())
            kind = " ".join(words)
            # No exemption for behaviour pools. That exemption was written
            # after round 4 on the theory that inside the pool the behaviour
            # definition is active by construction; round 5 refuted it -
            # ZBP_CDS_INT_EINV_DOC still failed on `EXPORTING et_doc TYPE
            # TABLE FOR READ RESULT ...` with "the statement before READ ...
            # was not closed". A derived type belongs in a method BODY only.
            _flag(f, f"METHODS {name} types a parameter `TABLE FOR "
                     f"{d.group(1).strip().upper()}` in the declaration part - a derived "
                     f"RAP type there makes the class compile only once the behaviour "
                     f"definition is active; use a plain local type")

# ------- 37. ABAP Doc only attaches to the declaration it precedes ----------
# `"!` in front of a chained TYPES: / DATA: / CONSTANTS: is rejected with
# "ABAP Doc comment is in the wrong position".
for f in files:
    if not f.endswith(".abap"):
        continue
    lines = read(f).split("\n")
    for i, l in enumerate(lines[:-1]):
        if not l.strip().startswith('"!'):
            continue
        nxt = lines[i + 1].strip()
        while nxt.startswith('"') or nxt.startswith('*'):
            i += 1
            if i + 1 >= len(lines):
                break
            nxt = lines[i + 1].strip()
        if re.match(r"^(TYPES|DATA|CONSTANTS|CLASS-DATA|STATICS)\s*:", nxt, re.I):
            _flag(f, f"ABAP Doc (\"!) in front of `{nxt.split(':')[0].upper()}:` - it "
                     f"attaches only to the declaration it precedes; use a plain \" comment")

# ------- 38. a TRY block needs a CATCH or a CLEANUP -------------------------
for f in files:
    if not f.endswith(".abap"):
        continue
    stack = []
    for n, l in enumerate(read(f).split("\n"), 1):
        t = l.strip().upper()
        if t.startswith("*") or t.startswith('"'):
            continue
        if re.match(r"^TRY\s*\.", t):
            stack.append([n, False])
        elif re.match(r"^(CATCH|CLEANUP)\b", t) and stack:
            stack[-1][1] = True
        elif re.match(r"^ENDTRY\s*\.", t) and stack:
            ln, handled = stack.pop()
            if not handled:
                _flag(f, f"TRY at line {ln} reaches its ENDTRY at line {n} with no CATCH "
                         f"and no CLEANUP - the block does not activate")

# -------- 58. a behaviour definition needs a ROOT view entity -------------
# "The type X is not a root entity or is not released for BEHAVIOR
# implementations", with the behaviour pool failing alongside it as
# "X is not part of a composition hierarchy of CDS entities".
# A behaviour can only be written for the root of a composition hierarchy,
# even when that hierarchy has one node and no children. Projections are
# covered too: a projection view must be root as well.
_ddls = {}
for f in files:
    if f.endswith(".ddls.asddls"):
        m = re.search(r"define\s+(root\s+)?(abstract\s+)?(custom\s+)?"
                      r"(table\s+function|view\s+entity|view)\s+(\w+)",
                      read(f), re.I)
        if m:
            _ddls[m.group(5).upper()] = (f, bool(m.group(1)))
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    body = re.sub(r"//.*$", "", body, flags=re.M)
    # Only the FIRST block in a behaviour definition is the composition
    # root; every block after it is a child, and a child view is correctly
    # not root. In a managed definition the children also say so with
    # `lock dependent by`, but in a projection they do not, so position is
    # the reliable signal.
    for m in list(re.finditer(r"define\s+behavior\s+for\s+(\w+)(.*?)\{", body,
                              re.S | re.I))[:1]:
        ent = m.group(1).upper()
        if re.search(r"\b(lock|authorization)\s+dependent\b", m.group(2), re.I):
            continue
        if ent not in _ddls:
            continue
        src, is_root = _ddls[ent]
        if not is_root:
            _flag(f, f"{ent}: a behaviour is defined for it, but {src} declares "
                     f"`define view entity` - a behaviour needs the ROOT of a "
                     f"composition hierarchy, so it must be "
                     f"`define root view entity`")

# ---- 59. IN LOCAL MODE only inside the behaviour pool of that same BO ----
# "The operation can only be used in implementations of behavior definition
# X". IN LOCAL MODE bypasses the external layer, so it is reserved for the
# BO's own handler. A call from one BO's handler into another must go
# through the external layer, which also means the called BO's feature
# control and authorization are evaluated - the behaviour you want.
_cls_bo = {}
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    src = read(f)
    cm = re.search(r"implementation\s+in\s+class\s+(\w+)", src, re.I)
    ents = {m.group(1).upper()
            for m in re.finditer(r"define\s+behavior\s+for\s+(\w+)", src, re.I)}
    if cm:
        _cls_bo.setdefault(cm.group(1).lower(), set()).update(ents)
for f in files:
    m = re.match(r"^(\w+)\.clas\.(locals_imp|locals_def)\.abap$", f)
    if not m or m.group(1).lower() not in _cls_bo:
        continue
    own = _cls_bo[m.group(1).lower()]
    body = re.sub(r'^\s*[*"].*$', "", read(f), flags=re.M)
    for em in re.finditer(r"\b(MODIFY|READ)\s+ENTITIES?\s+OF\s+(\w+)([^.]*?)"
                          r"\bIN\s+LOCAL\s+MODE", body, re.S | re.I):
        if em.group(2).upper() not in own:
            _flag(f, f"`{em.group(1).upper()} ENTITIES OF {em.group(2)} ... IN LOCAL "
                     f"MODE` in the behaviour pool of {'/'.join(sorted(own))} - "
                     f"IN LOCAL MODE is only legal inside that entity's own "
                     f"handler; drop it so the call goes through the external layer")

# ------ 60. action external names are flat per service definition --------
# "Duplicate action external name X" on the service binding. In OData V2
# an action becomes a FunctionImport in one flat, service-wide namespace,
# so two entities exposed by the same service definition may not carry
# actions of the same name - even though RAP itself allows it, because
# there the action is scoped to its entity.
_view_act = {}
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    bsrc = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    bsrc = re.sub(r"//.*$", "", bsrc, flags=re.M)
    for blk in re.finditer(r"define\s+behavior\s+for\s+(\w+)[^{]*\{(.*?)\n\}",
                           bsrc, re.S | re.I):
        acts = set(re.findall(r"\buse\s+action\s+(\w+)", blk.group(2), re.I))
        acts |= {m.group(2) for m in re.finditer(
            r"\b(?:static\s+)?action\s*(\([^)]*\))?\s*(\w+)", blk.group(2), re.I)}
        _view_act.setdefault(blk.group(1).upper(), set()).update(
            a for a in acts if a.lower() not in ("action",))
for f in files:
    if not f.endswith(".srvd.srvdsrv"):
        continue
    seen = {}
    for em in re.finditer(r"expose\s+(\w+)(?:\s+as\s+(\w+))?\s*;", read(f), re.I):
        view = em.group(1).upper()
        for a in sorted(_view_act.get(view, ())):
            if a.upper() in seen and seen[a.upper()] != view:
                _flag(f, f"duplicate action external name {a}: exposed by both "
                         f"{seen[a.upper()]} and {view}. OData gives every action in "
                         f"a service one flat namespace - rename it on one of them")
            seen[a.upper()] = view

# -------- 61. unresolved merge conflict markers in a source file ---------
# A merge committed without resolving puts `<<<<<<< HEAD` into the file, the
# pull carries it into the tenant, and the activation fails on line 1 with
# "Unexpected token". Cheap to spot, and nothing in this package has a
# legitimate reason to contain these.
for f in files:
    body = read(f)
    for mark in ("<<<<<<<", ">>>>>>>"):
        if mark in body:
            ln = body[:body.index(mark)].count("\n") + 1
            _flag(f, f"unresolved merge conflict marker `{mark}` at line {ln} - "
                     f"the file was committed mid-merge and will not activate")
            break

# ------ 62. a CONSTANTS VALUE clause takes a literal, not `&&` -----------
# "Unable to interpret &&". A VALUE clause is a literal; concatenation is
# an expression and is only legal where one is allowed. Easy to write by
# habit when porting a multi-line literal from older ABAP.
for f in files:
    if not f.endswith(".clas.abap") and not f.endswith(".prog.abap"):
        continue
    body = re.sub(r'^\s*[*].*$', "", read(f), flags=re.M)
    for m in re.finditer(r"VALUE\s+'[^']*'\s*&&", body):
        ln = body[:m.start()].count("\n") + 1
        _flag(f, f"line {ln}: a CONSTANTS/DATA `VALUE` clause takes a literal, "
                 f"but this one continues with `&&` - split it into several "
                 f"constants and concatenate at the point of use")

# ------- 39/40. BDEF: global authorization, and keys flagged readonly -------
# "Operation create should be equipped with (global) authorization" - CREATE
# and a static action have no instance, so `authorization master ( instance )`
# alone leaves them unauthorized.
# "The key field X should be flagged as readonly or readonly:update".
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    body = re.sub(r"//.*$", "", body, flags=re.M)
    if "projection" in body.split("\n")[0].lower():
        continue
    for blk in re.finditer(
            r"define\s+behavior\s+for\s+(\w+)(.*?)\{(.*?)\n\}", body, re.S | re.I):
        view, head, sect = blk.group(1), blk.group(2), blk.group(3)
        am = re.search(r"authorization\s+master\s*\(([^)]*)\)", head, re.I)
        if am and "global" not in am.group(1).lower():
            if re.search(r"^\s*create\s*;", sect, re.I | re.M) or \
               re.search(r"static\s+action", sect, re.I):
                _flag(f, f"{view}: `authorization master ( instance )` but the behaviour "
                         f"has create and/or a static action - neither has an instance to "
                         f"authorize, so the global authorization is required too")
        # Every key, on every behaviour, with no exemption for one that
        # declares no create and no update. A draft of
        # ZCDS_CUN_EINV_WORKLIST relaxed this rule on the reasoning that an
        # action-only behaviour has nothing to write its keys; the F3Y
        # activation rejected it anyway - the check is on the key, not on
        # the operations. Section 48.
        ro = " ".join(re.findall(r"field\s*\(\s*readonly[^)]*\)([^;]*);", sect, re.I))
        ro = {x.strip().upper() for x in re.split(r"[,\s]+", ro) if x.strip()}
        for k in cds_keys(view):
            if k.upper() not in ro:
                _flag(f, f"{view}: key field {k} is in no `field ( readonly ... )` list - "
                         f"the tenant asks for `readonly` or `readonly : update` on every key")

# ------- 41. constructs ABAP for Cloud Development has retired -------------
RETIRED = {
    r"\bTYPE\s+flag\b":  "data element FLAG is deprecated - use ABAP_BOOLEAN",
    r"\bsy-datum\b":     "SY-DATUM - use cl_abap_context_info=>get_system_date( )",
    r"\bsy-uzeit\b":     "SY-UZEIT - use cl_abap_context_info=>get_system_time( )",
}
for f in files:
    if not f.endswith(".abap"):
        continue
    for n, l in enumerate(read(f).split("\n"), 1):
        if l.strip().startswith("*"):
            continue
        # a trailing " comment is still a comment: ZCL_ELT keeps the old
        # statement behind one on the line that replaced it.
        l = re.sub(r'"[^"]*$', "", l)
        for pat, msg in RETIRED.items():
            if re.search(pat, l, re.I):
                _flag(f, f"line {n}: {msg}")




# ------- 42. DISTINCT belongs to the select list, not in front of FROM -----
# `SELECT DISTINCT FROM src FIELDS a, b` is the old word order carried into
# the new one; the tenant answers "FROM is invalid here (due to grammar)" and
# then reports every variable in the method as unknown.
for f in files:
    if not f.endswith(".abap"):
        continue
    for n, l in enumerate(read(f).split("\n"), 1):
        if re.search(r"\bSELECT\s+DISTINCT\s+FROM\b", l, re.I):
            _flag(f, f"line {n}: `SELECT DISTINCT FROM` - in the FIELDS form "
                     f"DISTINCT belongs to the select list: "
                     f"`SELECT FROM src FIELDS DISTINCT a, b`")

# ------- 43. %%tky is not a component; %tky is --------------------------------
# A literal doubled percent reaches the source when a generator writes the
# handler through a %-format string. ABAP reports it as "No component exists
# with the name %%TKY, but there is a component with a similar name %TKY".
for f in files:
    if not f.endswith(".abap"):
        continue
    for n, l in enumerate(read(f).split("\n"), 1):
        m = re.search(r"%%\w+", l)
        if m:
            _flag(f, f"line {n}: `{m.group(0)}` - a doubled percent is not a "
                     f"RAP component name")



def abap_code(name):
    """File contents with ABAP comments removed, so a rule never fires on a
    comment that explains why the construct is absent."""
    out = []
    for l in read(name).split("\n"):
        if l.lstrip().startswith("*"):
            out.append("")
            continue
        out.append(re.sub(r'"[^"]*$', "", l))
    return "\n".join(out)


# ------- 44. a static action's result row has no %cid_ref ------------------
for f in files:
    if not f.endswith(".abap"):
        continue
    body = abap_code(f)
    statics = set()
    for b in files:
        if b.endswith(".bdef.asbdef"):
            for m in re.finditer(r"static\s+action\s*(?:\([^)]*\))?\s*(\w+)", read(b), re.I):
                statics.add(m.group(1).upper())
    for m in re.finditer(r"METHODS\s+(\w+)\s+FOR\s+MODIFY\s+IMPORTING\s+keys\s+FOR\s+ACTION\s+[\w~]*~(\w+)",
                         body, re.I):
        if m.group(2).upper() not in statics:
            continue
        impl = re.search(r"METHOD\s+" + m.group(1) + r"\s*\.(.*?)\n\s*ENDMETHOD\s*\.",
                         body, re.S | re.I)
        if impl and "%cid_ref" in impl.group(1):
            _flag(f, f"METHOD {m.group(1)} fills %cid_ref, but {m.group(2)} is a STATIC "
                     f"action - its result row has no instance to point back at")

# ------- 45. a determination's REPORTED is not an EML REPORTED -------------
# Inside a determination or a validation, `reported` is RESPONSE FOR REPORTED
# EARLY; the REPORTED of an EML MODIFY is the LATE form. Appending one to the
# other with LINES OF is rejected as "unsuitable for the type ... (see long
# text)". CORRESPONDING per row is the way across.
for f in files:
    if not f.endswith(".abap"):
        continue
    body = abap_code(f)
    early = {m.group(1).upper() for m in
             re.finditer(r"METHODS\s+(\w+)\s+FOR\s+(?:DETERMINE|VALIDATE)\b", body, re.I)}
    for m in re.finditer(r"METHOD\s+(\w+)\s*\.(.*?)\n\s*ENDMETHOD\s*\.", body, re.S | re.I):
        if m.group(1).upper() not in early:
            continue
        if re.search(r"(reported|failed)-\w+\s*=\s*VALUE\s*#\(\s*BASE.*?LINES\s+OF",
                     m.group(2), re.S | re.I):
            _flag(f, f"METHOD {m.group(1)} is a determination/validation and copies an EML "
                     f"REPORTED with `LINES OF` - the EARLY and LATE row types differ; "
                     f"append CORRESPONDING #( ) per row")

# ------- 46. an action parameter entity cannot carry a child table ---------
# An abstract entity used as a `parameter` is flattened into %param. A
# composition in it is silently dropped, and the handler's `ls_par-_Child`
# is then "a component that does not exist".
param_entities = set()
for f in files:
    if f.endswith(".bdef.asbdef"):
        for m in re.finditer(r"\bparameter\s+(\w+)", read(f), re.I):
            param_entities.add(m.group(1).upper())
for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    body = re.sub(r"//.*$", "", body, flags=re.M)
    m = re.search(r"define\s+(?:root\s+)?abstract\s+entity\s+(\w+)", body, re.I)
    if not m or m.group(1).upper() not in param_entities:
        continue
    c = re.search(r"(\w+)\s*:\s*composition\s*\[", body, re.I)
    if c:
        _flag(f, f"{m.group(1)} is an action parameter entity and declares the composition "
                 f"{c.group(1)} - %param is flat, so the handler cannot read it")

# ------- 47. INDEX INTO declares its own variable --------------------------
for f in files:
    if not f.endswith(".abap"):
        continue
    body = abap_code(f)
    for m in re.finditer(r"METHOD\s+(\w+)\s*\.(.*?)\n\s*ENDMETHOD\s*\.", body, re.S | re.I):
        mb = m.group(2)
        for idx in {x.group(1).upper() for x in
                    re.finditer(r"INDEX\s+INTO\s+(\w+)", mb, re.I)}:
            if re.search(r"^\s*DATA\s+" + idx + r"\b", mb, re.I | re.M):
                _flag(f, f"METHOD {m.group(1)}: `{idx}` is declared with DATA and again by "
                         f"`INDEX INTO` - the FOR expression declares it itself")



# ------- 48. APJ: template -> catalog entry -> class must all resolve -------
# A job template names its catalog entry under `catalogName`. Spell it
# `catalogEntry` and the field is simply absent: the tenant answers "Job
# catalog entry  doesn't exist." with an empty name and no object attached,
# which is the hardest kind of error to trace back to a file.
import json as _json

_catalogs = {f[: -len(".sajc.json")].upper() for f in files if f.endswith(".sajc.json")}
for f in files:
    if f.endswith(".sajt.json"):
        try:
            gi = _json.loads(read(f)).get("generalInformation", {})
        except ValueError:
            _flag(f, "not valid JSON")
            continue
        cat = gi.get("catalogName")
        if not cat:
            _flag(f, f"job template has no `catalogName` in generalInformation "
                     f"(keys present: {sorted(gi) or 'none'}) - the tenant then reports "
                     f"an empty job catalog entry with no object to point at")
        elif cat.upper() not in _catalogs:
            _flag(f, f"job template names catalog entry {cat}, which is not in the package")
    elif f.endswith(".sajc.json"):
        try:
            gi = _json.loads(read(f)).get("generalInformation", {})
        except ValueError:
            _flag(f, "not valid JSON")
            continue
        cls = gi.get("className")
        if not cls:
            _flag(f, "job catalog entry has no `className` in generalInformation")
        elif cls.lower() + ".clas.abap" not in files:
            _flag(f, f"job catalog entry names class {cls}, which is not in the package")



# ------- 49. a launchpad page must point at a tile that exists -------------
# A .uipg.json visualization names {ladiId, tileId}. The ladiId has to be a
# .uiad.json in the package and the tileId one of the tiles that descriptor
# declares - these are platform-generated hashes, so a page carried over from
# another system points at a tile that was never imported, and the tenant
# answers "referenced LADI not found".
_ladi = {}
for f in files:
    if f.endswith(".uiad.json"):
        try:
            d = _json.loads(read(f))
        except ValueError:
            _flag(f, "not valid JSON")
            continue
        _ladi[f[: -len(".uiad.json")].upper()] = {
            t.get("id") for t in d.get("tiles", []) if t.get("id")}

for f in files:
    if not f.endswith(".uipg.json"):
        continue
    try:
        d = _json.loads(read(f))
    except ValueError:
        _flag(f, "not valid JSON")
        continue
    for sec in d.get("sections", []):
        for viz in sec.get("visualizations", []):
            a = viz.get("ladiAssignment") or {}
            lid, tid = a.get("ladiId"), a.get("tileId")
            if not lid:
                _flag(f, f"visualization {viz.get('id')} has no ladiId")
            elif lid.upper() not in _ladi:
                _flag(f, f"visualization {viz.get('id')} names app descriptor {lid}, "
                         f"which is not in the package")
            elif tid and tid not in _ladi[lid.upper()]:
                _flag(f, f"visualization {viz.get('id')} names tile {tid} of {lid}, which "
                         f"declares {sorted(_ladi[lid.upper()]) or 'no tiles'} - a hash "
                         f"carried over from another system")



# ------- 50. a job catalog entry needs an IAM app of type SAJC -------------
# An application job catalog entry is only reachable by name once it is
# registered as an IAM app (.sia6.xml, APP_TYPE SAJC, SECONDARY_ID the catalog
# entry). The two inherited jobs have one; the four generated for this
# conversion did not, which is a plausible reason the templates imported with
# an empty Job Catalog Entry.
_sajc_iam = set()
for f in files:
    if f.endswith(".sia6.xml"):
        b = read(f)
        if "<APP_TYPE>SAJC</APP_TYPE>" in b:
            m = re.search(r"<SECONDARY_ID>([^<]*)</SECONDARY_ID>", b)
            if m:
                _sajc_iam.add(m.group(1).strip().upper())
for f in files:
    if f.endswith(".sajc.json"):
        cat = f[: -len(".sajc.json")].upper()
        if cat not in _sajc_iam:
            _flag(f, f"job catalog entry {cat} has no IAM app of type SAJC - expected a "
                     f"{cat.lower()}_sajc.sia6.xml with SECONDARY_ID {cat}")



# ------- 51. a binding may not claim to be published without its endpoint --
# PUBLISHED/BINDING_CREATED true says "the inbound service that backs this
# endpoint already exists". For a V2 binding that object ships alongside as a
# .sco2.xml; for the V4 bindings generated here it is created by Local Publish
# in ADT and cannot be written by hand. Importing one that claims to be
# published leaves the tenant hunting for an inbound service nothing created.
for f in files:
    if not f.endswith(".srvb.xml"):
        continue
    b = read(f)
    if "<PUBLISHED>true</PUBLISHED>" not in b:
        continue
    name = f[: -len(".srvb.xml")]
    if f"{name}_iwsg.sco2.xml" not in files:
        # Reworded after section 74. The original text said the flag "has to
        # be false on import" and that the shell blocks the publish. Neither
        # held: ZSB_EDOC_AP published with its shell in place, and the flag
        # is true because the tenant really has published it. What is wrong
        # is the repository, which carries the claim without the object.
        _flag(f, f"published in the tenant, but abapGit did not serialise its inbound "
                 f"service ({name}_iwsg.sco2.xml) - a fresh import gets a half-carried "
                 f"publish and has to Publish Locally again (section 74: the publish "
                 f"itself succeeds, so this is repository fidelity, not a blocker)")



# ------- 52. OData V2 does not support a collection action result ----------
# `result [0..*]` makes the V2 service binding wizard refuse the whole
# service: "Result Cardinality '[0..*]' of Action 'X' of Entity 'Y' is not
# supported". This package is exposed as OData V2 - UI, which is what SAP
# recommends for a managed business object without draft, so [0..*] is out.
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    body = re.sub(r"//.*$", "", body, flags=re.M)
    for m in re.finditer(r"\b(?:static\s+)?action\s*(?:\([^)]*\))?\s*(\w+)[^;]*?result\s*\[([^\]]*)\]",
                         body, re.I):
        card = m.group(2).strip()
        if "*" in card:
            _flag(f, f"action {m.group(1)} has `result [{card}]` - OData V2 does not "
                     f"support a collection-valued action result, and the V2 binding "
                     f"wizard refuses the service over it")



# ------- 53. a #LINEITEM_REFERENCE facet needs the CHILD to have lineItems --
# Fiori Elements renders such a facet from the TARGET entity's own
# @UI.lineItem. If the child has none, the table appears on the object page
# with no columns - which looks like a working app until someone opens it.
# This is how ZCDS_CUN_EINV_DOC_ERR and _STAT shipped: two facets on the
# object page, neither child annotated.
def _view_body(view):
    f = view.lower() + ".ddls.asddls"
    if f not in files:
        return ""
    b = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    return re.sub(r"//.*$", "", b, flags=re.M)


def _has_lineitem(view):
    if "lineItem" in _view_body(view):
        return True
    for f in files:
        if f.endswith(".ddlx.asddlxs"):
            b = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
            if re.search(r"annotate\s+entity\s+" + view + r"\b", b, re.I) and "lineItem" in b:
                return True
    return False


for f in files:
    if not f.endswith(".ddlx.asddlxs"):
        continue
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    body = re.sub(r"//.*$", "", body, flags=re.M)
    m = re.search(r"annotate\s+entity\s+(\w+)", body, re.I)
    if not m:
        continue
    entity = m.group(1)
    # the annotated entity is a projection; its associations are declared on
    # the interface view it projects on
    base = re.search(r"as\s+projection\s+on\s+(\w+)", _view_body(entity), re.I)
    src = base.group(1) if base else entity
    for fm in re.finditer(r"type:\s*#LINEITEM_REFERENCE[^}]*?targetElement:\s*'(_\w+)'",
                          body, re.S | re.I):
        assoc = fm.group(1)
        a = re.search(r"(?:composition|association)\s*\[[^\]]*\]\s*(?:of|to)\s+(\w+)\s+as\s+"
                      + assoc + r"\b", _view_body(src), re.I)
        if not a:
            continue
        target_int = a.group(1)
        # interface entity -> the projection over it, which is what the
        # service exposes and what the UI annotations have to sit on
        target = target_int
        for g in files:
            if g.endswith(".ddls.asddls") and re.search(
                    r"as\s+projection\s+on\s+" + target_int + r"\b", _view_body(g[:-len(".ddls.asddls")]), re.I):
                target = g[: -len(".ddls.asddls")].upper()
                break
        if not _has_lineitem(target):
            _flag(f, f"facet {assoc} is #LINEITEM_REFERENCE onto {target}, which has no "
                     f"@UI.lineItem - the table renders on the object page with no columns")


# ------- 54. a behaviour definition is BDL, not ABAP: no `"` comments ------
# BDL comments are // and /* */. ABAP's `"` is not a comment character there,
# so the parser reads the whole line as code and reports every character in
# the prose: Unexpected character `"`, then `-`, then `>`. The activation
# error points at the comment lines, which makes it look like an encoding
# problem rather than the wrong comment marker. Cost one failed activation
# round on ZCDS_INT_EINV_INVMAP.
for f in files:
    if not f.endswith(".bdef.asbdef"):
        continue
    body = re.sub(r"/\*.*?\*/", "", read(f), flags=re.S)
    for n, line in enumerate(body.splitlines(), 1):
        stripped = line.strip()
        if stripped.startswith('"'):
            _flag(f, f'line {n} starts a comment with `"` - a behaviour '
                     f'definition is BDL, where comments are `//` or `/* */`; '
                     f'`"` is parsed as code and the whole line errors')


# ------- 55. a free-text domain without LOWERCASE silently upper-cases -----
# A CHAR domain with no <LOWERCASE>X</LOWERCASE> runs the DDIC input
# conversion, so every entry is upper-cased on save. For a key or an SAP
# code that is correct. For a URL, an HTTP header name such as
# X-Clear-Country-Code, a bearer token, a partner name or a message coming
# back from the portal it is silent corruption - the value looks fine in
# the form and is wrong in the database. Cost: the API Endpoint app stored
# every header name and value in capitals.
#
# Only NON-KEY domains are flagged: a case-sensitive key field would let two
# rows differ by case alone, which is worse than upper-casing.
_LC_WORDS = re.compile(r"\b(url|endpoint|message|description|text|value|"
                       r"token|header|parameter|source)\b", re.I)
# Upper case is right for these despite the wording of their description.
_LC_EXEMPT = {"ZDO_EINV_USER",     # ABAP user names are upper case
              "ZDO_EINV_HANDLER",  # ABAP class names are upper case
              "ZDO_PROGRAM"}       # ABAP program names are upper case

_key_dtels = set()
for _f in files:
    if not _f.endswith(".tabl.xml"):
        continue
    for _b in re.findall(r"<DD03P>(.*?)</DD03P>", read(_f), re.S):
        _d = re.search(r"<ROLLNAME>([^<]*)", _b)
        if _d and "<KEYFLAG>X</KEYFLAG>" in _b:
            _key_dtels.add(_d.group(1).upper())

_dom_of_key_dtel = set()
for _f in files:
    if not _f.endswith(".dtel.xml"):
        continue
    _s = read(_f)
    _n = re.search(r"<ROLLNAME>([^<]*)", _s)
    _dm = re.search(r"<DOMNAME>([^<]*)", _s)
    if _n and _dm and _n.group(1).upper() in _key_dtels:
        _dom_of_key_dtel.add(_dm.group(1).upper())

for f in files:
    if not f.endswith(".doma.xml"):
        continue
    body = read(f)
    dt = re.search(r"<DATATYPE>([^<]*)", body)
    if not dt or dt.group(1) not in ("CHAR", "SSTR", "STRG"):
        continue
    if "<LOWERCASE>" in body:
        continue
    name = (re.search(r"<DOMNAME>([^<]*)", body) or [None, ""])[1] if False else \
           re.search(r"<DOMNAME>([^<]*)", body).group(1).upper()
    if name in _LC_EXEMPT or name in _dom_of_key_dtel:
        continue
    text = (re.search(r"<DDTEXT>([^<]*)", body) or [None, ""])[1] if False else \
           (re.search(r"<DDTEXT>([^<]*)", body).group(1)
            if re.search(r"<DDTEXT>([^<]*)", body) else "")
    if _LC_WORDS.search(text):
        _flag(f, f"domain {name} ('{text}') holds free text but has no "
               f"<LOWERCASE>X</LOWERCASE> - the DDIC input conversion will "
               f"upper-case every entry on save")


# ------- 56. a service definition source accepts no comments --------------
# ZSD_EINV_DOC picked up four `//` lines explaining the new worklist entity
# and ADT answered "Comments are not supported and will be deleted on save"
# on every one. The source language of a .srvd.srvdsrv has annotations and
# `expose` and nothing else - no //, no /* */. The danger is not the
# warning but the silent deletion: the tenant saves a file that no longer
# matches the repository, and the next push shows a diff nobody made.
# Put the explanation in the exposed view or in CONVERSION_DESIGN.md.
for f in files:
    if not f.endswith(".srvd.srvdsrv"):
        continue
    body = read(f)
    for n, line in enumerate(body.splitlines(), 1):
        st = line.strip()
        if st.startswith("//") or st.startswith("/*") or st.startswith("*"):
            _flag(f, f"line {n} is a comment - a service definition source "
                   f"supports none, and ADT deletes them on save, so the "
                   f"tenant silently stops matching this file")


# ------- 57. an authorization-defaults object with nothing behind it -------
# Publishing a service binding creates four objects AND two SUSH
# authorization-defaults shells, one for the inbound service (IWSV) and one
# for the service group (IWSG). abapGit serialises the SUSH objects happily;
# it did not serialise the inbound services. The repository therefore
# carried a shell naming ZSB_EINV_DOC_IWSG while that object did not exist,
# and Publish Locally answered "Inbound service ZSB_EINV_DOC_IWSG does not
# exist" - the shell made the publish believe the object was already there.
#
# A half-carried publish is worse than none: with no SUSH the publish would
# simply have created everything.
for f in files:
    if not f.endswith(".sush.xml"):
        continue
    body = read(f)
    m = re.search(r"<DISPLAY_NAME>(.*?)</DISPLAY_NAME>", body, re.S)
    if not m:
        continue
    disp = " ".join(m.group(1).split())
    t = re.search(r"\b(IWSV|IWSG|SAJC)\s+(\S+)", disp)
    if not t:
        continue
    kind, name = t.group(1), t.group(2)
    if kind in ("IWSV", "IWSG"):
        # IWSG names arrive as ZSB_X_0001, IWSV as ZSB_X (version separate)
        binding = re.sub(r"_0001$", "", name).lower()
        needed = f"{binding}_iwsg.sco2.xml"
    else:
        needed = f"{name.lower()}.sajc.json"
    # A binding whose inbound service is missing is already reported once by
    # the rule above; its two shells say the same thing twice more. Section
    # 74 also disproved the mechanism this rule used to assert - the shells
    # do not block the publish - so they are no longer worth a line of their
    # own when the binding is already named.
    if needed in files:
        pass
    elif kind in ("IWSV", "IWSG") and f"{binding}.srvb.xml" in files:
        pass
    else:
        _flag(f, f"authorization defaults for {disp} but {needed} is not in "
               f"the repository and neither is its service binding - nothing "
               f"will ever create the object this shell describes")


# ------ 63. data elements and type-inference the tenant will not accept -----
# Two activation errors, from the same habit of writing ABAP that looked
# right in the HANA source:
#
#   "The use of Data Element SYTABIX is not permitted."
#     SYTABIX, SYSUBRC, SYDBCNT and friends are DDIC data elements that are
#     NOT released for ABAP Cloud. The system-field COMPONENT (`TYPE sy-tabix`)
#     is a different thing and is fine; the standalone data element is not.
#     Inherited code may use them, new code in this package may not.
#
#   "Redundant conversion for type X."
#     CONV where no conversion is needed. In classic ABAP this is a warning;
#     in a strict ABAP Cloud class it is an activation error. It appears when
#     a CONV is copied along with the expression it wrapped - `CONV string( )`
#     around something already typed STRING, `CONV #( )` around a value that
#     already has the target type.
#
# Both are statically decidable from the source, which is the whole argument
# for catching them here rather than one activation round trip at a time.
NOT_RELEASED_DE = ("SYTABIX", "SYSUBRC", "SYDBCNT", "SYINDEX", "SYUNAME",
                   "SYDATUM", "SYUZEIT", "SYMANDT", "SYREPID", "SYLANGU")

for f in files:
    if not f.endswith(".clas.abap"):
        continue
    # Only this package's own classes - ZCL_ELT and friends are inherited and
    # already activate in the tenant as they are.
    base = f.rsplit("/", 1)[-1]
    if not base.startswith("zcl_einv_") and not base.startswith("zbp_"):
        continue
    body = re.sub(r"^\s*[*].*$", "", read(f), flags=re.M)
    body = re.sub(r'"[^\n]*', "", body)          # drop trailing comments
    for de in NOT_RELEASED_DE:
        for m in re.finditer(r"\bTYPE\s+" + de + r"\b", body, re.I):
            ln = body[:m.start()].count("\n") + 1
            _flag(f, f"line {ln}: data element {de} is not released for ABAP "
                     f"Cloud - use the system field component (sy-"
                     f"{de[2:].lower()}) or a plain built-in type")
    # CONV wrapping something that is already that type, in the two shapes
    # that actually occur: a STRING field inside CONV string( ), and CONV #( )
    # on a parameter whose own type is the target.
    for m in re.finditer(r"CONV\s+string\(\s*([a-z_0-9<>-]+)\s*\)", body, re.I):
        name = m.group(1)
        if re.search(r"\b" + re.escape(name.strip("<>")) + r"\b[^\n]*TYPE\s+string\b",
                     body, re.I):
            ln = body[:m.start()].count("\n") + 1
            _flag(f, f"line {ln}: `CONV string( {name} )` where {name} is "
                     f"already typed STRING - a redundant conversion is an "
                     f"activation error in a strict ABAP Cloud class")


# ------ 64. no backticks in behaviour definitions -------------------------
# BDL has no backtick syntax at all - not a string literal, not a quoting
# character, nothing. Every backtick that has ever appeared in a .asbdef
# here arrived by round trip: a comment was quoted into chat or a document
# as Markdown, the Markdown fencing was carried back into the file, and the
# next round trip fenced the fencing. The counts grew 16 -> 112 per file
# across nine files before anyone looked (section 75).
#
# The tenant does not always reject them - a backtick inside a // comment
# activates - which is exactly why this has to be a checker rule rather
# than something activation catches. A backtick outside a comment is a
# syntax error; a backtick inside one is corruption that compounds.
for f in [x for x in files if x.endswith(".bdef.asbdef")]:
    body = read(f)
    if "`" in body:
        n = body.count("`")
        ln = body[:body.index("`")].count("\n") + 1
        problems.append(
            f"{f}: {n} backtick(s), first at line {ln} - BDL has no backtick "
            f"syntax; these are Markdown fencing carried back in by a round "
            f"trip and they compound on every further round trip (section 75)")


# ------ 65. job template parameters must be declared on the CATALOG -------
# Three objects, and the middle one is what makes a parameter visible:
#
#   .sajt.json  template  sets values            -> names a catalogName
#   .sajc.json  catalog   DECLARES "parameters"  -> names a className
#   class       ABAP      GET_PARAMETERS or IF_APJ_RT_RUN
#
# A parameter the class offers but the catalog entry does not list is
# HIDDEN, and a template may not set it:
#
#   Hidden parameter 'P_EINV' should not be used in template
#
# The message says "hidden", not "unknown", which reads like a visibility
# attribute on the class and sends you looking for a flag in
# GET_PARAMETERS. There is none; the catalog entry is the declaration.
# Section 78.
#
# Note ZCL_INSTRU_EXEC declares nothing in ABAP at all - it implements
# IF_APJ_RT_RUN and its catalog entry carries the parameters with sections
# and groups. So the catalog, not the class, is what this rule reads.
for f in files:
    if not f.endswith(".sajt.json"):
        continue
    body = read(f)
    m = re.search(r'"catalogName"\s*:\s*"([^"]+)"', body)
    if not m:
        continue
    cat_file = m.group(1).lower() + ".sajc.json"
    if cat_file not in files:
        _flag(f, f"names catalog entry {m.group(1)}, which is not in the "
               f"repository")
        continue
    cat = read(cat_file)
    pblock = re.search(r'"parameters"\s*:\s*\[(.*?)\n  \]', cat, re.S)
    declared = {p.upper() for p in re.findall(r'"name"\s*:\s*"([^"]+)"',
                                              pblock.group(1))} if pblock else set()
    for p in re.findall(r'"name"\s*:\s*"([^"]+)"', body):
        if p.upper() not in declared:
            _flag(f, f"sets parameter {p}, which {cat_file} does not declare "
                   f"in its \"parameters\" block - the tenant rejects this "
                   f"as \"Hidden parameter '{p}' should not be used in "
                   f"template\" (section 78)")

# ------ 66. a redirected composition child must be exposed too ------------
# A projection declares its children with
#     _Ppf : redirected to composition child ZCDS_CUN_EINV_PPF
# but that line only wires the projection. The entity reaches OData only
# when the SERVICE DEFINITION exposes it as well:
#     expose ZCDS_CUN_EINV_PPF as EInvoicePpf;
#
# Miss the expose and everything still activates - view, projection,
# behaviour, metadata extension. The failure shows up at runtime as an
# object-page facet with no target, which reads like a UI problem and
# sends you to BAS. It is not a UI problem. Section 82.
_exposed = {}            # service file -> set of exposed entity names
for f in files:
    if f.endswith(".srvd.srvdsrv"):
        _exposed[f] = {m.group(1).upper() for m in
                       re.finditer(r"\bexpose\s+([A-Z_0-9]+)", read(f), re.I)}

for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    view = f[: -len(".ddls.asddls")].upper()
    children = {m.group(1).upper() for m in re.finditer(
        r"redirected\s+to\s+composition\s+child\s+([A-Z_0-9]+)", read(f), re.I)}
    if not children:
        continue
    for srvd, exposed in _exposed.items():
        if view not in exposed:
            continue
        for child in sorted(children - exposed):
            _flag(f, f"redirects a composition child to {child}, but "
                   f"{srvd} exposes {view} without it - the entity is not "
                   f"in the OData service and any facet targeting it has "
                   f"no target (section 82)")

# ------ 67. criticality CASE expressions must agree within their family ---
# The status-to-criticality mapping is a CASE expression repeated across
# several views. ZTEINV_STATUS was supposed to hold this and does not
# (section 87), so these expressions ARE the configuration - and copies
# drift. Sections 79 and 81 had already added ACCEPTED and REJECTED to the
# two newest Sales expressions and not to the two older ones, so the same
# status coloured differently depending on which column you looked at.
# Nothing fails - an unlisted status falls to 0 - which is why only a rule
# catches it.
#
# TWO FAMILIES, DELIBERATELY DIFFERENT. The Sales flow speaks the Clear
# e-invoice vocabulary (VALID, SUCCESS, DELIVERED TO BUYER, ...); the AP
# and self-billed flows speak the eDocument vocabulary (APPROVED, CLEARED,
# SENT, IN_PROGRESS, ...). Requiring one global list would be wrong, so the
# rule compares within a family, keyed on einv / edoc in the view name.
#
# Across families it checks something different and more interesting: a
# status listed by both must carry the SAME criticality. ACCEPTED is 3 and
# REJECTED is 1 on both sides today; a future edit that disagreed would be
# a contradiction rather than a vocabulary difference.
_crit = {}
for f in files:
    if not f.endswith(".ddls.asddls"):
        continue
    body = read(f)
    for m in re.finditer(r"case\s+upper\((.*?)\bend\b", body, re.S | re.I):
        pairs = {s.upper(): int(c) for s, c in re.findall(
            r"when\s+'([^']+)'\s*then\s+(\d)", m.group(1), re.I)}
        if pairs:
            _crit[(f, body[: m.start()].count("\n") + 1)] = pairs

def _family(name):
    if "einv" in name:
        return "einv"
    if "edoc" in name:
        return "edoc"
    return "other"

for fam in {_family(f) for f, _ in _crit}:
    members = {k: v for k, v in _crit.items() if _family(k[0]) == fam}
    if len(members) < 2:
        continue
    union = set().union(*(set(v) for v in members.values()))
    for (f, ln), pairs in sorted(members.items()):
        missing = sorted(union - set(pairs))
        if missing:
            _flag(f, f"line {ln}: criticality CASE omits {', '.join(missing)}, "
                   f"which another {fam} criticality CASE lists - an "
                   f"unlisted status falls to 0 (neutral), so one status "
                   f"would show a colour in one column and grey in another "
                   f"(section 87)")

_seen = {}
for (f, ln), pairs in sorted(_crit.items()):
    for st, c in pairs.items():
        if st in _seen and _seen[st][1] != c:
            _flag(f, f"line {ln}: maps {st} to criticality {c}, but "
                   f"{_seen[st][0]} maps it to {_seen[st][1]} - the same "
                   f"status cannot mean two different things (section 87)")
        else:
            _seen.setdefault(st, (f, c))

# ------------------------------------------------------------------ report --
print(f"Checked {len(files)} files in {SRC}")
print(f"  domains {len(domains)}  data elements {len(dtels)}  tables/structures {len(tables)}"
      f"  table types {len(ttyps)}")
print(f"  CDS {len(cds)}  BDEF {len(bdefs)}  DDLX {len(ddlx)}  classes {len(classes)}"
      f"  interfaces {len(intfs)}")
print()
if warnings:
    print(f"{len(warnings)} warning(s):")
    for w in warnings:
        print("  ~", w)
    print()
if problems:
    print(f"{len(problems)} problem(s):")
    seen = set()
    for p in problems:
        if p in seen:
            continue
        seen.add(p)
        print("  !", p)
    sys.exit(1)
print("No inconsistencies found.")
